package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class PoupousService extends Service implements LocationListener {
    private static PowerManager.WakeLock wakeLock = null;
    private static boolean serverRunning = false;
    public static boolean running = false;
    
    private LocationManager lm;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private Handler handler;
    private boolean isListeningActive = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        
        // Acquérir un WakeLock pour garder le processeur actif écran éteint
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::WakeLock");
                wakeLock.acquire(4 * 60 * 60 * 1000L); // Max 4 heures ou jusqu'à libération
            }
        } catch (Exception ignored) {}

        // Initialisation de TTS pour le service vocal
        try {
            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    tts.setLanguage(Locale.FRANCE);
                }
            });
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : "";
        
        createNotificationChannel();
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, "poupous_fond");
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
                .setContentTitle("Poupous Mains Libres Actif")
                .setContentText("Écoute du mot magique en arrière-plan...")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION |
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            startForeground(1, notification, serviceType);
        } else if (Build.VERSION.SDK_INT >= 29) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            startForeground(1, notification, serviceType);
        } else {
            startForeground(1, notification);
        }

        if ("START_GEOFENCE".equals(action)) {
            startGeofencing();
        } else {
            startBackgroundListening();
        }

        running = true;
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel channel = new NotificationChannel(
                        "poupous_fond",
                        "Poupous Service Arrière-plan",
                        NotificationManager.IMPORTANCE_LOW
                );
                channel.setDescription("Maintient Poupous actif en arrière-plan avec écoute vocale");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    private void startGeofencing() {
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000, 50, this, Looper.getMainLooper());
            }
        } catch (Exception ignored) {}
    }

    private void startBackgroundListening() {
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        if (!prefs.getBoolean("wake_running", true)) {
            stopSelf();
            return;
        }

        handler.post(() -> {
            try {
                if (speechRecognizer != null) {
                    try { speechRecognizer.destroy(); } catch (Exception ignored) {}
                }
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(PoupousService.this);
                speechRecognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) { isListeningActive = true; }
                    @Override public void onBeginningOfSpeech() {}
                    @Override public void onRmsChanged(float rmsdB) {}
                    @Override public void onBufferReceived(byte[] buffer) {}
                    @Override public void onEndOfSpeech() {}
                    @Override public void onError(int error) {
                        isListeningActive = false;
                        // Relancer l'écoute en cas de timeout ou pas de correspondance
                        handler.postDelayed(PoupousService.this::startBackgroundListening, 1000);
                    }
                    @Override
                    public void onResults(Bundle results) {
                        isListeningActive = false;
                        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches != null && !matches.isEmpty()) {
                            String spoken = matches.get(0);
                            if (spoken != null && !spoken.trim().isEmpty()) {
                                handleVoiceCommand(spoken);
                            }
                        }
                        handler.postDelayed(PoupousService.this::startBackgroundListening, 500);
                    }
                    @Override public void onPartialResults(Bundle partialResults) {}
                    @Override public void onEvent(int eventType, Bundle params) {}
                });

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
                speechRecognizer.startListening(intent);
            } catch (Exception e) {
                handler.postDelayed(PoupousService.this::startBackgroundListening, 3000);
            }
        });
    }

    private void handleVoiceCommand(String command) {
        String lower = command.toLowerCase(Locale.ROOT);
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        
        // Vérifier si le mot "poupous" ou un déclencheur est prononcé
        if (lower.contains("poupous") || lower.contains("pupus") || lower.contains("pouce pouce")) {
            // Prononcer un accusé de réception ou lancer MainActivity
            if (tts != null) {
                tts.speak("Oui, je t'écoute !", TextToSpeech.QUEUE_FLUSH, null, "poupous_ack");
            }
            
            Intent launchIntent = new Intent(this, MainActivity.class);
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            launchIntent.putExtra("reveil_after", command);
            startActivity(launchIntent);
        }
    }

    @Override
    public void onLocationChanged(Location loc) {
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        if (!prefs.getBoolean("geofence_running", false)) return;
        try {
            JSONArray stores = new JSONArray(prefs.getString("geofence_stores", "[]"));
            for (int i = 0; i < stores.length(); i++) {
                JSONObject s = stores.getJSONObject(i);
                double tLat = s.getDouble("lat");
                double tLon = s.getDouble("lon");
                float[] dist = new float[1];
                Location.distanceBetween(loc.getLatitude(), loc.getLongitude(), tLat, tLon, dist);
                if (dist[0] < 500) {
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    Notification.Builder b;
                    if (Build.VERSION.SDK_INT >= 26) {
                        b = new Notification.Builder(this, "poupous_fond");
                    } else {
                        b = new Notification.Builder(this);
                    }
                    Notification notif = b
                            .setContentTitle("Proximité Magasin")
                            .setContentText("Vous êtes à moins de 500m de " + s.optString("nom"))
                            .setSmallIcon(android.R.drawable.ic_dialog_map)
                            .setAutoCancel(true)
                            .build();
                    if (nm != null) nm.notify(2, notif);
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        running = false;
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (Exception ignored) {}
        }
        if (speechRecognizer != null) {
            try { speechRecognizer.destroy(); } catch (Exception ignored) {}
        }
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {}
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    public static void startHttpServer(Context context) { serverRunning = true; }
    public static void stopHttpServer() { serverRunning = false; }
    public static boolean isServerRunning() { return serverRunning; }
    public static void broadcastSync(String json) {}
    public static String getLocalIpAddress(Context context) { return "127.0.0.1"; }
}
