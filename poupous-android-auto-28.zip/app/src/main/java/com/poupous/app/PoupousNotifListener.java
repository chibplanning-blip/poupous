package com.poupous.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.HashMap;

public class PoupousNotifListener extends NotificationListenerService {
    public static final HashMap<String, Notification.Action> reponses = new HashMap<>();
    public static PoupousNotifListener inst = null;

    @Override
    public void onListenerConnected() {
        inst = this;
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals("com.poupous.app") || pkg.equals("android")) return;
        Notification n = sbn.getNotification();
        Bundle ex = n.extras;
        CharSequence tit = ex.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence txt = ex.getCharSequence(Notification.EXTRA_TEXT);
        if (txt == null || txt.length() == 0) return;
        String cle = sbn.getKey();
        Notification.Action act = actionReponse(n);
        if (act != null) {
            if (reponses.size() > 60) reponses.clear();
            reponses.put(cle, act);
        }
        MainActivity.pushNotif("{app:" + js(pkg) + ",titre:" + js(String.valueOf(tit)) +
            ",texte:" + js(String.valueOf(txt)) + ",cle:" + js(cle) + ",repondable:" + (act != null) + "}");
    }

    private static Notification.Action actionReponse(Notification n) {
        Notification.Action[] acts = n.actions;
        if (acts == null) return null;
        for (Notification.Action a : acts) {
            if (a != null && a.getRemoteInputs() != null && a.getRemoteInputs().length > 0) return a;
        }
        return null;
    }

    public static String repondre(Context ctx, String cle, String texte) {
        Notification.Action a = reponses.get(cle);
        if (a == null) return "pas-de-bouton-repondre";
        try {
            RemoteInput[] rrs = a.getRemoteInputs();
            Intent i = new Intent();
            Bundle b = new Bundle();
            for (RemoteInput rr : rrs) b.putCharSequence(rr.getResultKey(), texte);
            RemoteInput.addResultsToIntent(rrs, i, b);
            a.actionIntent.send(ctx, 0, i);
            return "ok";
        } catch (PendingIntent.CanceledException e) {
            return "echec-" + e.getMessage();
        }
    }

    private static String js(String s) {
        if (s == null) return "''";
        s = s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", "");
        return "'" + s + "'";
    }
}
