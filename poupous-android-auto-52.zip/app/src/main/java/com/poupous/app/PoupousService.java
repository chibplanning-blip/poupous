package com.poupous.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class PoupousService extends Service implements LocationListener {
    private static PowerManager.WakeLock wakeLock = null;
    private static boolean serverRunning = false;
    public static boolean running = false;
    
    private LocationManager lm;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private Handler handler;
    private boolean isListeningActive = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::WakeLock");
                wakeLock.acquire(12 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) {}

        try {
            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    tts.setLanguage(Locale.FRANCE);
                }
            });
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : "";
        
        createNotificationChannel();
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, "poupous_fond");
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
                .setContentTitle("Poupous Actif")
                .setContentText("Surveillance et écoute continue en arrière-plan...")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION |
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            startForeground(1, notification, serviceType);
        } else if (Build.VERSION.SDK_INT >= 29) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            startForeground(1, notification, serviceType);
        } else {
            startForeground(1, notification);
        }

        if ("START_GEOFENCE".equals(action)) {
            startGeofencing();
        } else {
            startBackgroundListening();
        }

        running = true;
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel channel = new NotificationChannel(
                        "poupous_fond",
                        "Poupous Service Arrière-plan",
                        NotificationManager.IMPORTANCE_LOW
                );
                channel.setDescription("Maintient Poupous actif en continu sans se faire tuer par Android");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    private void startGeofencing() {
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 20000, 10, this, Looper.getMainLooper());
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 20000, 10, this, Looper.getMainLooper());
            }
        } catch (Exception ignored) {}
    }

    private void startBackgroundListening() {
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        if (!prefs.getBoolean("wake_running", true)) {
            stopSelf();
            return;
        }

        handler.post(() -> {
            try {
                if (speechRecognizer != null) {
                    try { speechRecognizer.destroy(); } catch (Exception ignored) {}
                }
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(PoupousService.this);
                speechRecognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) { isListeningActive = true; }
                    @Override public void onBeginningOfSpeech() {}
                    @Override public void onRmsChanged(float rmsdB) {}
                    @Override public void onBufferReceived(byte[] buffer) {}
                    @Override public void onEndOfSpeech() {}
                    @Override public void onError(int error) {
                        isListeningActive = false;
                        // Tentative de reprise immédiate en cas d'erreur ou de timeout
                        handler.postDelayed(PoupousService.this::startBackgroundListening, 800);
                    }
                    @Override
                    public void onResults(Bundle results) {
                        isListeningActive = false;
                        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches != null && !matches.isEmpty()) {
                            String spoken = matches.get(0);
                            if (spoken != null && !spoken.trim().isEmpty()) {
                                handleVoiceCommand(spoken);
                            }
                        }
                        handler.postDelayed(PoupousService.this::startBackgroundListening, 300);
                    }
                    @Override public void onPartialResults(Bundle partialResults) {}
                    @Override public void onEvent(int eventType, Bundle params) {}
                });

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
                speechRecognizer.startListening(intent);
            } catch (Exception e) {
                handler.postDelayed(PoupousService.this::startBackgroundListening, 2000);
            }
        });
    }

    private void handleVoiceCommand(String command) {
        String lower = command.toLowerCase(Locale.ROOT);
        if (lower.contains("poupous") || lower.contains("pupus") || lower.contains("pouce pouce")) {
            if (tts != null) {
                tts.speak("Oui, je t'écoute !", TextToSpeech.QUEUE_FLUSH, null, "poupous_ack");
            }
            
            Intent launchIntent = new Intent(this, MainActivity.class);
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            launchIntent.putExtra("reveil_after", command);
            startActivity(launchIntent);
        }
    }

    @Override
    public void onLocationChanged(Location loc) {
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        if (!prefs.getBoolean("geofence_running", false)) return;
        try {
            boolean hasItems = false;
            String shoppingListJson = prefs.getString("data_shopping_list", "[]");
            JSONArray shoppingList = new JSONArray(shoppingListJson);
            if (shoppingList.length() > 0) {
                hasItems = true;
            } else {
                String storeDataStr = prefs.getString("store_management_data", "{}");
                JSONObject storeData = new JSONObject(storeDataStr);
                JSONObject lists = storeData.optJSONObject("lists");
                if (lists != null) {
                    java.util.Iterator<String> keys = lists.keys();
                    while (keys.hasNext()) {
                        JSONArray arr = lists.optJSONArray(keys.next());
                        if (arr != null && arr.length() > 0) {
                            hasItems = true;
                            break;
                        }
                    }
                }
            }

            if (!hasItems) return;

            JSONArray stores = new JSONArray(prefs.getString("geofence_stores", "[]"));
            for (int i = 0; i < stores.length() && i < 100; i++) {
                JSONObject s = stores.getJSONObject(i);
                double tLat = s.getDouble("lat");
                double tLon = s.getDouble("lon");
                float[] dist = new float[1];
                Location.distanceBetween(loc.getLatitude(), loc.getLongitude(), tLat, tLon, dist);
                if (dist[0] <= 500.0f) {
                    String storeKey = "notified_store_" + s.optString("id", String.valueOf(i));
                    boolean alreadyNotified = prefs.getBoolean(storeKey, false);
                    if (!alreadyNotified) {
                        prefs.edit().putBoolean(storeKey, true).apply();
                        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                        Notification.Builder b;
                        if (Build.VERSION.SDK_INT >= 26) {
                            b = new Notification.Builder(this, "poupous_fond");
                        } else {
                            b = new Notification.Builder(this);
                        }
                        Notification notif = b
                                .setContentTitle("🛒 Poupous : Liste de courses !")
                                .setContentText("Vous êtes à moins de 500m de " + s.optString("nom", "ce magasin") + " et vous avez des articles à acheter.")
                                .setSmallIcon(android.R.drawable.ic_dialog_map)
                                .setAutoCancel(true)
                                .setDefaults(Notification.DEFAULT_ALL)
                                .build();
                        if (nm != null) nm.notify(100 + i, notif);
                    }
                } else {
                    if (dist[0] > 600.0f) {
                        String storeKey = "notified_store_" + s.optString("id", String.valueOf(i));
                        if (prefs.getBoolean(storeKey, false)) {
                            prefs.edit().putBoolean(storeKey, false).apply();
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Redémarrage automatique du service si l'application est swipée/tuée par l'utilisateur
        try {
            Intent restartServiceIntent = new Intent(getApplicationContext(), this.getClass());
            restartServiceIntent.setPackage(getPackageName());
            PendingIntent restartServicePendingIntent = PendingIntent.getService(
                    getApplicationContext(), 1, restartServiceIntent,
                    Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_ONE_SHOT : PendingIntent.FLAG_ONE_SHOT
            );
            AlarmManager alarmService = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
            if (alarmService != null) {
                alarmService.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 1000, restartServicePendingIntent);
            }
        } catch (Exception ignored) {}
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        running = false;
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (Exception ignored) {}
        }
        if (speechRecognizer != null) {
            try { speechRecognizer.destroy(); } catch (Exception ignored) {}
        }
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {}
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
        
        // Relance automatique préventive si le service est détruit par le système
        try {
            SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
            if (prefs.getBoolean("wake_running", false)) {
                Intent restartIntent = new Intent(this, PoupousService.class);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(restartIntent);
                } else {
                    startService(restartIntent);
                }
            }
        } catch (Exception ignored) {}

        super.onDestroy();
    }

    public static void startHttpServer(Context context) { serverRunning = true; }
    public static void stopHttpServer() { serverRunning = false; }
    public static boolean isServerRunning() { return serverRunning; }
    public static void broadcastSync(String json) {}
    public static String getLocalIpAddress(Context context) { return "127.0.0.1"; }
}
