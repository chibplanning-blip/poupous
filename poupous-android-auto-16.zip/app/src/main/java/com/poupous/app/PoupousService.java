package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.NetworkInterface;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class PoupousService extends Service {
    static final String CHANNEL_ID = "poupous_service";
    PowerManager.WakeLock wakeLock;

    static ServerSocket serverSocket;
    static volatile boolean serverRunning = false;
    static Socket activeClientSocket = null;

    LocationManager locationManager;
    LocationListener locationListener;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous Persistant & Mains Libres", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::PersistentWakeLock");
            wakeLock.acquire();
        }

        // Surveillance GPS active pour le Géofencing des magasins (Aldi, Lidl, Colruyt, Action)
        startLocationMonitoring();
        
        // Démarrage automatique du serveur web local de synchronisation PC
        startHttpServer(this);

        // Lancement de la vérification automatique des mises à jour APK GitHub en arrière-plan
        startAutoUpdateChecker();
    }

    void startLocationMonitoring() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null) return;

            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    checkGeofences(location.getLatitude(), location.getLongitude());
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };

            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10, locationListener);
                Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last != null) checkGeofences(last.getLatitude(), last.getLongitude());
            }
        } catch (Exception ignored) {}
    }

    void checkGeofences(double lat, double lon) {
        // Coordonnées fictives ou dynamiques de magasins cibles proches (Aldi, Lidl, Colruyt, Action)
        // Vérification de la distance <= 500m et notification/alerte vocale
        try {
            SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
            JSONObject storeData = new JSONObject(prefs.getString("store_management_data", "{\"stores\":[\"Aldi\",\"Lidl\",\"Colruyt\",\"Action\"],\"lists\":{},\"halal\":true}"));
            JSONArray stores = storeData.optJSONArray("stores");
            
            // Exemple de points de référence (ex: centres commerciaux / magasins type)
            // Déclenchement d'une alerte si proche de l'un d'eux
            double[][] storeCoords = {
                {50.8503, 4.3517, 0}, // Aldi type
                {50.8520, 4.3550, 1}, // Lidl type
                {50.8480, 4.3480, 2}, // Colruyt type
                {50.8550, 4.3600, 3}  // Action type
            };

            for (double[] sc : storeCoords) {
                double targetLat = sc[0];
                double targetLon = sc[1];
                int idx = (int) sc[2];
                String storeName = stores != null && idx < stores.length() ? stores.optString(idx, "Magasin") : "Magasin";

                double earthRadius = 6371000;
                double dLat = Math.toRadians(targetLat - lat);
                double dLon = Math.toRadians(targetLon - lon);
                double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                           Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(targetLat)) *
                           Math.sin(dLon / 2) * Math.sin(dLon / 2);
                double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                double distance = earthRadius * c;

                if (distance <= 500.0) {
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    Notification.Builder b = new Notification.Builder(this);
                    if (Build.VERSION.SDK_INT >= 26) b.setChannelId(CHANNEL_ID);
                    b.setContentTitle("Géofencing : Moins de 500m de " + storeName + " !")
                     .setContentText("Poussez votre liste de courses halal sans viande !")
                     .setSmallIcon(android.R.drawable.ic_menu_mylocation);
                    if (nm != null) nm.notify(100 + idx, b.build());
                }
            }
        } catch (Exception ignored) {}
    }

    void startAutoUpdateChecker() {
        new Thread(() -> {
            try {
                while (serverRunning || wakeLock != null) {
                    Thread.sleep(30 * 60 * 1000); // Vérification toutes les 30 minutes
                    URL url = new URL("https://api.github.com/repos/" + MainActivity.REPO + "/releases/latest");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(15000);
                    c.setRequestProperty("User-Agent", "Poupous");
                    if (c.getResponseCode() == 200) {
                        String json = readStream(c.getInputStream());
                        JSONObject obj = new JSONObject(json);
                        JSONArray assets = obj.optJSONArray("assets");
                        if (assets != null) {
                            for (int i = 0; i < assets.length(); i++) {
                                JSONObject asset = assets.optJSONObject(i);
                                if (asset != null) {
                                    String name = asset.optString("name", "");
                                    if (name.endsWith(".apk")) {
                                        String downloadUrl = asset.optString("browser_download_url", "");
                                        if (!downloadUrl.isEmpty()) {
                                            // Téléchargement automatique de la dernière APK prête sur GitHub
                                            downloadAndInstallApk(downloadUrl);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    void downloadAndInstallApk(String downloadUrl) {
        try {
            File apk = new File(new File(getCacheDir(), "partage"), "poupous-auto-update.apk");
            apk.getParentFile().mkdirs();
            HttpURLConnection c = (HttpURLConnection) new URL(downloadUrl).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setRequestProperty("User-Agent", "Poupous");
            if (c.getResponseCode() == 200) {
                InputStream in = c.getInputStream();
                OutputStream out = new java.io.FileOutputStream(apk);
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();

                // Notification persistante de disponibilité de mise à jour avec intention d'installation
                Intent installIntent = new Intent(Intent.ACTION_VIEW);
                installIntent.setDataAndType(FilesProvider.uriFor(apk), "application/vnd.android.package-archive");
                installIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
                PendingIntent pi = PendingIntent.getActivity(this, 0, installIntent, flagsPending);

                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                Notification.Builder b = new Notification.Builder(this);
                if (Build.VERSION.SDK_INT >= 26) b.setChannelId(CHANNEL_ID);
                b.setContentTitle("Mise à jour Poupous disponible !")
                 .setContentText("Appuyez pour installer la dernière version GitHub.")
                 .setSmallIcon(android.R.drawable.stat_sys_download_done)
                 .setContentIntent(pi);
                if (nm != null) nm.notify(999, b.build());
            }
        } catch (Exception ignored) {}
    }

    static String readStream(InputStream in) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line).append("\n");
        r.close();
        return sb.toString();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, flagsPending);

        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous Assistant")
               .setContentText("Actif, écoute du mot clé, géofencing magasins & synchronisation en cours.")
               .setSmallIcon(android.R.drawable.ic_btn_speak_now)
               .setContentIntent(pendingIntent);
        
        Notification notification = builder.build();
        startForeground(1, notification);
        return START_STICKY;
    }

    public static void startHttpServer(final Context context) {
        if (serverRunning) return;
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(8080);
                serverRunning = true;
                while (serverRunning) {
                    try {
                        Socket socket = serverSocket.accept();
                        activeClientSocket = socket;
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String line = reader.readLine();
                        if (line == null) {
                            socket.close();
                            continue;
                        }

                        SharedPreferences prefs = context.getSharedPreferences("poupous", MODE_PRIVATE);
                        String payload = prefs.getString("sync_shared_payload", "{\"lists\":{},\"messages\":[]}");

                        if (line.contains("POST /update")) {
                            StringBuilder sb = new StringBuilder();
                            int contentLength = 0;
                            String l;
                            while ((l = reader.readLine()) != null && !l.isEmpty()) {
                                if (l.toLowerCase().startsWith("content-length:")) {
                                    try {
                                        contentLength = Integer.parseInt(l.substring(15).trim());
                                    } catch (Exception ignored) {}
                                }
                            }
                            char[] buf = new char[contentLength];
                            int read = 0;
                            while (read < contentLength) {
                                int r = reader.read(buf, read, contentLength - read);
                                if (r == -1) break;
                                read += r;
                            }
                            String body = new String(buf, 0, read);
                            if (!body.isEmpty()) {
                                prefs.edit().putString("sync_shared_payload", body).apply();
                            }
                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n{\"status\":\"ok\"}";
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        } else {
                            String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Poupous PC Sync</title>" +
                                    "<style>body{background:#030712;color:#f8fafc;font-family:sans-serif;padding:40px;max-width:800px;margin:0 auto;}" +
                                    "h1{color:#00e5ff;margin-bottom:10px;} textarea{width:100%;height:350px;background:#111827;color:#f8fafc;border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:16px;font-size:15px;outline:none;}" +
                                    "button{background:#00e5ff;color:#000;font-weight:bold;padding:14px 28px;border:none;border-radius:12px;cursor:pointer;margin-top:16px;font-size:16px;box-shadow:0 0 20px rgba(0,229,255,0.3);}" +
                                    "</style></head><body><h1>Poupous - Synchronisation PC</h1>" +
                                    "<p style='color:#94a3b8;margin-bottom:20px;'>Modifiez vos listes et données ci-dessous. La synchronisation avec le téléphone est instantanée :</p>" +
                                    "<textarea id='data'>" + payload + "</textarea><br>" +
                                    "<button onclick='save()'>Enregistrer et synchroniser</button>" +
                                    "<script>" +
                                    "function save(){" +
                                    "fetch('/update',{method:'POST',headers:{'Content-Type':'application/json'},body:document.getElementById('data').value})" +
                                    ".then(r=>alert('Données synchronisées avec succès !'));" +
                                    "}" +
                                    "</script></body></html>";

                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n" + html;
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        }
                        socket.close();
                    } catch (Exception e) {
                        break;
                    }
                }
            } catch (Exception e) {
                serverRunning = false;
            }
        }).start();
    }

    public static void stopHttpServer() {
        serverRunning = false;
        try {
            if (serverSocket != null) serverSocket.close();
            if (activeClientSocket != null) activeClientSocket.close();
        } catch (Exception ignored) {}
    }

    public static boolean isServerRunning() {
        return serverRunning;
    }

    public static void broadcastSync(String json) {}

    public static String getLocalIpAddress(Context context) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        boolean isIPv4 = sAddr.indexOf(':') < 0;
                        if (isIPv4) return sAddr;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }

    @Override
    public void onDestroy() {
        stopHttpServer();
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) {}
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
