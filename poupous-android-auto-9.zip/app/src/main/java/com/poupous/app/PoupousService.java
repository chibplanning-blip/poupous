package com.poupous.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

public class PoupousService extends Service implements LocationListener {
    static final String CHANNEL_ID = "poupous_service";
    static final String ALERT_CHANNEL_ID = "poupous_alerts";
    PowerManager.WakeLock wakeLock;
    LocationManager locationManager;

    // Coordonnées approximatives fictives ou configurées des magasins (Aldi, Lidl, Colruyt, Action)
    // Dans une implémentation réelle, on pourrait utiliser des POI, ici on simule la détection de proximité
    static final double[][] STORES = {
        {50.8503, 4.3517, 500.0, "Aldi"},
        {50.8450, 4.3570, 500.0, "Lidl"},
        {50.8600, 4.3400, 500.0, "Colruyt"},
        {50.8400, 4.3600, 500.0, "Action"}
    };

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous actif", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(channel);

            NotificationChannel alertChannel = new NotificationChannel(ALERT_CHANNEL_ID, "Proximité Magasin", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(alertChannel);
        }

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::Wakelock");
            wakeLock.acquire();
        }

        // Initialisation de la géolocalisation pour le service en arrière-plan
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 30000, 50, this);
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 30000, 50, this);
            }
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous actif")
               .setContentText("Surveillance de position et écoute en arrière-plan.")
               .setSmallIcon(android.R.drawable.ic_btn_speak_now);
        startForeground(1, builder.build());
        return START_STICKY;
    }

    @Override
    public void onLocationChanged(Location location) {
        evaluateProximity(this, location.getLatitude(), location.getLongitude());
    }

    public static void evaluateProximity(Context context, double lat, double lon) {
        try {
            SharedPreferences prefs = context.getSharedPreferences("poupous", Context.MODE_PRIVATE);
            long lastAlert = prefs.getLong("last_store_alert", 0);
            // Éviter de spammer les notifications (cooldown 30 minutes)
            if (System.currentTimeMillis() - lastAlert < 30 * 60 * 1000) return;

            String rawShop = prefs.getString("shopping_lists", "{}");
            JSONObject shopsObj = new JSONObject(rawShop);

            for (double[] store : STORES) {
                double sLat = store[0];
                double sLon = store[1];
                double maxDist = store[2]; // 500 mètres
                String storeName = "";
                if (store[3] == 0.0) storeName = "Aldi"; // Simplification tableau double
                // Pour éviter les ambiguïtés de tableau double, stockons proprement ou faisons une vérification simple
            }

            // Vérification simplifiée avec les noms connus
            String[] storeNames = {"Aldi", "Lidl", "Colruyt", "Action"};
            double[][] coords = {
                {50.8503, 4.3517},
                {50.8450, 4.3570},
                {50.8600, 4.3400},
                {50.8400, 4.3600}
            };

            for (int i = 0; i < storeNames.length; i++) {
                float[] results = new float[1];
                Location.distanceBetween(lat, lon, coords[i][0], coords[i][1], results);
                float distanceInMeters = results[0];

                if (distanceInMeters <= 500.0f) {
                    String storeName = storeNames[i];
                    JSONArray items = shopsObj.optJSONArray(storeName);
                    if (items != null && items.length() > 0) {
                        // Envoyer une notification avec la liste de courses
                        StringBuilder sb = new StringBuilder();
                        for (int j = 0; j < items.length(); j++) {
                            JSONObject item = items.optJSONObject(j);
                            if (item != null) {
                                sb.append("• ").append(item.optString("name")).append("\n");
                            }
                        }

                        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                        Notification.Builder b = new Notification.Builder(context);
                        if (Build.VERSION.SDK_INT >= 26) b.setChannelId(ALERT_CHANNEL_ID);
                        b.setContentTitle("Vous êtes près de " + storeName + " !")
                         .setContentText("Voici votre liste de courses.")
                         .setStyle(new Notification.BigTextStyle().bigText(sb.toString()))
                         .setAutoCancel(true)
                         .setSmallIcon(android.R.drawable.ic_dialog_info);

                        nm.notify(2 + i, b.build());
                        prefs.edit().putLong("last_store_alert", System.currentTimeMillis()).apply();
                        break;
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}

    @Override
    public void onDestroy() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
