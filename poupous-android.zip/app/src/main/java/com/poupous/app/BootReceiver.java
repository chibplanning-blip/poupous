package com.poupous.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BootReceiver extends BroadcastReceiver {

    static final String REPO = "chibplanning-blip/poupous";
    static final String UPDATE_URL = "https://raw.githubusercontent.com/" + REPO + "/HEAD/app.html";
    static final String ACTION_BACKGROUND_UPDATE = "com.poupous.app.ACTION_BACKGROUND_UPDATE";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();

        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            SharedPreferences prefs = context.getSharedPreferences("poupous", Context.MODE_PRIVATE);
            if (prefs.getBoolean("wake_running", false)) {
                Intent serviceIntent = new Intent(context, PoupousService.class);
                if (Build.VERSION.SDK_INT >= 26) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            }
            if (prefs.getBoolean("background_update_scheduled", false)) {
                scheduleNextUpdate(context);
            }
        } else if (ACTION_BACKGROUND_UPDATE.equals(action)) {
            performBackgroundUpdate(context);
            scheduleNextUpdate(context);
        }
    }

    public static void scheduleNextUpdate(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(context, BootReceiver.class);
            intent.setAction(ACTION_BACKGROUND_UPDATE);
            int flags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pi = PendingIntent.getBroadcast(context, 777, intent, flags);
            if (am != null) {
                long triggerAt = System.currentTimeMillis() + (6 * 60 * 60 * 1000L); // Toutes les 6 heures
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                }
                context.getSharedPreferences("poupous", Context.MODE_PRIVATE).edit().putBoolean("background_update_scheduled", true).apply();
            }
        } catch (Exception ignored) {}
    }

    public static void cancelNextUpdate(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(context, BootReceiver.class);
            intent.setAction(ACTION_BACKGROUND_UPDATE);
            int flags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pi = PendingIntent.getBroadcast(context, 777, intent, flags);
            if (am != null) {
                am.cancel(pi);
            }
            context.getSharedPreferences("poupous", Context.MODE_PRIVATE).edit().putBoolean("background_update_scheduled", false).apply();
        } catch (Exception ignored) {}
    }

    void performBackgroundUpdate(Context context) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                if (c.getResponseCode() != 200) return;
                String remote = readStream(c.getInputStream());
                if (!remote.contains("POUPOUS_APP")) return;

                File appFile = new File(context.getFilesDir(), "app.html");
                File backupFile = new File(context.getFilesDir(), "app_backup.html");
                String current = readFile(appFile);

                if (versionOf(remote) > versionOf(current)) {
                    if (current != null) writeFile(backupFile, current);
                    if (writeFile(appFile, remote)) {
                        context.getSharedPreferences("poupous", Context.MODE_PRIVATE).edit().putBoolean("upgradePending", true).apply();
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    static int versionOf(String html) {
        if (html == null) return -1;
        Matcher m = Pattern.compile("POUPOUS_VERSION\\s*=\\s*(\\d+)").matcher(html);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    static String readStream(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    static String readFile(File f) {
        try { return readStream(new FileInputStream(f)); } catch (Exception e) { return null; }
    }

    static boolean writeFile(File f, String text) {
        try {
            File tmp = new File(f.getAbsolutePath() + ".tmp");
            OutputStream out = new FileOutputStream(tmp);
            out.write(text.getBytes(StandardCharsets.UTF_8));
            out.close();
            return tmp.renameTo(f);
        } catch (Exception e) {
            return false;
        }
    }
}
