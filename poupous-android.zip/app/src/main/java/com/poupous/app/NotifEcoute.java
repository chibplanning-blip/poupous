package com.poupous.app;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Surveille les notifications de WhatsApp, WhatsApp Business et des SMS.
 * Si le nom/pseudo enregistré par l'utilisateur apparaît dans un message
 * (même venant d'une conversation mise en sourdine, puisque l'appli source
 * poste quand même la notification en silence), Poupous affiche sa propre
 * notification pour prévenir l'utilisateur.
 */
public class NotifEcoute extends NotificationListenerService {

    static final Set<String> PAQUETS_SURVEILLES = new HashSet<>(Arrays.asList(
            "com.whatsapp",
            "com.whatsapp.w4b",
            "com.google.android.apps.messaging",
            "com.android.mms",
            "com.samsung.android.messaging"
    ));

    static String simplifie(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || sbn.getPackageName() == null || !PAQUETS_SURVEILLES.contains(sbn.getPackageName())) return;

            SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
            String mention = prefs.getString("mention", "");
            if (mention == null || mention.trim().isEmpty()) return;
            String cible = simplifie(mention.replace("@", "").trim());
            if (cible.isEmpty()) return;

            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;
            Bundle extras = n.extras;

            StringBuilder texte = new StringBuilder();
            CharSequence titre = extras.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence corps = extras.getCharSequence(Notification.EXTRA_TEXT);
            if (titre != null) texte.append(titre).append(' ');
            if (corps != null) texte.append(corps).append(' ');

            CharSequence[] lignes = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (lignes != null) for (CharSequence l : lignes) if (l != null) texte.append(l).append(' ');

            Parcelable[] messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (messages != null) {
                for (Parcelable p : messages) {
                    if (!(p instanceof Bundle)) continue;
                    Bundle m = (Bundle) p;
                    CharSequence t = m.getCharSequence("text");
                    if (t != null) texte.append(t).append(' ');
                }
            }

            String contenu = simplifie(texte.toString());
            if (!contenu.contains(cible)) return;

            String titrePoupous = "Mentionné" + (titre != null ? " · " + titre : "");
            String textePoupous = corps != null ? corps.toString() : texte.toString().trim();
            Rappel.montrer(this, titrePoupous, textePoupous);
        } catch (Exception ignored) {
        }
    }
}
