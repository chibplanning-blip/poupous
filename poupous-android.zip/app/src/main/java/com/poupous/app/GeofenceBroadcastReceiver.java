package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.location.Location;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        SharedPreferences prefs = context.getSharedPreferences("poupous", Context.MODE_PRIVATE);
        
        // Vérifier si la liste de courses contient au moins un article
        String shoppingListJson = prefs.getString("shopping_list_items", "[]");
        boolean hasItems = false;
        try {
            JSONArray arr = new JSONArray(shoppingListJson);
            hasItems = arr.length() > 0;
        } catch (Exception ignored) {}

        if (!hasItems) {
            return; // Pas d'articles, pas de notification
        }

        // Récupérer l'action de géorepérage (simulation ou native)
        String storeName = intent.getStringExtra("store_name");
        if (storeName == null || storeName.isEmpty()) {
            storeName = "Supermarché";
        }

        triggerProximityNotification(context, storeName);
        
        // Déclencher un rechargement des zones si nécessaire (déplacement significatif)
        double lastLat = Double.longBitsToDouble(prefs.getLong("last_geofence_lat", 0));
        double lastLon = Double.longBitsToDouble(prefs.getLong("last_geofence_lon", 0));
        
        // Obtenir la position actuelle et recharger si déplacement > 10 km
        new Thread(() -> {
            try {
                // Requête Overpass pour rafraîchir les supermarchés de Belgique autour de la position actuelle
                double lat = lastLat != 0 ? lastLat : 50.8503;
                double lon = lastLon != 0 ? lastLon : 4.3517;
                
                String overpassQuery = "[out:json];node(around:20000," + lat + "," + lon + ")[shop=supermarket];out body 100;";
                String urlString = "https://overpass-api.de/api/interpreter?data=" + java.net.URLEncoder.encode(overpassQuery, "UTF-8");
                HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "Poupous");
                if (c.getResponseCode() == 200) {
                    InputStream in = c.getInputStream();
                    String text = in == null ? "" : readStream(in);
                    prefs.edit().putString("geofence_stores_cache", text).apply();
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void triggerProximityNotification(Context context, String storeName) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                String channelId = "poupous_geofence_alert";
                if (Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel channel = new NotificationChannel(
                            channelId,
                            "Alertes Proximité Magasins",
                            NotificationManager.IMPORTANCE_HIGH
                    );
                    channel.setDescription("Alerte lorsqu'un supermarché est proche et que la liste de courses n'est pas vide");
                    channel.enableVibration(true);
                    nm.createNotificationChannel(channel);
                }

                Notification.Builder builder;
                if (Build.VERSION.SDK_INT >= 26) {
                    builder = new Notification.Builder(context, channelId);
                } else {
                    builder = new Notification.Builder(context);
                }

                Notification notif = builder
                        .setContentTitle("🛒 Supermarché proche : "  + storeName)
                        .setContentText("Vous êtes à moins de 500m ! Votre liste de courses contient des articles.")
                        .setSmallIcon(android.R.drawable.ic_dialog_map)
                        .setAutoCancel(true)
                        .setPriority(Notification.PRIORITY_HIGH)
                        .setDefaults(Notification.DEFAULT_ALL)
                        .build();

                nm.notify((int) System.currentTimeMillis(), notif);
            }
        } catch (Exception ignored) {}
    }

    private static String readStream(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }
}
