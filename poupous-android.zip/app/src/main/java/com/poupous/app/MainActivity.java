package com.poupous.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static final String UPDATE_URL = "https://raw.githubusercontent.com/__REPO__/HEAD/app.html";
    static final String API_URL = "https://api.anthropic.com/v1/messages";

    WebView web;
    TextToSpeech tts;
    volatile boolean ttsReady = false;
    SpeechRecognizer recognizer;
    final Handler main = new Handler(Looper.getMainLooper());
    SharedPreferences prefs;
    String pendingListenId = null;

    // ------------------------------------------------------------------ cycle de vie

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("poupous", MODE_PRIVATE);

        web = new WebView(this);
        web.setBackgroundColor(0xFF070D1A);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                checkStartedAfterUpgrade();
            }
        });
        web.addJavascriptInterface(new Bridge(), "Poupous");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.FRANCE);
                ttsReady = true;
                applyVoice();
            }
        });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { ttsFinished(id); }
            @Override public void onError(String id) { ttsFinished(id); }
            @Override public void onStop(String id, boolean interrupted) { ttsFinished(id); }
        });

        ensureAppFile();
        loadApp();
        checkForUpdate();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (recognizer != null) recognizer.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        js("window.__onBack ? window.__onBack() : null");
    }

    // ------------------------------------------------------------------ fichiers de l'appli

    File appFile() { return new File(getFilesDir(), "app.html"); }
    File backupFile() { return new File(getFilesDir(), "app_backup.html"); }

    static int versionOf(String html) {
        if (html == null) return -1;
        Matcher m = Pattern.compile("POUPOUS_VERSION\\s*=\\s*(\\d+)").matcher(html);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    static String readStream(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    static String readFile(File f) {
        try { return readStream(new FileInputStream(f)); } catch (Exception e) { return null; }
    }

    static boolean writeFile(File f, String text) {
        try {
            File tmp = new File(f.getAbsolutePath() + ".tmp");
            OutputStream out = new FileOutputStream(tmp);
            out.write(text.getBytes(StandardCharsets.UTF_8));
            out.close();
            return tmp.renameTo(f);
        } catch (Exception e) {
            return false;
        }
    }

    String assetApp() {
        try { return readStream(getAssets().open("app.html")); } catch (Exception e) { return null; }
    }

    void ensureAppFile() {
        String asset = assetApp();
        String current = readFile(appFile());
        if (current == null || versionOf(asset) > versionOf(current)) {
            if (current != null) writeFile(backupFile(), current);
            if (asset != null) writeFile(appFile(), asset);
        }
    }

    void loadApp() {
        web.loadUrl("file://" + appFile().getAbsolutePath());
    }

    void checkForUpdate() {
        if (UPDATE_URL.contains("__" + "REPO" + "__")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return;
                String remote = readStream(c.getInputStream());
                String current = readFile(appFile());
                if (!remote.contains("POUPOUS_APP")) return;
                if (versionOf(remote) > versionOf(current)) {
                    if (current != null) writeFile(backupFile(), current);
                    if (writeFile(appFile(), remote)) {
                        prefs.edit().putBoolean("upgradePending", true).apply();
                        main.post(() -> {
                            Toast.makeText(this, "Poupous a été mis à jour", Toast.LENGTH_SHORT).show();
                            loadApp();
                        });
                    }
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    // Si une nouvelle version ne démarre pas, on remet la précédente.
    void checkStartedAfterUpgrade() {
        if (!prefs.getBoolean("upgradePending", false)) return;
        main.postDelayed(() -> web.evaluateJavascript("!!window.__poupousOK", value -> {
            if ("true".equals(value)) {
                prefs.edit().putBoolean("upgradePending", false).apply();
            } else if (backupFile().exists()) {
                String backup = readFile(backupFile());
                prefs.edit().putBoolean("upgradePending", false).putBoolean("rolledBack", true).apply();
                if (backup != null && writeFile(appFile(), backup)) {
                    Toast.makeText(this, "La nouvelle version ne démarrait pas : retour à la précédente", Toast.LENGTH_LONG).show();
                    loadApp();
                }
            }
        }), 7000);
    }

    // ------------------------------------------------------------------ utilitaires

    void js(String code) {
        main.post(() -> web.evaluateJavascript(code, null));
    }

    static String q(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    // ------------------------------------------------------------------ voix

    void applyVoice() {
        if (!ttsReady) return;
        tts.setSpeechRate(prefs.getFloat("rate", 1.0f));
        tts.setPitch(prefs.getFloat("pitch", 1.0f));
        String name = prefs.getString("voice", "");
        if (!name.isEmpty() && tts.getVoices() != null) {
            for (Voice v : tts.getVoices()) {
                if (v.getName().equals(name)) { tts.setVoice(v); return; }
            }
        }
        tts.setLanguage(Locale.FRANCE);
    }

    void ttsFinished(String id) {
        if (id != null && !id.endsWith("_part")) js("window.__ttsDone && window.__ttsDone(" + q(id) + ")");
    }

    // ------------------------------------------------------------------ écoute

    void startListening(String id) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.__listenDone && window.__listenDone(" + q(id) + ",'','unsupported')");
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            boolean finished = false;

            void finish(String text, String err) {
                if (finished) return;
                finished = true;
                js("window.__listenDone && window.__listenDone(" + q(id) + "," + q(text) + "," + q(err) + ")");
            }

            @Override public void onReadyForSpeech(Bundle params) { js("window.__listenReady && window.__listenReady()"); }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int eventType, Bundle params) { }

            @Override
            public void onPartialResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) js("window.__listenPartial && window.__listenPartial(" + q(r.get(0)) + ")");
            }

            @Override
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                finish(r != null && !r.isEmpty() ? r.get(0) : "", "");
            }

            @Override
            public void onError(int code) {
                String err;
                if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) err = "no-speech";
                else if (code == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) err = "not-allowed";
                else if (code == SpeechRecognizer.ERROR_CLIENT) err = "aborted";
                else err = "error-" + code;
                finish("", err);
            }
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != 1 || pendingListenId == null) return;
        String id = pendingListenId;
        pendingListenId = null;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening(id);
        else js("window.__listenDone && window.__listenDone(" + q(id) + ",'','not-allowed')");
    }

    // ------------------------------------------------------------------ pont JavaScript

    class Bridge {

        @JavascriptInterface
        public boolean hasKey() {
            return !prefs.getString("apiKey", "").isEmpty();
        }

        @JavascriptInterface
        public void setKey(String key) {
            prefs.edit().putString("apiKey", key == null ? "" : key.trim()).apply();
        }

        @JavascriptInterface
        public String get(String name) {
            return prefs.getString("data_" + name, "");
        }

        @JavascriptInterface
        public void set(String name, String value) {
            prefs.edit().putString("data_" + name, value).apply();
        }

        @JavascriptInterface
        public int appVersion() {
            return versionOf(readFile(appFile()));
        }

        @JavascriptInterface
        public boolean wasRolledBack() {
            boolean r = prefs.getBoolean("rolledBack", false);
            if (r) prefs.edit().putBoolean("rolledBack", false).apply();
            return r;
        }

        @JavascriptInterface
        public void claude(String id, String body) {
            new Thread(() -> {
                int status = 0;
                String text;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(API_URL).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(600000);
                    c.setDoOutput(true);
                    c.setRequestProperty("content-type", "application/json");
                    c.setRequestProperty("anthropic-version", "2023-06-01");
                    c.setRequestProperty("x-api-key", prefs.getString("apiKey", ""));
                    OutputStream out = c.getOutputStream();
                    out.write(body.getBytes(StandardCharsets.UTF_8));
                    out.close();
                    status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    text = in == null ? "" : readStream(in);
                } catch (Exception e) {
                    text = "network: " + e.getMessage();
                }
                js("window.__claudeDone && window.__claudeDone(" + q(id) + "," + status + "," + q(text) + ")");
            }).start();
        }

        @JavascriptInterface
        public void speak(String id, String text) {
            if (!ttsReady || text == null || text.trim().isEmpty()) {
                ttsFinished(id);
                return;
            }
            int max = Math.max(500, TextToSpeech.getMaxSpeechInputLength() - 100);
            ArrayList<String> parts = new ArrayList<>();
            String rest = text;
            while (rest.length() > max) {
                int cut = rest.lastIndexOf(". ", max);
                if (cut < max / 2) cut = max;
                parts.add(rest.substring(0, cut + 1));
                rest = rest.substring(cut + 1);
            }
            parts.add(rest);
            for (int i = 0; i < parts.size(); i++) {
                String uid = i == parts.size() - 1 ? id : id + "_" + i + "_part";
                tts.speak(parts.get(i), TextToSpeech.QUEUE_ADD, null, uid);
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void setVoice(float rate, float pitch, String name) {
            prefs.edit().putFloat("rate", rate).putFloat("pitch", pitch).putString("voice", name == null ? "" : name).apply();
            main.post(MainActivity.this::applyVoice);
        }

        @JavascriptInterface
        public String voices() {
            JSONArray arr = new JSONArray();
            try {
                if (ttsReady && tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) {
                        if (v.getLocale() != null && "fr".equals(v.getLocale().getLanguage())) arr.put(v.getName());
                    }
                }
            } catch (Exception ignored) {
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void listen(String id) {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    pendingListenId = id;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                } else {
                    startListening(id);
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            main.post(() -> { if (recognizer != null) recognizer.stopListening(); });
        }

        @JavascriptInterface
        public void cancelListening() {
            main.post(() -> { if (recognizer != null) recognizer.cancel(); });
        }

        @JavascriptInterface
        public String getApp() {
            String s = readFile(appFile());
            return s == null ? "" : s;
        }

        @JavascriptInterface
        public String saveApp(String html) {
            if (html == null || !html.contains("POUPOUS_APP")) return "invalid";
            String current = readFile(appFile());
            if (current != null) writeFile(backupFile(), current);
            if (!writeFile(appFile(), html)) return "write-failed";
            prefs.edit().putBoolean("upgradePending", true).apply();
            main.postDelayed(MainActivity.this::loadApp, 300);
            return "ok";
        }

        @JavascriptInterface
        public String restoreBackup() {
            String backup = readFile(backupFile());
            if (backup == null) return "none";
            String current = readFile(appFile());
            if (!writeFile(appFile(), backup)) return "write-failed";
            if (current != null) writeFile(backupFile(), current);
            main.postDelayed(MainActivity.this::loadApp, 300);
            return "ok";
        }

        @JavascriptInterface
        public void quit() {
            main.post(MainActivity.this::finish);
        }
    }
}
