package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public class NotifListener extends NotificationListenerService {

    static final String PKG_WHATSAPP = "com.whatsapp";
    static final String PKG_WHATSAPP_BIZ = "com.whatsapp.w4b";
    static final int MAX_MESSAGES = 50;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            String pkg = sbn.getPackageName();
            if (!PKG_WHATSAPP.equals(pkg) && !PKG_WHATSAPP_BIZ.equals(pkg)) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;
            Bundle extras = n.extras;
            String expediteur = str(extras.getCharSequence(Notification.EXTRA_TITLE));
            String texte = str(extras.getCharSequence(Notification.EXTRA_TEXT));
            if (expediteur.isEmpty() && texte.isEmpty()) return;

            SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
            
            // Filtrage ciblé WhatsApp : @hamed ou prénom configuré (ou par défaut hamed)
            String userName = prefs.getString("user_name", "hamed").trim().toLowerCase(Locale.ROOT);
            String fullTextCheck = (expediteur + " " + texte).toLowerCase(Locale.ROOT);
            
            boolean isMentioned = fullTextCheck.contains("@hamed") || 
                                  fullTextCheck.contains(userName) || 
                                  fullTextCheck.contains("hamed");

            JSONArray liste;
            try {
                liste = new JSONArray(prefs.getString("whatsappMsgs", "[]"));
            } catch (Exception e) {
                liste = new JSONArray();
            }

            JSONObject msg = new JSONObject();
            msg.put("expediteur", expediteur);
            msg.put("texte", texte);
            msg.put("horodatage", System.currentTimeMillis());
            msg.put("mentionne", isMentioned);
            liste.put(msg);

            while (liste.length() > MAX_MESSAGES) liste.remove(0);

            prefs.edit().putString("whatsappMsgs", liste.toString()).apply();

            if (isMentioned) {
                triggerPoupousAlert(expediteur, texte);
            }
        } catch (Exception ignored) {
        }
    }

    private void triggerPoupousAlert(String expediteur, String texte) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                String channelId = "poupous_whatsapp_mention";
                if (Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel channel = new NotificationChannel(
                            channelId,
                            "Mentions WhatsApp Poupous",
                            NotificationManager.IMPORTANCE_HIGH
                    );
                    channel.setDescription("Alerte spéciale pour les mentions WhatsApp de Poupous");
                    channel.enableVibration(true);
                    AudioAttributes audioAttributes = new AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .build();
                    channel.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, audioAttributes);
                    nm.createNotificationChannel(channel);
                }

                Notification.Builder builder;
                if (Build.VERSION.SDK_INT >= 26) {
                    builder = new Notification.Builder(this, channelId);
                } else {
                    builder = new Notification.Builder(this);
                }

                Notification notif = builder
                        .setContentTitle("🚨 Mention WhatsApp : " + expediteur)
                        .setContentText(texte)
                        .setSmallIcon(android.R.drawable.stat_notify_chat)
                        .setAutoCancel(true)
                        .setPriority(Notification.PRIORITY_HIGH)
                        .setDefaults(Notification.DEFAULT_ALL)
                        .build();

                nm.notify((int) System.currentTimeMillis(), notif);
            }
        } catch (Exception ignored) {}
    }

    private String str(CharSequence c) {
        return c == null ? "" : c.toString();
    }
}
