package com.poupous.app;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

public class NotifListener extends NotificationListenerService {

    static final String PKG_WHATSAPP = "com.whatsapp";
    static final String PKG_WHATSAPP_BIZ = "com.whatsapp.w4b";
    static final int MAX_MESSAGES = 50;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            String pkg = sbn.getPackageName();
            if (!PKG_WHATSAPP.equals(pkg) && !PKG_WHATSAPP_BIZ.equals(pkg)) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;
            Bundle extras = n.extras;
            String expediteur = str(extras.getCharSequence(Notification.EXTRA_TITLE));
            String texte = str(extras.getCharSequence(Notification.EXTRA_TEXT));
            if (expediteur.isEmpty() && texte.isEmpty()) return;

            SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
            JSONArray liste;
            try {
                liste = new JSONArray(prefs.getString("whatsappMsgs", "[]"));
            } catch (Exception e) {
                liste = new JSONArray();
            }

            JSONObject msg = new JSONObject();
            msg.put("expediteur", expediteur);
            msg.put("texte", texte);
            msg.put("horodatage", System.currentTimeMillis());
            liste.put(msg);

            while (liste.length() > MAX_MESSAGES) {
                JSONArray newListe = new JSONArray();
                for (int i = 1; i < liste.length(); i++) {
                    newListe.put(liste.get(i));
                }
                liste = newListe;
            }

            prefs.edit().putString("whatsappMsgs", liste.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private String str(CharSequence c) {
        return c == null ? "" : c.toString();
    }
}
