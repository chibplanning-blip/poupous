package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;

public class PoupousService extends Service implements LocationListener {
    public static boolean running = false;
    private static boolean serverRunning = false;
    private LocationManager lm;

    @Override public android.os.IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        String action = i != null ? i.getAction() : "";
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel("poupous_fond", "Poupous en arrière-plan", NotificationManager.IMPORTANCE_LOW);
        c.setShowBadge(false); 
        if (nm != null) nm.createNotificationChannel(c);
        
        Notification.Builder builder = new Notification.Builder(this, "poupous_fond")
            .setContentTitle("Poupous est actif")
            .setContentText("Service de fond actif.")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setOngoing(true);

        if (Build.VERSION.SDK_INT >= 34) {
            int serviceType = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            startForeground(1, builder.build(), serviceType);
        } else {
            startForeground(1, builder.build());
        }

        if ("START_GEOFENCE".equals(action)) {
            lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            try {
                if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000, 50, this, Looper.getMainLooper());
                }
            } catch (Exception ignored) {}
        }

        running = true;
        return START_STICKY;
    }

    @Override public void onLocationChanged(Location loc) {
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        if (!prefs.getBoolean("geofence_running", false)) return;
        try {
            JSONArray stores = new JSONArray(prefs.getString("geofence_stores", "[]"));
            for (int i = 0; i < stores.length(); i++) {
                JSONObject s = stores.getJSONObject(i);
                double tLat = s.getDouble("lat");
                double tLon = s.getDouble("lon");
                float[] dist = new float[1];
                Location.distanceBetween(loc.getLatitude(), loc.getLongitude(), tLat, tLon, dist);
                if (dist[0] < 500) {
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    Notification.Builder b = new Notification.Builder(this, "poupous_fond")
                            .setContentTitle("Proximité Poupous")
                            .setContentText("Vous êtes à moins de 500m de " + s.optString("nom"))
                            .setSmallIcon(android.R.drawable.ic_dialog_map);
                    nm.notify(2, b.build());
                }
            }
        } catch (Exception ignored) {}
    }

    @Override public void onDestroy() {
        if (lm != null) lm.removeUpdates(this);
        running = false;
        super.onDestroy();
    }

    public static void startHttpServer(Context context) { serverRunning = true; }
    public static void stopHttpServer() { serverRunning = false; }
    public static boolean isServerRunning() { return serverRunning; }
    public static void broadcastSync(String json) {}
    public static String getLocalIpAddress(Context context) { return "127.0.0.1"; }
}
