package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.util.Locale;

public class PoupousService extends Service {
    private static PowerManager.WakeLock wakeLock = null;
    private static WifiManager.WifiLock wifiLock = null;
    public static boolean running = false;
    private static boolean serverRunning = false;
    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        String action = i != null ? i.getAction() : null;

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel("poupous_fond", "Poupous en arrière-plan", NotificationManager.IMPORTANCE_LOW);
        c.setShowBadge(false); 
        if (nm != null) {
            nm.createNotificationChannel(c);
        }
        
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, "poupous_fond");
        } else {
            builder = new Notification.Builder(this);
        }
        
        Notification n = builder
            .setContentTitle("Poupous est actif")
            .setContentText("Mode persistant en veille, réseau et radar actif.")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setOngoing(true).build();

        if (Build.VERSION.SDK_INT >= 34) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            startForeground(1, n, serviceType);
        } else if (Build.VERSION.SDK_INT >= 29) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            startForeground(1, n, serviceType);
        } else {
            startForeground(1, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "poupous:wakelock");
                wakeLock.setReferenceCounted(false);
            }
        }
        if (wakeLock != null && !wakeLock.isHeld()) {
            wakeLock.acquire();
        }

        if (wifiLock == null) {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                if (Build.VERSION.SDK_INT >= 29) {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "poupous:wifilock");
                } else {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL, "poupous:wifilock");
                }
                wifiLock.setReferenceCounted(false);
            }
        }
        if (wifiLock != null && !wifiLock.isHeld()) {
            wifiLock.acquire();
        }

        if ("START_RADAR".equals(action) || "START_LOCATION".equals(action)) {
            startRadarUpdates();
        } else if ("STOP_LOCATION".equals(action)) {
            stopRadarUpdates();
        }

        running = true;
        return START_STICKY;
    }

    private void startRadarUpdates() {
        try {
            if (locationManager == null) {
                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            }
            if (locationManager != null && locationListener == null) {
                locationListener = new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {
                        checkSupermarketsRadar(location.getLatitude(), location.getLongitude());
                    }
                    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                    @Override public void onProviderEnabled(String provider) {}
                    @Override public void onProviderDisabled(String provider) {}
                };
                if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10, locationListener, Looper.getMainLooper());
                    }
                    if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 10, locationListener, Looper.getMainLooper());
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void stopRadarUpdates() {
        try {
            if (locationManager != null && locationListener != null) {
                locationManager.removeUpdates(locationListener);
                locationListener = null;
            }
        } catch (Exception ignored) {}
    }

    private void checkSupermarketsRadar(double lat, double lon) {
        new Thread(() -> {
            try {
                String query = "[out:json][timeout:10];(node[\"shop\"=\"supermarket\"](around:1000," + lat + "," + lon + ");way[\"shop\"=\"supermarket\"](around:1000," + lat + "," + lon + "););out body;";
                String urlStr = "https://overpass-api.de/api/interpreter?data=" + java.net.URLEncoder.encode(query, "UTF-8");
                HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                if (conn.getResponseCode() == 200) {
                    String jsonResp = readStream(conn.getInputStream());
                    JSONObject overpassObj = new JSONObject(jsonResp);
                    JSONArray elements = overpassObj.optJSONArray("elements");
                    if (elements != null) {
                        for (int i = 0; i < elements.length(); i++) {
                            JSONObject el = elements.optJSONObject(i);
                            if (el != null) {
                                JSONObject tags = el.optJSONObject("tags");
                                String name = tags != null ? tags.optString("name", "Supermarché") : "Supermarché";
                                String nameLower = name.toLowerCase(Locale.ROOT);
                                if (nameLower.contains("aldi") || nameLower.contains("lidl") || nameLower.contains("colruyt") || nameLower.contains("action") || nameLower.contains("intermarché") || nameLower.contains("intermarche")) {
                                    double eLat = el.has("lat") ? el.optDouble("lat", lat) : (el.has("center") ? el.optJSONObject("center").optDouble("lat", lat) : lat);
                                    double eLon = el.has("lon") ? el.optDouble("lon", lon) : (el.has("center") ? el.optJSONObject("center").optDouble("lon", lon) : lon);
                                    
                                    double earthRadius = 6371000;
                                    double dLat = Math.toRadians(eLat - lat);
                                    double dLon = Math.toRadians(eLon - lon);
                                    double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(eLat)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
                                    double distance = earthRadius * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));

                                    if (distance <= 500.0) {
                                        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
                                        String lastNotifiedStore = prefs.getString("last_notified_store", "");
                                        if (!lastNotifiedStore.equals(name + "_" + (int)distance)) {
                                            prefs.edit().putString("last_notified_store", name + "_" + (int)distance).apply();
                                            android.os.Handler h = new android.os.Handler(Looper.getMainLooper());
                                            h.post(() -> Toast.makeText(PoupousService.this, "Radar 500m : " + name + " à " + (int)distance + "m !", Toast.LENGTH_LONG).show());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private static String readStream(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    @Override public void onDestroy() {
        stopRadarUpdates();
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {}
        }
        if (wifiLock != null && wifiLock.isHeld()) {
            try {
                wifiLock.release();
            } catch (Exception ignored) {}
        }
        running = false;
        super.onDestroy();
    }

    public static void start(Context c) { 
        Intent intent = new Intent(c, PoupousService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            c.startForegroundService(intent);
        } else {
            c.startService(intent);
        }
    }
    
    public static void stop(Context c) { 
        c.stopService(new Intent(c, PoupousService.class)); 
    }

    public static void startHttpServer(Context context) {
        serverRunning = true;
    }

    public static void stopHttpServer() {
        serverRunning = false;
    }

    public static boolean isServerRunning() {
        return serverRunning;
    }

    public static void broadcastSync(String json) {
    }

    public static String getLocalIpAddress(Context context) {
        try {
            WifiManager wm = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                int ipInt = wm.getConnectionInfo().getIpAddress();
                if (ipInt != 0) {
                    return InetAddress.getByAddress(ByteBuffer.allocate(4).putInt(Integer.reverseBytes(ipInt)).array()).getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }
}
