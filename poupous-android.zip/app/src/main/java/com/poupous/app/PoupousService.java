package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

public class PoupousService extends Service {
    static final String CHANNEL_ID = "poupous_service";

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous actif", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous écoute")
               .setContentText("L'application Poupous tourne en arrière-plan.")
               .setSmallIcon(android.R.drawable.ic_btn_speak_now);
        startForeground(1, builder.build());
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
