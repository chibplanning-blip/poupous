package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.PowerManager;

public class PoupousService extends Service {
    private static PowerManager.WakeLock lock = null;
    public static boolean running = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel("poupous_fond", "Poupous en arrière-plan", NotificationManager.IMPORTANCE_LOW);
        c.setShowBadge(false); nm.createNotificationChannel(c);
        Notification n = new Notification.Builder(this, "poupous_fond")
            .setContentTitle("Poupous est actif")
            .setContentText("Je continue à travailler écran éteint et en arrière-plan.")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setOngoing(true).build();
        startForeground(1, n);
        if (lock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "poupous:veille");
            lock.setReferenceCounted(false);
        }
        lock.acquire();
        running = true;
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (lock != null && lock.isHeld()) lock.release();
        running = false;
        super.onDestroy();
    }

    public static void start(Context c) { c.startService(new Intent(c, PoupousService.class)); }
    public static void stop(Context c) { c.stopService(new Intent(c, PoupousService.class)); }
}
