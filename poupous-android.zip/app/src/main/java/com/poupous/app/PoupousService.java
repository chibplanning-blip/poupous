package com.poupous.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

public class PoupousService extends Service {
    static final String CHANNEL_ID = "poupous_service";
    PowerManager.WakeLock wakeLock;

    static ServerSocket serverSocket;
    static volatile boolean serverRunning = false;
    static Socket activeClientSocket = null;

    LocationManager locationManager;
    LocationListener locationListener;

    static final String[][] STORES = {
            {"Aldi", "50.8503", "4.3517"},
            {"Lidl", "50.8513", "4.3527"},
            {"Colruyt", "50.8493", "4.3507"},
            {"Action", "50.8523", "4.3537"}
    };

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous Persistant & GPS", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::PersistentWakeLock");
            wakeLock.acquire();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getStringExtra("action") : null;
        if ("start_location".equals(action)) {
            startLocationUpdates();
        } else if ("stop_location".equals(action)) {
            stopLocationUpdates();
        }

        Intent notificationIntent = new Intent(this, MainActivity.class);
        int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, flagsPending);

        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous Assistant")
               .setContentText("Mode persistant, GPS et synchronisation en cours.")
               .setSmallIcon(android.R.drawable.ic_btn_speak_now)
               .setContentIntent(pendingIntent);
        
        Notification notification = builder.build();
        startForeground(1, notification);
        return START_STICKY;
    }

    void startLocationUpdates() {
        if (locationManager != null) return;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) return;

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                checkStoresProximity(location.getLatitude(), location.getLongitude());
            }
            @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
            @Override public void onProviderEnabled(String provider) {}
            @Override public void onProviderDisabled(String provider) {}
        };

        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10.0f, locationListener);
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 10.0f, locationListener);
                Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last == null) last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (last != null) {
                    checkStoresProximity(last.getLatitude(), last.getLongitude());
                }
            }
        } catch (Exception ignored) {}
    }

    void stopLocationUpdates() {
        if (locationManager != null && locationListener != null) {
            try {
                locationManager.removeUpdates(locationListener);
            } catch (Exception ignored) {}
            locationManager = null;
            locationListener = null;
        }
    }

    void checkStoresProximity(double lat, double lon) {
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        prefs.edit().putFloat("last_lat", (float) lat).putFloat("last_lon", (float) lon).apply();

        String storeDataStr = prefs.getString("store_management_data", "{\"lists\":{}}");
        JSONObject storeData;
        JSONObject lists = new JSONObject();
        try {
            storeData = new JSONObject(storeDataStr);
            lists = storeData.optJSONObject("lists");
            if (lists == null) lists = new JSONObject();
        } catch (Exception ignored) {}

        for (String[] store : STORES) {
            String name = store[0];
            double tLat = Double.parseDouble(store[1]);
            double tLon = Double.parseDouble(store[2]);

            double earthRadius = 6371000;
            double dLat = Math.toRadians(tLat - lat);
            double dLon = Math.toRadians(tLon - lon);
            double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                       Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(tLat)) *
                       Math.sin(dLon / 2) * Math.sin(dLon / 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            double distance = earthRadius * c;

            if (distance <= 500.0) {
                String lastApproached = prefs.getString("last_store_approached", "");
                if (!lastApproached.equals(name)) {
                    prefs.edit().putString("last_store_approached", name).apply();
                    
                    JSONArray listArr = lists.optJSONArray(name);
                    StringBuilder sb = new StringBuilder("Liste de courses : ");
                    if (listArr != null && listArr.length() > 0) {
                        for (int i = 0; i < listArr.length(); i++) {
                            sb.append(listArr.optString(i)).append(i < listArr.length() - 1 ? ", " : "");
                        }
                    } else {
                        sb.append("Aucun article spécifique.");
                    }

                    sendProximityNotification(name, sb.toString());
                }
            }
        }
    }

    void sendProximityNotification(String storeName, String contentText) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Intent notificationIntent = new Intent(this, MainActivity.class);
        int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, flagsPending);

        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Vous approchez de " + storeName + " (-500m)")
               .setContentText(contentText)
               .setSmallIcon(android.R.drawable.ic_menu_mylocation)
               .setAutoCancel(true)
               .setContentIntent(pendingIntent);

        nm.notify(storeName.hashCode(), builder.build());
    }

    public static void startHttpServer(final Context context) {
        if (serverRunning) return;
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(8080);
                serverRunning = true;
                while (serverRunning) {
                    try {
                        Socket socket = serverSocket.accept();
                        activeClientSocket = socket;
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String line = reader.readLine();
                        if (line == null) {
                            socket.close();
                            continue;
                        }

                        SharedPreferences prefs = context.getSharedPreferences("poupous", MODE_PRIVATE);
                        String payload = prefs.getString("sync_shared_payload", "{\"lists\":{},\"messages\":[]}");

                        if (line.contains("POST /update")) {
                            StringBuilder sb = new StringBuilder();
                            int contentLength = 0;
                            String l;
                            while ((l = reader.readLine()) != null && !l.isEmpty()) {
                                if (l.toLowerCase().startsWith("content-length:")) {
                                    try {
                                        contentLength = Integer.parseInt(l.substring(15).trim());
                                    } catch (Exception ignored) {}
                                }
                            }
                            char[] buf = new char[contentLength];
                            int read = 0;
                            while (read < contentLength) {
                                int r = reader.read(buf, read, contentLength - read);
                                if (r == -1) break;
                                read += r;
                            }
                            String body = new String(buf, 0, read);
                            if (!body.isEmpty()) {
                                prefs.edit().putString("sync_shared_payload", body).apply();
                            }
                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n{\"status\":\"ok\"}";
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        } else {
                            String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Poupous PC Sync</title>" +
                                    "<style>body{background:#030712;color:#f8fafc;font-family:sans-serif;padding:40px;max-width:800px;margin:0 auto;}" +
                                    "h1{color:#00e5ff;margin-bottom:10px;} textarea{width:100%;height:350px;background:#111827;color:#f8fafc;border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:16px;font-size:15px;outline:none;}" +
                                    "button{background:#00e5ff;color:#000;font-weight:bold;padding:14px 28px;border:none;border-radius:12px;cursor:pointer;margin-top:16px;font-size:16px;box-shadow:0 0 20px rgba(0,229,255,0.3);}" +
                                    "</style></head><body><h1>Poupous - Synchronisation PC</h1>" +
                                    "<p style='color:#94a3b8;margin-bottom:20px;'>Modifiez vos listes et données ci-dessous. La synchronisation avec le téléphone est instantanée :</p>" +
                                    "<textarea id='data'>" + payload + "</textarea><br>" +
                                    "<button onclick='save()'>Enregistrer et synchroniser</button>" +
                                    "<script>" +
                                    "function save(){" +
                                    "fetch('/update',{method:'POST',headers:{'Content-Type':'application/json'},body:document.getElementById('data').value})" +
                                    ".then(r=>alert('Données synchronisées avec succès !'));" +
                                    "}" +
                                    "</script></body></html>";

                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n" + html;
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        }
                        socket.close();
                    } catch (Exception e) {
                        break;
                    }
                }
            } catch (Exception e) {
                serverRunning = false;
            }
        }).start();
    }

    public static void stopHttpServer() {
        serverRunning = false;
        try {
            if (serverSocket != null) serverSocket.close();
            if (activeClientSocket != null) activeClientSocket.close();
        } catch (Exception ignored) {}
    }

    public static boolean isServerRunning() {
        return serverRunning;
    }

    public static void broadcastSync(String json) {}

    public static String getLocalIpAddress(Context context) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        boolean isIPv4 = sAddr.indexOf(':') < 0;
                        if (isIPv4) return sAddr;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }

    @Override
    public void onDestroy() {
        stopLocationUpdates();
        stopHttpServer();
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
