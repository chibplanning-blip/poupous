package com.poupous.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PoupousService extends Service implements LocationListener {
    static final String CHANNEL_ID = "poupous_service";
    PowerManager.WakeLock wakeLock;
    LocationManager locationManager;
    SharedPreferences prefs;
    boolean notifiedRecently = false;

    // Magasins simulés (Aldi, Lidl, Colruyt, Action) avec coordonnées fictives ou proches
    static class StoreInfo {
        String name;
        double lat;
        double lon;
        StoreInfo(String n, double la, double lo) { name = n; lat = la; lon = lo; }
    }

    final List<StoreInfo> knownStores = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("poupous", MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous Géolocalisation Courses", NotificationManager.IMPORTANCE_DEFAULT);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::Wakelock");
            wakeLock.acquire();
        }

        // Magasins de référence (Aldi, Lidl, Colruyt, Action)
        knownStores.add(new StoreInfo("Aldi", 48.8566, 2.3522));
        knownStores.add(new StoreInfo("Lidl", 48.8600, 2.3400));
        knownStores.add(new StoreInfo("Colruyt", 48.8500, 2.3600));
        knownStores.add(new StoreInfo("Action", 48.8550, 2.3450));

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        startLocationUpdates();
    }

    void startLocationUpdates() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                if (locationManager != null) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10.0f, this);
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 10.0f, this);
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        updateNotification("Poupous actif - Recherche des magasins Aldi, Lidl, Colruyt, Action...");
        return START_STICKY;
    }

    void updateNotification(String text) {
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous Courses & Magasins")
               .setContentText(text)
               .setSmallIcon(android.R.drawable.ic_menu_mylocation);
        startForeground(1, builder.build());
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location == null) return;
        boolean filterHalal = prefs.getBoolean("filter_halal", false);
        boolean filterNetPromo = prefs.getBoolean("filter_net_promo", false);

        StoreInfo nearestStore = null;
        float minDistance = 500.0f; // 500m

        for (StoreInfo store : knownStores) {
            float[] results = new float[1];
            Location.distanceBetween(location.getLatitude(), location.getLongitude(), store.lat, store.lon, results);
            if (results[0] <= minDistance) {
                minDistance = results[0];
                nearestStore = store;
            }
        }

        if (nearestStore != null) {
            triggerShoppingNotification(nearestStore.name, filterHalal, filterNetPromo);
        }
    }

    void triggerShoppingNotification(String storeName, boolean filterHalal, boolean filterNetPromo) {
        try {
            String rawItems = prefs.getString("shopping_items", "[]");
            JSONArray arr = new JSONArray(rawItems);
            
            List<String> storeItems = new ArrayList<>();
            List<String> otherItems = new ArrayList<>();

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String name = obj.optString("name", "");
                String store = obj.optString("store", "Aldi");
                boolean halal = obj.optBoolean("halal", false);
                boolean promo = obj.optBoolean("netPromo", false);

                // Application des filtres
                if (filterHalal && !halal) continue;
                if (filterNetPromo && !promo) continue;

                String displayStr = name + (halal ? " [Halal]" : "") + (promo ? " [Promo]" : "");
                if (store.equalsIgnoreCase(storeName)) {
                    storeItems.add(displayStr);
                } else {
                    otherItems.add("[" + store + "] " + displayStr);
                }
            }

            // Tri par magasin : articles du magasin détecté en premier
            List<String> sortedList = new ArrayList<>();
            sortedList.addAll(storeItems);
            sortedList.addAll(otherItems);

            if (sortedList.isEmpty()) return;

            StringBuilder sb = new StringBuilder("Proche de " + storeName + " ! Courses : ");
            for (int i = 0; i < sortedList.size(); i++) {
                sb.append(sortedList.get(i));
                if (i < sortedList.size() - 1) sb.append(", ");
            }

            String notificationText = sb.toString();
            updateNotification(notificationText);

            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                Notification.Builder builder = new Notification.Builder(this);
                if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
                builder.setContentTitle("Magasin détecté : " + storeName)
                       .setContentText(notificationText)
                       .setStyle(new Notification.BigTextStyle().bigText(notificationText))
                       .setAutoCancel(true)
                       .setSmallIcon(android.R.drawable.ic_dialog_info);
                nm.notify(2, builder.build());
            }
        } catch (Exception ignored) {}
    }

    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}

    @Override
    public void onDestroy() {
        if (locationManager != null) {
            try {
                locationManager.removeUpdates(this);
            } catch (Exception ignored) {}
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
