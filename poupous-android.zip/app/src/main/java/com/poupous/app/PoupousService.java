package com.poupous.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class PoupousService extends Service {
    static final String CHANNEL_ID = "poupous_service";
    PowerManager.WakeLock wakeLock;

    static ServerSocket serverSocket;
    static volatile boolean serverRunning = false;
    static Socket activeClientSocket = null;
    static ScheduledExecutorService workerExecutor = null;
    static volatile boolean workerRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous Persistant & Mains Libres", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::PersistentWakeLock");
            wakeLock.acquire();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, flagsPending);

        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous Assistant")
               .setContentText("Mode persistant, mains libres et synchronisation actifs.")
               .setSmallIcon(android.R.drawable.ic_btn_speak_now)
               .setContentIntent(pendingIntent);
        
        Notification notification = builder.build();
        startForeground(1, notification);
        return START_STICKY;
    }

    public static void startWorker(final Context context) {
        if (workerRunning) return;
        workerRunning = true;
        workerExecutor = Executors.newSingleThreadScheduledExecutor();
        workerExecutor.scheduleAtFixedRate(() -> {
            if (!workerRunning) return;
            try {
                // Simulation ou vérification GPS continue en arrière-plan
                LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
                if (lm != null && (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (loc == null) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (loc != null) {
                        checkStores(context, loc.getLatitude(), loc.getLongitude());
                    }
                }
            } catch (Exception ignored) {}
        }, 0, 30, TimeUnit.SECONDS);
    }

    public static void stopWorker() {
        workerRunning = false;
        if (workerExecutor != null) {
            workerExecutor.shutdownNow();
            workerExecutor = null;
        }
    }

    public static void checkStores(Context context, double lat, double lon) {
        // Magasins surveillés : Aldi, Lidl, Colruyt, Action (coordonnées approximatives ou cibles géographiques de démonstration / géofencing intelligent)
        // Coordonnées factices de test si aucune position réelle proche, ou calcul direct
        // Coordonnées de test en Belgique/France ou comparaison avec les listes
        double[][] storesCoords = {
            {50.8503, 4.3517, 500.0, "Aldi"},
            {50.8450, 4.3570, 500.0, "Lidl"},
            {50.8600, 4.3400, 500.0, "Colruyt"},
            {50.8350, 4.3650, 500.0, "Action"}
        };

        for (double[] store : storesCoords) {
            double targetLat = store[0];
            double targetLon = store[1];
            double maxDist = store[2];
            String storeName = store[3];

            double earthRadius = 6371000;
            double dLat = Math.toRadians(targetLat - lat);
            double dLon = Math.toRadians(targetLon - lon);
            double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                       Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(targetLat)) *
                       Math.sin(dLon / 2) * Math.sin(dLon / 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            double distance = earthRadius * c;

            if (distance <= maxDist) {
                sendHalalNotification(context, storeName);
                break;
            }
        }
    }

    static void sendHalalNotification(Context context, String storeName) {
        SharedPreferences prefs = context.getSharedPreferences("poupous", MODE_PRIVATE);
        String storeDataJson = prefs.getString("store_management_data", "{\"lists\":{}}");
        String shoppingItemsStr = "Liste vide";
        try {
            JSONObject data = new JSONObject(storeDataJson);
            JSONObject lists = data.optJSONObject("lists");
            if (lists != null) {
                JSONArray rawList = lists.optJSONArray(storeName);
                if (rawList != null && rawList.length() > 0) {
                    JSONArray halalNoMeat = new JSONArray();
                    String[] forbiddenKeywords = {"porc", "jambon", "lard", "bacon", "saucisson", "viande", "boeuf", "poulet", "agneau", "veau", "steak", "hache", "lardon", "gelatine porcine"};
                    for (int i = 0; i < rawList.length(); i++) {
                        String item = rawList.optString(i, "").toLowerCase(Locale.ROOT);
                        boolean ok = true;
                        for (String kw : forbiddenKeywords) {
                            if (item.contains(kw)) {
                                ok = false;
                                break;
                            }
                        }
                        if (ok) halalNoMeat.put(rawList.optString(i));
                    }
                    if (halalNoMeat.length() > 0) {
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < halalNoMeat.length(); i++) {
                            sb.append("• ").append(halalNoMeat.optString(i)).append(" ");
                        }
                        shoppingItemsStr = sb.toString();
                    } else {
                        shoppingItemsStr = "Aucun article halal sans viande dans la liste.";
                    }
                }
            }
        } catch (Exception ignored) {}

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("poupous_proximity", "Proximité Magasins Halal", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(channel);
        }

        Intent intent = new Intent(context, MainActivity.class);
        int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, flagsPending);

        Notification.Builder builder = new Notification.Builder(context);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId("poupous_proximity");
        builder.setContentTitle("Proche de " + storeName + " (< 500m)")
               .setContentText("Courses Halal sans viande : " + shoppingItemsStr)
               .setStyle(new Notification.BigTextStyle().bigText("Liste de courses Halal sans viande pour " + storeName + " :\n" + shoppingItemsStr))
               .setSmallIcon(android.R.drawable.ic_menu_compass)
               .setContentIntent(pendingIntent)
               .setAutoCancel(true);

        nm.notify(storeName.hashCode(), builder.build());
    }

    public static void downloadAndInstallBackground(Context context, String id, String urlStr) {
        new Thread(() -> {
            try {
                File shareDir = new File(context.getCacheDir(), "partage");
                shareDir.mkdirs();
                File apk = new File(shareDir, "poupous-mise-a-jour.apk");
                HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setConnectTimeout(20000);
                c.setReadTimeout(120000);
                c.setRequestProperty("User-Agent", "Poupous");
                int st = c.getResponseCode();
                if (st != 200) throw new Exception("HTTP " + st);
                InputStream in = c.getInputStream();
                OutputStream out = new FileOutputStream(apk);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                out.close();
                in.close();

                // Notifier que l'APK est téléchargé en arrière-plan
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel channel = new NotificationChannel("poupous_update", "Mises à jour APK", NotificationManager.IMPORTANCE_HIGH);
                    nm.createNotificationChannel(channel);
                }
                Intent intent = new Intent(context, MainActivity.class);
                int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
                PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, flagsPending);

                Notification.Builder builder = new Notification.Builder(context);
                if (Build.VERSION.SDK_INT >= 26) builder.setChannelId("poupous_update");
                builder.setContentTitle("Mise à jour Poupous téléchargée")
                       .setContentText("Appuyez pour installer la nouvelle version.")
                       .setSmallIcon(android.R.drawable.stat_sys_download_done)
                       .setContentIntent(pendingIntent)
                       .setAutoCancel(true);
                nm.notify(999, builder.build());

            } catch (Exception ignored) {}
        }).start();
    }

    public static void startHttpServer(final Context context) {
        if (serverRunning) return;
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(8080);
                serverRunning = true;
                while (serverRunning) {
                    try {
                        Socket socket = serverSocket.accept();
                        activeClientSocket = socket;
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String line = reader.readLine();
                        if (line == null) {
                            socket.close();
                            continue;
                        }

                        SharedPreferences prefs = context.getSharedPreferences("poupous", MODE_PRIVATE);
                        String payload = prefs.getString("sync_shared_payload", "{\"lists\":{},\"messages\":[]}");

                        if (line.contains("POST /update")) {
                            StringBuilder sb = new StringBuilder();
                            int contentLength = 0;
                            String l;
                            while ((l = reader.readLine()) != null && !l.isEmpty()) {
                                if (l.toLowerCase().startsWith("content-length:")) {
                                    try {
                                        contentLength = Integer.parseInt(l.substring(15).trim());
                                    } catch (Exception ignored) {}
                                }
                            }
                            char[] buf = new char[contentLength];
                            int read = 0;
                            while (read < contentLength) {
                                int r = reader.read(buf, read, contentLength - read);
                                if (r == -1) break;
                                read += r;
                            }
                            String body = new String(buf, 0, read);
                            if (!body.isEmpty()) {
                                prefs.edit().putString("sync_shared_payload", body).apply();
                            }
                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n{\"status\":\"ok\"}";
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        } else {
                            String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Poupous PC Sync</title>" +
                                    "<style>body{background:#030712;color:#f8fafc;font-family:sans-serif;padding:40px;max-width:800px;margin:0 auto;}" +
                                    "h1{color:#00e5ff;margin-bottom:10px;} textarea{width:100%;height:350px;background:#111827;color:#f8fafc;border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:16px;font-size:15px;outline:none;}" +
                                    "button{background:#00e5ff;color:#000;font-weight:bold;padding:14px 28px;border:none;border-radius:12px;cursor:pointer;margin-top:16px;font-size:16px;box-shadow:0 0 20px rgba(0,229,255,0.3);}" +
                                    "</style></head><body><h1>Poupous - Synchronisation PC</h1>" +
                                    "<p style='color:#94a3b8;margin-bottom:20px;'>Modifiez vos listes et données ci-dessous. La synchronisation avec le téléphone est instantanée :</p>" +
                                    "<textarea id='data'>" + payload + "</textarea><br>" +
                                    "<button onclick='save()'>Enregistrer et synchroniser</button>" +
                                    "<script>" +
                                    "function save(){" +
                                    "fetch('/update',{method:'POST',headers:{'Content-Type':'application/json'},body:document.getElementById('data').value})" +
                                    ".then(r=>alert('Données synchronisées avec succès !'));" +
                                    "}" +
                                    "</script></body></html>";

                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n" + html;
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        }
                        socket.close();
                    } catch (Exception e) {
                        break;
                    }
                }
            } catch (Exception e) {
                serverRunning = false;
            }
        }).start();
    }

    public static void stopHttpServer() {
        serverRunning = false;
        try {
            if (serverSocket != null) serverSocket.close();
            if (activeClientSocket != null) activeClientSocket.close();
        } catch (Exception ignored) {}
    }

    public static boolean isServerRunning() {
        return serverRunning;
    }

    public static void broadcastSync(String json) {}

    public static String getLocalIpAddress(Context context) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        boolean isIPv4 = sAddr.indexOf(':') < 0;
                        if (isIPv4) return sAddr;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }

    @Override
    public void onDestroy() {
        stopHttpServer();
        stopWorker();
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
