package com.poupous.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public class PoupousService extends Service implements LocationListener {
    static final String CHANNEL_ID = "poupous_service";
    static final String ALERT_CHANNEL_ID = "poupous_geofence_alerts";
    PowerManager.WakeLock wakeLock;
    LocationManager locationManager;
    SharedPreferences prefs;
    long lastAlertTime = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous actif", NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(channel);
                NotificationChannel alertChannel = new NotificationChannel(ALERT_CHANNEL_ID, "Rappels magasins", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(alertChannel);
            }
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::Wakelock");
            wakeLock.acquire();
        }
        startLocationUpdates();
    }

    void startLocationUpdates() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null) {
            try {
                boolean hasFine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                boolean hasCoarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                if (hasFine || hasCoarse) {
                    String provider = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER;
                    locationManager.requestLocationUpdates(provider, 15000, 20.0f, this);
                }
            } catch (SecurityException ignored) {
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous actif")
               .setContentText("Surveillance GPS et écoute en arrière-plan.")
               .setSmallIcon(android.R.drawable.ic_btn_speak_now)
               .setContentIntent(pendingIntent);
        startForeground(1, builder.build());
        return START_STICKY;
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location == null) return;
        long now = System.currentTimeMillis();
        if (now - lastAlertTime < 300000) return; // Éviter le spam (5 min)

        String json = prefs.getString("geofences_data", "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject store = arr.getJSONObject(i);
                double lat = store.getDouble("lat");
                double lon = store.getDouble("lon");
                String name = store.optString("name", "Magasin");
                JSONArray items = store.optJSONArray("items");
                if (items == null || items.length() == 0) continue;

                float[] results = new float[1];
                Location.distanceBetween(location.getLatitude(), location.getLongitude(), lat, lon, results);
                float distance = results[0];

                if (distance <= 500.0f) {
                    lastAlertTime = now;
                    StringBuilder sb = new StringBuilder("Vous arrivez près de " + name + ". N'oubliez pas d'acheter : ");
                    for (int j = 0; j < items.length(); j++) {
                        if (j > 0) sb.append(", ");
                        sb.append(items.getString(j));
                    }
                    String alertText = sb.toString();
                    sendGeofenceNotification(name, alertText);
                    break;
                }
            }
        } catch (Exception ignored) {
        }
    }

    void sendGeofenceNotification(String title, String message) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(ALERT_CHANNEL_ID);
        builder.setContentTitle("Rappel courses : " + title)
               .setContentText(message)
               .setStyle(new Notification.BigTextStyle().bigText(message))
               .setSmallIcon(android.R.drawable.stat_sys_warning)
               .setAutoCancel(true)
               .setContentIntent(pendingIntent);

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(2, builder.build());
        }
    }

    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}

    @Override
    public void onDestroy() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (SecurityException ignored) {}
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
