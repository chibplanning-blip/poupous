package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;

import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PoupousService extends Service implements LocationListener {
    private static PowerManager.WakeLock wakeLock = null;
    private static boolean serverRunning = false;
    public static boolean running = false;
    
    private LocationManager lm;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private Handler handler;
    private GeofencingClient geofencingClient;
    private PendingIntent geofencePendingIntent;
    private double lastGeofenceLat = 0.0;
    private double lastGeofenceLon = 0.0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::WakeLock");
                wakeLock.acquire(4 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) {}

        try {
            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    tts.setLanguage(Locale.FRANCE);
                }
            });
        } catch (Exception ignored) {}

        geofencingClient = LocationServices.getGeofencingClient(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : "";
        
        createNotificationChannel();
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, "poupous_fond");
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
                .setContentTitle("Poupous Actif")
                .setContentText("Écoute vocale et géorepérage intelligents actifs...")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION |
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            startForeground(1, notification, serviceType);
        } else if (Build.VERSION.SDK_INT >= 29) {
            int serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            startForeground(1, notification, serviceType);
        } else {
            startForeground(1, notification);
        }

        if ("START_GEOFENCE".equals(action) || "STOP_GEOFENCE".equals(action)) {
            handleGeofencingAction(action);
        } else {
            startBackgroundListening();
            startGeofenceLocationUpdates();
        }

        running = true;
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel channel = new NotificationChannel(
                        "poupous_fond",
                        "Poupous Service Arrière-plan",
                        NotificationManager.IMPORTANCE_LOW
                );
                channel.setDescription("Maintient Poupous actif en arrière-plan");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    private void startGeofenceLocationUpdates() {
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000, 1000, this, Looper.getMainLooper());
                Location lastLoc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (lastLoc == null) {
                    lastLoc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
                if (lastLoc != null) {
                    updateGeofencesAround(lastLoc.getLatitude(), lastLoc.getLongitude());
                } else {
                    updateGeofencesAround(50.8503, 4.3517);
                }
            }
        } catch (Exception ignored) {}
    }

    private void handleGeofencingAction(String action) {
        if ("START_GEOFENCE".equals(action)) {
            startGeofenceLocationUpdates();
        } else if ("STOP_GEOFENCE".equals(action)) {
            try {
                if (geofencingClient != null && geofencePendingIntent != null) {
                    geofencingClient.removeGeofences(geofencePendingIntent);
                }
            } catch (Exception ignored) {}
        }
    }

    @Override
    public void onLocationChanged(Location loc) {
        double lat = loc.getLatitude();
        double lon = loc.getLongitude();
        
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        prefs.edit()
             .putLong("last_geofence_lat", Double.doubleToRawLongBits(lat))
             .putLong("last_geofence_lon", Double.doubleToRawLongBits(lon))
             .apply();

        float[] dist = new float[1];
        if (lastGeofenceLat != 0.0 && lastGeofenceLon != 0.0) {
            Location.distanceBetween(lastGeofenceLat, lastGeofenceLon, lat, lon, dist);
            if (dist[0] > 5000) {
                updateGeofencesAround(lat, lon);
            }
        } else {
            updateGeofencesAround(lat, lon);
        }
    }

    private void updateGeofencesAround(double lat, double lon) {
        lastGeofenceLat = lat;
        lastGeofenceLon = lon;

        new Thread(() -> {
            try {
                String overpassQuery = "[out:json];node(around:20000," + lat + "," + lon + ")[shop=supermarket];out body 100;";
                String urlString = "https://overpass-api.de/api/interpreter?data=" + java.net.URLEncoder.encode(overpassQuery, "UTF-8");
                HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "Poupous");
                
                if (c.getResponseCode() == 200) {
                    InputStream in = c.getInputStream();
                    String text = in == null ? "" : readStream(in);
                    JSONObject root = new JSONObject(text);
                    JSONArray elements = root.optJSONArray("elements");
                    
                    if (elements != null && elements.length() > 0) {
                        List<Geofence> geofenceList = new ArrayList<>();
                        
                        for (int i = 0; i < Math.min(elements.length(), 100); i++) {
                            JSONObject el = elements.getJSONObject(i);
                            long id = el.optLong("id");
                            double sLat = el.optDouble("lat");
                            double sLon = el.optDouble("lon");
                            JSONObject tags = el.optJSONObject("tags");
                            String name = tags != null ? tags.optString("name", "Supermarché") : "Supermarché";
                            
                            geofenceList.add(new Geofence.Builder()
                                    .setRequestId("store_" + id + "_" + name)
                                    .setCircularRegion(sLat, sLon, 500f)
                                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_DWELL)
                                    .setLoiteringDelay(30000)
                                    .build());
                        }

                        if (!geofenceList.isEmpty()) {
                            try {
                                GeofencingRequest request = new GeofencingRequest.Builder()
                                        .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
                                        .addGeofences(geofenceList)
                                        .build();

                                Intent broadcastIntent = new Intent(this, GeofenceBroadcastReceiver.class);
                                int flags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
                                geofencePendingIntent = PendingIntent.getBroadcast(this, 999, broadcastIntent, flags);

                                if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                    geofencingClient.addGeofences(request, geofencePendingIntent);
                                }
                            } catch (Exception ignored) {}
                        }
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private static String readStream(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    private void startBackgroundListening() {
        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        if (!prefs.getBoolean("wake_running", true)) {
            stopSelf();
            return;
        }

        handler.post(() -> {
            try {
                if (speechRecognizer != null) {
                    try { speechRecognizer.destroy(); } catch (Exception ignored) {}
                }
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(PoupousService.this);
                speechRecognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) {}
                    @Override public void onBeginningOfSpeech() {}
                    @Override public void onRmsChanged(float rmsdB) {}
                    @Override public void onBufferReceived(byte[] buffer) {}
                    @Override public void onEndOfSpeech() {}
                    @Override public void onError(int error) {
                        handler.postDelayed(PoupousService.this::startBackgroundListening, 1000);
                    }
                    @Override
                    public void onResults(Bundle results) {
                        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches != null && !matches.isEmpty()) {
                            String spoken = matches.get(0);
                            if (spoken != null && !spoken.trim().isEmpty()) {
                                handleVoiceCommand(spoken);
                            }
                        }
                        handler.postDelayed(PoupousService.this::startBackgroundListening, 500);
                    }
                    @Override public void onPartialResults(Bundle partialResults) {}
                    @Override public void onEvent(int eventType, Bundle params) {}
                });

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
                speechRecognizer.startListening(intent);
            } catch (Exception e) {
                handler.postDelayed(PoupousService.this::startBackgroundListening, 3000);
            }
        });
    }

    private void handleVoiceCommand(String command) {
        String lower = command.toLowerCase(Locale.ROOT);
        if (lower.contains("poupous") || lower.contains("pupus") || lower.contains("pouce pouce")) {
            if (tts != null) {
                tts.speak("Oui, je t'écoute !", TextToSpeech.QUEUE_FLUSH, null, "poupous_ack");
            }
            
            Intent launchIntent = new Intent(this, MainActivity.class);
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            launchIntent.putExtra("reveil_after", command);
            startActivity(launchIntent);
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (Exception ignored) {}
        }
        if (geofencingClient != null && geofencePendingIntent != null) {
            try { geofencingClient.removeGeofences(geofencePendingIntent); } catch (Exception ignored) {}
        }
        if (speechRecognizer != null) {
            try { speechRecognizer.destroy(); } catch (Exception ignored) {}
        }
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {}
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    public static void startHttpServer(Context context) { serverRunning = true; }
    public static void stopHttpServer() { serverRunning = false; }
    public static boolean isServerRunning() { return serverRunning; }
    public static void broadcastSync(String json) {}
    public static String getLocalIpAddress(Context context) { return "127.0.0.1"; }
}
