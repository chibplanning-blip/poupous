package com.poupous.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Affiche la notification quand l'heure du rappel arrive, même si l'appli est fermée. */
public class Rappel extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String titre = intent.getStringExtra("titre");
        String texte = intent.getStringExtra("texte");
        if (titre == null || titre.isEmpty()) titre = "Poupous";
        if (texte == null) texte = "";
        montrer(context, titre, texte);
    }

    static void montrer(Context context, String titre, String texte) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent ouvrir = new Intent(context, MainActivity.class);
        ouvrir.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 0, ouvrir,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(context, MainActivity.CANAL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(titre)
                .setContentText(texte)
                .setStyle(new Notification.BigTextStyle().bigText(texte))
                .setAutoCancel(true)
                .setContentIntent(pi);
        nm.notify((int) (System.currentTimeMillis() % 100000), b.build());
    }
}
