#!/usr/bin/env bash
set -euo pipefail
REPO="$1"
sed -i "s#__REPO__#${REPO}#g" app/src/main/java/com/poupous/app/MainActivity.java
mkdir -p app/src/main/assets
cp ../app.html app/src/main/assets/app.html
echo "Projet prêt pour ${REPO}"
