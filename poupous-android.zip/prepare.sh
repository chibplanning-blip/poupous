#!/usr/bin/env bash
set -euo pipefail
REPO="$1"
sed -i "s#__REPO__#${REPO}#g" app/src/main/java/com/poupous/app/MainActivity.java
mkdir -p app/src/main/assets/source
tar --exclude='./app/src/main/assets' --exclude='./app/build' --exclude='./build' --exclude='./.gradle' --exclude='./app.html' -cf /tmp/poupous-source.tar .
tar -xf /tmp/poupous-source.tar -C app/src/main/assets/source
ver() { { grep -o 'POUPOUS_VERSION=[0-9]*' "$1" 2>/dev/null || true; } | head -1 | cut -d= -f2; }
ZV=$(ver app.html); RV=$(ver ../app.html)
if [ "${ZV:-0}" -gt "${RV:-0}" ]; then cp app.html app/src/main/assets/app.html; else cp ../app.html app/src/main/assets/app.html; fi
echo "Projet prêt pour ${REPO} (page zip=${ZV:-0}, dépôt=${RV:-0})"
