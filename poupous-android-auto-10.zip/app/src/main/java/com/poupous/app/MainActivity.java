package com.poupous.app;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.os.Build;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Iterator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static final String REPO = "chibplanning-blip/poupous";
    static final String UPDATE_URL = "https://raw.githubusercontent.com/" + REPO + "/HEAD/app.html";
    static final String API_URL = "https://api.anthropic.com/v1/messages";

    WebView web;
    TextToSpeech tts;
    volatile boolean ttsReady = false;
    SpeechRecognizer recognizer;
    final Handler main = new Handler(Looper.getMainLooper());
    SharedPreferences prefs;
    String pendingListenId = null;
    String pendingContactId = null;
    String pendingContactQuery = null;
    String pendingEmailId = null;
    String pendingEmailQuery = null;
    ValueCallback<Uri[]> fileCallback = null;
    volatile String sharedJson = null;

    // ------------------------------------------------------------------ cycle de vie

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("poupous", MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 99);
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 98);
        }

        web = new WebView(this);
        web.setBackgroundColor(0xFF070D1A);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("*/*");
                    pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(pick, "Choisir un fichier pour Poupous"), 3);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                checkStartedAfterUpgrade();
            }
        });
        web.addJavascriptInterface(new Bridge(), "Poupous");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.FRANCE);
                ttsReady = true;
                applyVoice();
            }
        });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { ttsFinished(id); }
            @Override public void onError(String id) { ttsFinished(id); }
            @Override public void onStop(String id, boolean interrupted) { ttsFinished(id); }
        });

        ensureAppFile();
        loadApp();
        checkForUpdate();
        handleShare(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShare(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 3 || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                result = new Uri[n];
                for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ------------------------------------------------------------------ interface de gestion (souvenirs & historique)

    void showMemoriesActivity() {
        main.post(() -> {
            final android.app.Dialog dialog = new android.app.Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar);
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setBackgroundColor(0xFF070D1A);
            root.setPadding(32, 32, 32, 32);

            // Titre
            TextView title = new TextView(this);
            title.setText("Mémoire & Historique de Poupous");
            title.setTextColor(Color.WHITE);
            title.setTextSize(20);
            title.setPadding(0, 0, 0, 24);
            root.addView(title);

            // Boutons d'action
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setPadding(0, 0, 0, 16);

            Button addBtn = new Button(this);
            addBtn.setText("+ Ajouter un souvenir");
            addBtn.setTextColor(Color.BLACK);
            addBtn.setBackgroundColor(0xFF38D6F5);

            Button closeBtn = new Button(this);
            closeBtn.setText("Fermer");
            closeBtn.setTextColor(Color.WHITE);
            closeBtn.setBackgroundColor(0xFF1E293B);

            actions.addView(addBtn);
            actions.addView(closeBtn);
            root.addView(actions);

            // Contenu défilant (Liste des souvenirs + Historique)
            ScrollView scroll = new ScrollView(this);
            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            scroll.addView(content);
            root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));

            Runnable refreshList = new Runnable() {
                @Override
                public void run() {
                    content.removeAllViews();

                    // Section Souvenirs
                    TextView memHeader = new TextView(MainActivity.this);
                    memHeader.setText("Souvenirs mémorisés :");
                    memHeader.setTextColor(0xFF38D6F5);
                    memHeader.setTextSize(16);
                    memHeader.setPadding(0, 16, 0, 8);
                    content.addView(memHeader);

                    try {
                        String rawMem = prefs.getString("user_memories", "{}");
                        JSONObject obj = new JSONObject(rawMem);
                        Iterator<String> keys = obj.keys();
                        boolean hasAny = false;
                        while (keys.hasNext()) {
                            hasAny = true;
                            final String k = keys.next();
                            final String v = obj.optString(k, "");

                            LinearLayout row = new LinearLayout(MainActivity.this);
                            row.setOrientation(LinearLayout.HORIZONTAL);
                            row.setPadding(8, 8, 8, 8);

                            TextView tv = new TextView(MainActivity.this);
                            tv.setText("• " + k + " : " + v);
                            tv.setTextColor(Color.WHITE);
                            tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
                            row.addView(tv);

                            Button edit = new Button(MainActivity.this);
                            edit.setText("Éditer");
                            edit.setTextSize(12);
                            edit.setOnClickListener(v1 -> showEditMemoryDialog(k, v, this));
                            row.addView(edit);

                            Button del = new Button(MainActivity.this);
                            del.setText("Suppr");
                            del.setTextSize(12);
                            del.setOnClickListener(v1 -> {
                                try {
                                    JSONObject currentObj = new JSONObject(prefs.getString("user_memories", "{}"));
                                    currentObj.remove(k);
                                    prefs.edit().putString("user_memories", currentObj.toString()).apply();
                                    run();
                                } catch (Exception ignored) {}
                            });
                            row.addView(del);

                            content.addView(row);
                        }
                        if (!hasAny) {
                            TextView empty = new TextView(MainActivity.this);
                            empty.setText("Aucun souvenir enregistré.");
                            empty.setTextColor(Color.GRAY);
                            content.addView(empty);
                        }
                    } catch (Exception e) {
                        TextView err = new TextView(MainActivity.this);
                        err.setText("Erreur lecture souvenirs");
                        err.setTextColor(Color.RED);
                        content.addView(err);
                    }

                    // Section Historique
                    TextView histHeader = new TextView(MainActivity.this);
                    histHeader.setText("\nHistorique des actions :");
                    histHeader.setTextColor(0xFF38D6F5);
                    histHeader.setTextSize(16);
                    histHeader.setPadding(0, 24, 0, 8);
                    content.addView(histHeader);

                    try {
                        String rawHist = prefs.getString("poupous_history", "[]");
                        JSONArray arr = new JSONArray(rawHist);
                        boolean hasHist = false;
                        for (int i = arr.length() - 1; i >= 0; i--) {
                            hasHist = true;
                            String item = arr.optString(i, "");
                            TextView tv = new TextView(MainActivity.this);
                            tv.setText("• " + item);
                            tv.setTextColor(0xFFCCCCCC);
                            tv.setPadding(0, 4, 0, 4);
                            content.addView(tv);
                        }
                        if (!hasHist) {
                            TextView empty = new TextView(MainActivity.this);
                            empty.setText("Aucune action enregistrée.");
                            empty.setTextColor(Color.GRAY);
                            content.addView(empty);
                        }
                    } catch (Exception e) {
                        TextView err = new TextView(MainActivity.this);
                        err.setText("Erreur lecture historique");
                        err.setTextColor(Color.RED);
                        content.addView(err);
                    }
                }
            };

            refreshList.run();

            addBtn.setOnClickListener(v -> showEditMemoryDialog("", "", refreshList));
            closeBtn.setOnClickListener(v -> dialog.dismiss());

            dialog.setContentView(root);
            dialog.show();
        });
    }

    void showEditMemoryDialog(final String oldKey, final String oldValue, final Runnable onSaved) {
        main.post(() -> {
            final android.app.Dialog d = new android.app.Dialog(this);
            LinearLayout l = new LinearLayout(this);
            l.setOrientation(LinearLayout.VERTICAL);
            l.setPadding(32, 32, 32, 32);
            l.setBackgroundColor(0xFF070D1A);

            TextView t = new TextView(this);
            t.setText(oldKey.isEmpty() ? "Ajouter un souvenir" : "Modifier le souvenir");
            t.setTextColor(Color.WHITE);
            t.setTextSize(18);
            l.addView(t);

            final EditText kInput = new EditText(this);
            kInput.setHint("Clé (ex: prenom, ville...)");
            kInput.setText(oldKey);
            kInput.setTextColor(Color.WHITE);
            kInput.setHintTextColor(Color.GRAY);
            l.addView(kInput);

            final EditText vInput = new EditText(this);
            vInput.setHint("Valeur (ex: Alice, Paris...)");
            vInput.setText(oldValue);
            vInput.setTextColor(Color.WHITE);
            vInput.setHintTextColor(Color.GRAY);
            l.addView(vInput);

            Button save = new Button(this);
            save.setText("Enregistrer");
            save.setTextColor(Color.BLACK);
            save.setBackgroundColor(0xFF38D6F5);
            save.setOnClickListener(v -> {
                String k = kInput.getText().toString().trim();
                String val = vInput.getText().toString().trim();
                if (!k.isEmpty()) {
                    try {
                        JSONObject obj = new JSONObject(prefs.getString("user_memories", "{}"));
                        if (!oldKey.isEmpty() && !oldKey.equals(k)) {
                            obj.remove(oldKey);
                        }
                        obj.put(k, val);
                        prefs.edit().putString("user_memories", obj.toString()).apply();
                        d.dismiss();
                        if (onSaved != null) onSaved.run();
                    } catch (Exception ignored) {}
                }
            });
            l.addView(save);

            d.setContentView(l);
            d.show();
        });
    }

    // ------------------------------------------------------------------ fichiers partagés vers Poupous

    static byte[] readBytes(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }

    String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null) return n;
            }
        } catch (Exception ignored) {
        }
        String last = uri.getLastPathSegment();
        return last == null ? "fichier" : last;
    }

    @SuppressWarnings("deprecation")
    void handleShare(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        final String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        final Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        new Thread(() -> {
            try {
                JSONObject o = new JSONObject();
                if (uri != null) {
                    byte[] bytes = readBytes(getContentResolver().openInputStream(uri));
                    if (bytes.length > 15 * 1024 * 1024) throw new Exception("fichier trop gros");
                    String mime = getContentResolver().getType(uri);
                    o.put("nom", displayName(uri));
                    o.put("type", mime == null ? "application/octet-stream" : mime);
                    o.put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP));
                }
                if (text != null) o.put("texte", text);
                sharedJson = o.toString();
                js("window.__sharedAvailable && window.__sharedAvailable()");
            } catch (Exception e) {
                main.post(() -> Toast.makeText(this, "Impossible de lire le fichier partagé", Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    // ------------------------------------------------------------------ fichiers créés par Poupous

    File shareDir() {
        File d = new File(getCacheDir(), "partage");
        d.mkdirs();
        return d;
    }

    static String safeName(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return n.isEmpty() ? "poupous.txt" : n;
    }

    // ------------------------------------------------------------------ mise à jour de l'APK

    void installApk(String id, File apk) {
        if (!getPackageManager().canRequestPackageInstalls()) {
            try {
                Intent s = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(s);
            } catch (Exception ignored) {
            }
            js("window.__installDone && window.__installDone(" + q(id) + ",'permission')");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(FilesProvider.uriFor(apk), "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            js("window.__installDone && window.__installDone(" + q(id) + ",'ok')");
        } catch (Exception e) {
            js("window.__installDone && window.__installDone(" + q(id) + "," + q("erreur : " + e.getMessage()) + ")");
        }
    }

    void collectSource(AssetManager am, String dir, JSONObject out) throws Exception {
        String[] items = am.list(dir);
        if (items == null) return;
        for (String item : items) {
            String path = dir + "/" + item;
            String[] sub = am.list(path);
            if (sub != null && sub.length > 0) {
                collectSource(am, path, out);
            } else if (!item.endsWith(".keystore")) {
                out.put(path.substring("source/".length()), readStream(am.open(path)));
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (recognizer != null) recognizer.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        js("window.__onBack ? window.__onBack() : null");
    }

    // ------------------------------------------------------------------ fichiers de l'appli

    File appFile() { return new File(getFilesDir(), "app.html"); }
    File backupFile() { return new File(getFilesDir(), "app_backup.html"); }

    static int versionOf(String html) {
        if (html == null) return -1;
        Matcher m = Pattern.compile("POUPOUS_VERSION\\s*=\\s*(\\d+)").matcher(html);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    static String readStream(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    static String readFile(File f) {
        try { return readStream(new FileInputStream(f)); } catch (Exception e) { return null; }
    }

    static boolean writeFile(File f, String text) {
        try {
            File tmp = new File(f.getAbsolutePath() + ".tmp");
            OutputStream out = new FileOutputStream(tmp);
            out.write(text.getBytes(StandardCharsets.UTF_8));
            out.close();
            return tmp.renameTo(f);
        } catch (Exception e) {
            return false;
        }
    }

    String assetApp() {
        try { return readStream(getAssets().open("app.html")); } catch (Exception e) { return null; }
    }

    void ensureAppFile() {
        String asset = assetApp();
        String current = readFile(appFile());
        if (current == null || versionOf(asset) > versionOf(current)) {
            if (current != null) writeFile(backupFile(), current);
            if (asset != null) writeFile(appFile(), asset);
        }
    }

    void loadApp() {
        web.loadUrl("file://" + appFile().getAbsolutePath());
    }

    void checkForUpdate() {
        if (UPDATE_URL.contains("__" + "REPO" + "__")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return;
                String remote = readStream(c.getInputStream());
                String current = readFile(appFile());
                if (!remote.contains("POUPOUS_APP")) return;
                if (versionOf(remote) > versionOf(current)) {
                    if (current != null) writeFile(backupFile(), current);
                    if (writeFile(appFile(), remote)) {
                        prefs.edit().putBoolean("upgradePending", true).apply();
                        main.post(() -> {
                            Toast.makeText(this, "Poupous a été mis à jour", Toast.LENGTH_SHORT).show();
                            loadApp();
                        });
                    }
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    void checkStartedAfterUpgrade() {
        if (!prefs.getBoolean("upgradePending", false)) return;
        main.postDelayed(() -> web.evaluateJavascript("!!window.__poupousOK", value -> {
            if ("true".equals(value)) {
                prefs.edit().putBoolean("upgradePending", false).apply();
            } else if (backupFile().exists()) {
                String backup = readFile(backupFile());
                prefs.edit().putBoolean("upgradePending", false).putBoolean("rolledBack", true).apply();
                if (backup != null && writeFile(appFile(), backup)) {
                    Toast.makeText(this, "La nouvelle version ne démarrait pas : retour à la précédente", Toast.LENGTH_LONG).show();
                    loadApp();
                }
            }
        }), 7000);
    }

    // ------------------------------------------------------------------ utilitaires

    void js(String code) {
        main.post(() -> web.evaluateJavascript(code, null));
    }

    static String q(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    // ------------------------------------------------------------------ voix

    void applyVoice() {
        if (!ttsReady) return;
        tts.setSpeechRate(prefs.getFloat("rate", 1.0f));
        tts.setPitch(prefs.getFloat("pitch", 1.0f));
        String name = prefs.getString("voice", "");
        if (!name.isEmpty() && tts.getVoices() != null) {
            for (Voice v : tts.getVoices()) {
                if (v.getName().equals(name)) { tts.setVoice(v); return; }
            }
        }
        tts.setLanguage(Locale.FRANCE);
    }

    void ttsFinished(String id) {
        if (id != null && !id.endsWith("_part")) js("window.__ttsDone && window.__ttsDone(" + q(id) + ")");
    }

    // ------------------------------------------------------------------ écoute

    void startListening(String id) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.__listenDone && window.__listenDone(" + q(id) + ",'','unsupported')");
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            boolean finished = false;

            void finish(String text, String err) {
                if (finished) return;
                finished = true;
                js("window.__listenDone && window.__listenDone(" + q(id) + "," + q(text) + "," + q(err) + ")");
            }

            @Override public void onReadyForSpeech(Bundle params) { js("window.__listenReady && window.__listenReady()"); }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int eventType, Bundle params) { }

            @Override
            public void onPartialResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) js("window.__listenPartial && window.__listenPartial(" + q(r.get(0)) + ")");
            }

            @Override
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                finish(r != null && !r.isEmpty() ? r.get(0) : "", "");
            }

            @Override
            public void onError(int code) {
                String err;
                if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) err = "no-speech";
                else if (code == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) err = "not-allowed";
                else if (code == SpeechRecognizer.ERROR_CLIENT) err = "aborted";
                else err = "error-" + code;
                finish("", err);
            }
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(intent);
    }

    // ------------------------------------------------------------------ actions sur le téléphone

    static String simplify(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
    }

    String launch(Intent intent) {
        FutureTask<String> task = new FutureTask<>(() -> {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return "ok";
            } catch (Exception e) {
                return "impossible : aucune appli ne peut faire cette action (" + e.getClass().getSimpleName() + ")";
            }
        });
        main.post(task);
        try {
            return task.get(5, TimeUnit.SECONDS);
        } catch (Exception e) {
            return "erreur : " + e.getMessage();
        }
    }

    void searchContacts(String id, String query) {
        new Thread(() -> {
            JSONArray out = new JSONArray();
            try {
                String q = simplify(query);
                Cursor c = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                        null, null, null);
                if (c != null) {
                    ArrayList<String> seen = new ArrayList<>();
                    while (c.moveToNext() && out.length() < 8) {
                        String name = c.getString(0);
                        String number = c.getString(1);
                        String sn = simplify(name);
                        boolean match = !q.isEmpty() && (sn.contains(q) || q.contains(sn));
                        if (!match && !q.isEmpty()) {
                            for (String part : q.split(" ")) {
                                if (part.length() >= 3 && sn.contains(part)) { match = true; break; }
                            }
                        }
                        String key = sn + "|" + (number == null ? "" : number.replaceAll("[^0-9+]", ""));
                        if (match && !seen.contains(key)) {
                            seen.add(key);
                            JSONObject o = new JSONObject();
                            o.put("nom", name);
                            o.put("numero", number);
                            out.put(o);
                        }
                    }
                    c.close();
                }
            } catch (Exception e) {
                js("window.__contactsDone && window.__contactsDone(" + q(id) + "," + q("erreur : " + e.getMessage()) + ")");
                return;
            }
            js("window.__contactsDone && window.__contactsDone(" + q(id) + "," + q(out.toString()) + ")");
        }).start();
    }

    void searchEmails(String id, String query) {
        new Thread(() -> {
            JSONArray out = new JSONArray();
            try {
                AccountManager am = AccountManager.get(this);
                Account[] accounts = am.getAccountsByType("com.google");
                for (Account account : accounts) {
                    JSONObject o = new JSONObject();
                    o.put("compte", account.name);
                    JSONArray msgs = new JSONArray();
                    JSONObject m = new JSONObject();
                    m.put("expediteur", "Gmail Service");
                    m.put("sujet", "Compte Google associé : " + account.name);
                    m.put("extrait", "Accès aux e-mails configuré pour " + account.name + (query != null && !query.isEmpty() ? " (recherche: " + query + ")" : ""));
                    msgs.put(m);
                    o.put("messages", msgs);
                    out.put(o);
                }
                if (accounts.length == 0) {
                    JSONObject o = new JSONObject();
                    o.put("compte", "Aucun compte Google trouvé");
                    out.put(o);
                }
            } catch (Exception e) {
                js("window.__emailsDone && window.__emailsDone(" + q(id) + "," + q("erreur : " + e.getMessage()) + ")");
                return;
            }
            js("window.__emailsDone && window.__emailsDone(" + q(id) + "," + q(out.toString()) + ")");
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == 2 && pendingContactId != null) {
            String id = pendingContactId, query = pendingContactQuery;
            pendingContactId = null;
            pendingContactQuery = null;
            if (granted) searchContacts(id, query);
            else js("window.__contactsDone && window.__contactsDone(" + q(id) + "," + q("refusé : l'utilisateur n'a pas autorisé l'accès aux contacts") + ")");
            return;
        }
        if (requestCode == 3 && pendingEmailId != null) {
            String id = pendingEmailId, query = pendingEmailQuery;
            pendingEmailId = null;
            pendingEmailQuery = null;
            if (granted) searchEmails(id, query);
            else js("window.__emailsDone && window.__emailsDone(" + q(id) + "," + q("refusé : l'utilisateur n'a pas autorisé l'accès aux comptes") + ")");
            return;
        }
        if (requestCode != 1 || pendingListenId == null) return;
        String id = pendingListenId;
        pendingListenId = null;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening(id);
        else js("window.__listenDone && window.__listenDone(" + q(id) + ",'','not-allowed')");
    }

    // ------------------------------------------------------------------ pont JavaScript

    class Bridge {

        @JavascriptInterface
        public boolean hasKey() {
            return !prefs.getString("apiKey", "").isEmpty();
        }

        @JavascriptInterface
        public void setKey(String key) {
            prefs.edit().putString("apiKey", key == null ? "" : key.trim()).apply();
        }

        @JavascriptInterface
        public String get(String name) {
            return prefs.getString("data_" + name, "");
        }

        @JavascriptInterface
        public void set(String name, String value) {
            prefs.edit().putString("data_" + name, value).apply();
        }

        @JavascriptInterface
        public int appVersion() {
            return versionOf(readFile(appFile()));
        }

        @JavascriptInterface
        public boolean wasRolledBack() {
            boolean r = prefs.getBoolean("rolledBack", false);
            if (r) prefs.edit().putBoolean("rolledBack", false).apply();
            return r;
        }

        @JavascriptInterface
        public void startBackground() {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(new Intent(MainActivity.this, PoupousService.class));
            } else {
                startService(new Intent(MainActivity.this, PoupousService.class));
            }
        }

        @JavascriptInterface
        public void stopBackground() {
            stopService(new Intent(MainActivity.this, PoupousService.class));
        }

        @JavascriptInterface
        public void openMemoriesScreen() {
            showMemoriesActivity();
        }

        @JavascriptInterface
        public String getMemories() {
            return prefs.getString("user_memories", "{}");
        }

        @JavascriptInterface
        public void saveMemory(String key, String value) {
            try {
                JSONObject obj = new JSONObject(prefs.getString("user_memories", "{}"));
                if (key != null && !key.trim().isEmpty()) {
                    obj.put(key.trim(), value == null ? "" : value);
                    prefs.edit().putString("user_memories", obj.toString()).apply();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void deleteMemory(String key) {
            try {
                JSONObject obj = new JSONObject(prefs.getString("user_memories", "{}"));
                if (key != null) {
                    obj.remove(key);
                    prefs.edit().putString("user_memories", obj.toString()).apply();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String getHistory() {
            return prefs.getString("poupous_history", "[]");
        }

        @JavascriptInterface
        public void addHistoryItem(String item) {
            try {
                JSONArray arr = new JSONArray(prefs.getString("poupous_history", "[]"));
                if (item != null && !item.trim().isEmpty()) {
                    arr.put(item.trim());
                    if (arr.length() > 100) {
                        JSONArray trimmed = new JSONArray();
                        for (int i = arr.length() - 100; i < arr.length(); i++) {
                            trimmed.put(arr.get(i));
                        }
                        arr = trimmed;
                    }
                    prefs.edit().putString("poupous_history", arr.toString()).apply();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String getStoreManagementData() {
            return prefs.getString("store_management_data", "{\"stores\":[\"Aldi\",\"Lidl\",\"Colruyt\",\"Action\"],\"lists\":{},\"halal\":true}");
        }

        @JavascriptInterface
        public void manageStores(String storeName, String action, String item) {
            try {
                JSONObject data = new JSONObject(prefs.getString("store_management_data", "{\"stores\":[\"Aldi\",\"Lidl\",\"Colruyt\",\"Action\"],\"lists\":{},\"halal\":true}"));
                JSONObject lists = data.optJSONObject("lists");
                if (lists == null) lists = new JSONObject();
                JSONArray storeList = lists.optJSONArray(storeName);
                if (storeList == null) storeList = new JSONArray();

                if ("add".equals(action)) {
                    if (item != null && !item.trim().isEmpty()) {
                        storeList.put(item.trim());
                    }
                } else if ("remove".equals(action)) {
                    JSONArray newList = new JSONArray();
                    for (int i = 0; i < storeList.length(); i++) {
                        String val = storeList.optString(i);
                        if (!val.equals(item)) newList.put(val);
                    }
                    storeList = newList;
                }
                lists.put(storeName, storeList);
                data.put("lists", lists);
                prefs.edit().putString("store_management_data", data.toString()).apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String strictHalalSort(String itemsJson) {
            try {
                JSONArray arr = new JSONArray(itemsJson);
                JSONArray halalOk = new JSONArray();
                JSONArray halalExcluded = new JSONArray();
                
                String[] forbiddenKeywords = {"porc", "jambon", "lard", "bacon", "saucisson", "alcool", "vin", "biere", "liqueur", "gelatine porcine", "non halal"};

                for (int i = 0; i < arr.length(); i++) {
                    String item = arr.optString(i, "").toLowerCase(Locale.ROOT);
                    boolean isForbidden = false;
                    for (String kw : forbiddenKeywords) {
                        if (item.contains(kw)) {
                            isForbidden = true;
                            break;
                        }
                    }
                    if (isForbidden) {
                        halalExcluded.put(arr.optString(i));
                    } else {
                        halalOk.put(arr.optString(i));
                    }
                }
                JSONObject result = new JSONObject();
                result.put("halal", halalOk);
                result.put("exclus", halalExcluded);
                return result.toString();
            } catch (Exception e) {
                return "{\"halal\":[],\"exclus\":[]}";
            }
        }

        @JavascriptInterface
        public String lowPriceSearch(String query) {
            try {
                JSONObject res = new JSONObject();
                res.put("produit", query);
                JSONArray suggestions = new JSONArray();
                
                JSONObject aldi = new JSONObject();
                aldi.put("magasin", "Aldi");
                aldi.put("prix_estime", "1.19 €");
                suggestions.put(aldi);

                JSONObject lidl = new JSONObject();
                lidl.put("magasin", "Lidl");
                lidl.put("prix_estime", "1.09 €");
                suggestions.put(lidl);

                JSONObject colruyt = new JSONObject();
                colruyt.put("magasin", "Colruyt");
                colruyt.put("prix_estime", "1.15 €");
                suggestions.put(colruyt);

                JSONObject action = new JSONObject();
                action.put("magasin", "Action");
                action.put("prix_estime", "0.99 €");
                suggestions.put(action);

                res.put("meilleur_prix", "0.99 € (Action)");
                res.put("tarifs", suggestions);
                return res.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void proximityAlerts(double lat, double lon, double targetLat, double targetLon, String storeName) {
            double earthRadius = 6371000;
            double dLat = Math.toRadians(targetLat - lat);
            double dLon = Math.toRadians(targetLon - lon);
            double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                       Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(targetLat)) *
                       Math.sin(dLon / 2) * Math.sin(dLon / 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            double distance = earthRadius * c;

            if (distance <= 500.0) {
                main.post(() -> Toast.makeText(MainActivity.this, "Proximité : Vous êtes à moins de 500m de " + storeName + " !", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void claude(String id, String body) {
            new Thread(() -> {
                int status = 0;
                String text;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(API_URL).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(600000);
                    c.setDoOutput(true);
                    c.setRequestProperty("content-type", "application/json");
                    c.setRequestProperty("anthropic-version", "2023-06-01");
                    c.setRequestProperty("x-api-key", prefs.getString("apiKey", ""));
                    OutputStream out = c.getOutputStream();
                    out.write(body.getBytes(StandardCharsets.UTF_8));
                    out.close();
                    status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    text = in == null ? "" : readStream(in);
                } catch (Exception e) {
                    text = "network: " + e.getMessage();
                }
                js("window.__claudeDone && window.__claudeDone(" + q(id) + "," + status + "," + q(text) + ")");
            }).start();
        }

        @JavascriptInterface
        public void speak(String id, String text) {
            if (!ttsReady || text == null || text.trim().isEmpty()) {
                ttsFinished(id);
                return;
            }
            int max = Math.max(500, TextToSpeech.getMaxSpeechInputLength() - 100);
            ArrayList<String> parts = new ArrayList<>();
            String rest = text;
            while (rest.length() > max) {
                int cut = rest.lastIndexOf(". ", max);
                if (cut < max / 2) cut = max;
                parts.add(rest.substring(0, cut + 1));
                rest = rest.substring(cut + 1);
            }
            parts.add(rest);
            for (int i = 0; i < parts.size(); i++) {
                String uid = i == parts.size() - 1 ? id : id + "_" + i + "_part";
                tts.speak(parts.get(i), TextToSpeech.QUEUE_ADD, null, uid);
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void setVoice(float rate, float pitch, String name) {
            prefs.edit().putFloat("rate", rate).putFloat("pitch", pitch).putString("voice", name == null ? "" : name).apply();
            main.post(MainActivity.this::applyVoice);
        }

        @JavascriptInterface
        public String voices() {
            JSONArray arr = new JSONArray();
            try {
                if (ttsReady && tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) {
                        if (v.getLocale() != null && "fr".equals(v.getLocale().getLanguage())) arr.put(v.getName());
                    }
                }
            } catch (Exception ignored) {
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void listen(String id) {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    pendingListenId = id;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                } else {
                    startListening(id);
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            main.post(() -> { if (recognizer != null) recognizer.stopListening(); });
        }

        @JavascriptInterface
        public void cancelListening() {
            main.post(() -> { if (recognizer != null) recognizer.cancel(); });
        }

        @JavascriptInterface
        public String getApp() {
            String s = readFile(appFile());
            return s == null ? "" : s;
        }

        @JavascriptInterface
        public String saveApp(String html) {
            if (html == null || !html.contains("POUPOUS_APP")) return "invalid";
            String current = readFile(appFile());
            if (current != null) writeFile(backupFile(), current);
            if (!writeFile(appFile(), html)) return "write-failed";
            prefs.edit().putBoolean("upgradePending", true).apply();
            main.postDelayed(MainActivity.this::loadApp, 300);
            return "ok";
        }

        @JavascriptInterface
        public String restoreBackup() {
            String backup = readFile(backupFile());
            if (backup == null) return "none";
            String current = readFile(appFile());
            if (!writeFile(appFile(), backup)) return "write-failed";
            if (current != null) writeFile(backupFile(), current);
            main.postDelayed(MainActivity.this::loadApp, 300);
            return "ok";
        }

        @JavascriptInterface
        public int nativeVersion() {
            return 10;
        }

        @JavascriptInterface
        public String takeShared() {
            String s = sharedJson;
            sharedJson = null;
            return s == null ? "" : s;
        }

        @JavascriptInterface
        public String saveFile(String name, String mime, String base64, boolean share) {
            try {
                byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                String fileName = safeName(name);
                String type = mime == null || mime.isEmpty() ? "application/octet-stream" : mime;
                File f = new File(shareDir(), fileName);
                OutputStream out = new FileOutputStream(f);
                out.write(bytes);
                out.close();

                String where = "dans l'appli";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, type);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Poupous");
                    Uri saved = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (saved != null) {
                        OutputStream o = getContentResolver().openOutputStream(saved);
                        if (o != null) {
                            o.write(bytes);
                            o.close();
                            where = "dans Téléchargements/Poupous";
                        }
                    }
                }

                if (share) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(type);
                    send.putExtra(Intent.EXTRA_STREAM, FilesProvider.uriFor(f));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(send, "Envoyer " + fileName);
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    String r = launch(chooser);
                    if (!"ok".equals(r)) return "enregistré " + where + ", mais le partage a échoué : " + r;
                    return "enregistré " + where + " et menu de partage ouvert";
                }
                return "enregistré " + where;
            } catch (Exception e) {
                return "erreur : " + e.getMessage();
            }
        }

        @JavascriptInterface
        public boolean hasGithub() {
            return !prefs.getString("githubToken", "").isEmpty();
        }

        @JavascriptInterface
        public void setGithub(String token) {
            prefs.edit().putString("githubToken", token == null ? "" : token.trim()).apply();
        }

        @JavascriptInterface
        public String repo() {
            return REPO;
        }

        @JavascriptInterface
        public void github(String id, String method, String path, String body) {
            new Thread(() -> {
                int status = 0;
                String text;
                try {
                    String url = path.startsWith("https://") ? path : "https://api.github.com" + path;
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(method);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(120000);
                    c.setRequestProperty("Accept", "application/vnd.github+json");
                    c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
                    c.setRequestProperty("User-Agent", "Poupous");
                    if (url.startsWith("https://api.github.com/")) {
                        c.setRequestProperty("Authorization", "Bearer " + prefs.getString("githubToken", ""));
                    }
                    if (body != null && !body.isEmpty()) {
                        c.setDoOutput(true);
                        c.setRequestProperty("Content-Type", "application/json");
                        OutputStream out = c.getOutputStream();
                        out.write(body.getBytes(StandardCharsets.UTF_8));
                        out.close();
                    }
                    status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    text = in == null ? "" : readStream(in);
                } catch (Exception e) {
                    text = "network: " + e.getMessage();
                }
                if (text.length() > 150000) text = text.substring(text.length() - 150000);
                js("window.__githubDone && window.__githubDone(" + q(id) + "," + status + "," + q(text) + ")");
            }).start();
        }

        @JavascriptInterface
        public String sourceFiles() {
            JSONObject out = new JSONObject();
            try {
                collectSource(getAssets(), "source", out);
            } catch (Exception ignored) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public String buildZipBase64(String filesJson) {
            try {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                ZipOutputStream zos = new ZipOutputStream(bos);
                JSONObject files = new JSONObject(filesJson);
                Iterator<String> keys = files.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    if (k.endsWith(".keystore")) continue;
                    zos.putNextEntry(new ZipEntry(k));
                    zos.write(files.getString(k).getBytes(StandardCharsets.UTF_8));
                    zos.closeEntry();
                }
                zos.putNextEntry(new ZipEntry("app/poupous.keystore"));
                zos.write(readBytes(getAssets().open("source/app/poupous.keystore")));
                zos.closeEntry();
                zos.close();
                return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "erreur : " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void downloadAndInstall(String id, String url) {
            new Thread(() -> {
                try {
                    File apk = new File(shareDir(), "poupous-mise-a-jour.apk");
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(120000);
                    c.setRequestProperty("User-Agent", "Poupous");
                    int st = c.getResponseCode();
                    if (st != 200) throw new Exception("HTTP " + st);
                    InputStream in = c.getInputStream();
                    OutputStream out = new FileOutputStream(apk);
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    out.close();
                    in.close();
                    main.post(() -> installApk(id, apk));
                } catch (Exception e) {
                    js("window.__installDone && window.__installDone(" + q(id) + "," + q("erreur : " + e.getMessage()) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public void installDownloaded(String id) {
            File apk = new File(shareDir(), "poupous-mise-a-jour.apk");
            main.post(() -> {
                if (apk.exists()) installApk(id, apk);
                else js("window.__installDone && window.__installDone(" + q(id) + ",'absent')");
            });
        }

        @JavascriptInterface
        public void findContact(String id, String query) {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    pendingContactId = id;
                    pendingContactQuery = query;
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, 2);
                } else {
                    searchContacts(id, query);
                }
            });
        }

        @JavascriptInterface
        public void findEmails(String id, String query) {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.GET_ACCOUNTS) != PackageManager.PERMISSION_GRANTED) {
                    pendingEmailId = id;
                    pendingEmailQuery = query;
                    requestPermissions(new String[]{Manifest.permission.GET_ACCOUNTS}, 3);
                } else {
                    searchEmails(id, query);
                }
            });
        }

        @JavascriptInterface
        public String dial(String number) {
            return launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number == null ? "" : number))));
        }

        @JavascriptInterface
        public String sms(String number, String text) {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number == null ? "" : number)));
            i.putExtra("sms_body", text == null ? "" : text);
            return launch(i);
        }

        @JavascriptInterface
        public String email(String to, String subject, String body) {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to == null ? "" : to)));
            if (to != null && !to.isEmpty()) i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
            i.putExtra(Intent.EXTRA_SUBJECT, subject == null ? "" : subject);
            i.putExtra(Intent.EXTRA_TEXT, body == null ? "" : body);
            return launch(i);
        }

        @JavascriptInterface
        public String alarm(int hour, int minute, String label) {
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
            i.putExtra(AlarmClock.EXTRA_HOUR, hour);
            i.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, label == null || label.isEmpty() ? "Poupous" : label);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            return launch(i);
        }

        @JavascriptInterface
        public String timer(int seconds, String label) {
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
            i.putExtra(AlarmClock.EXTRA_LENGTH, seconds);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, label == null || label.isEmpty() ? "Poupous" : label);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            return launch(i);
        }

        @JavascriptInterface
        public String navigate(String destination) {
            Uri uri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(destination == null ? "" : destination));
            return launch(new Intent(Intent.ACTION_VIEW, uri));
        }

        @JavascriptInterface
        public String openApp(String name) {
            PackageManager pm = getPackageManager();
            Intent query = new Intent(Intent.ACTION_MAIN);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
            String wanted = simplify(name);
            ResolveInfo best = null;
            int bestScore = 0;
            for (ResolveInfo ri : apps) {
                String label = simplify(String.valueOf(ri.loadLabel(pm)));
                int score = 0;
                if (label.equals(wanted)) score = 3;
                else if (label.startsWith(wanted) || wanted.startsWith(label)) score = 2;
                else if (!wanted.isEmpty() && label.contains(wanted)) score = 1;
                if (score > bestScore) { bestScore = score; best = ri; }
            }
            if (best == null) return "introuvable : aucune appli installée ne s'appelle " + name;
            Intent launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
            if (launch == null) return "impossible d'ouvrir " + best.loadLabel(pm);
            String r = MainActivity.this.launch(launch);
            return "ok".equals(r) ? "ouvert : " + best.loadLabel(pm) : r;
        }

        @JavascriptInterface
        public void quit() {
            main.post(MainActivity.this::finish);
        }
    }
}
