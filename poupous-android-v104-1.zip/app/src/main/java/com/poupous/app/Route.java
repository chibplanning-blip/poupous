package com.poupous.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Surveille la route quand la liste de courses n'est pas vide.
 * Relève la position chaque minute ; dès que l'utilisateur se déplace,
 * cherche les supermarchés autour et prévient une seule fois par magasin.
 */
public class Route extends Service {

    static final String CANAL_SERVICE = "poupous-route";
    static final int ID_SERVICE = 4242;
    static final long PERIODE_MS = 60000L;
    static final long PERIODE_RECHERCHE_MS = 180000L;
    static final int RAYON_M = 2000;
    static final float VITESSE_MIN_KMH = 15f;
    static final long OUBLI_MS = 6L * 3600L * 1000L;

    Handler main;
    LocationManager lm;
    LocationListener ecoute;
    Location precedente;
    long dernierePosMs = 0;
    long derniereRechercheMs = 0;
    boolean tourne = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        main = new Handler(Looper.getMainLooper());
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        creerCanal();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(ID_SERVICE, notifServiceBuilder("Poupous surveille la route", "Je te préviens si un magasin est sur ton chemin."));
        if (!tourne) {
            tourne = true;
            demarrerEcoute();
            main.postDelayed(this::battement, PERIODE_MS);
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        tourne = false;
        arreterEcoute();
        super.onDestroy();
    }

    void creerCanal() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        android.app.NotificationChannel c = new android.app.NotificationChannel(
                CANAL_SERVICE, "Surveillance de la route", NotificationManager.IMPORTANCE_LOW);
        c.setDescription("Affichée pendant que Poupous surveille les magasins sur ta route");
        nm.createNotificationChannel(c);
    }

    Notification notifServiceBuilder(String titre, String texte) {
        Intent ouvrir = new Intent(this, MainActivity.class);
        ouvrir.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, ouvrir,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CANAL_SERVICE)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle(titre)
                .setContentText(texte)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    void demarrerEcoute() {
        if (lm == null) return;
        ecoute = new LocationListener() {
            @Override
            public void onLocationChanged(Location l) {
                dernierePosMs = System.currentTimeMillis();
                traiter(l);
            }

            @Override
            public void onStatusChanged(String p, int s, Bundle b) {}

            @Override
            public void onProviderEnabled(String p) {}

            @Override
            public void onProviderDisabled(String p) {}
        };
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, PERIODE_MS, 100f, ecoute, Looper.getMainLooper());
            else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, PERIODE_MS, 100f, ecoute, Looper.getMainLooper());
        } catch (SecurityException e) {
            stopSelf();
        }
    }

    void arreterEcoute() {
        try { if (lm != null && ecoute != null) lm.removeUpdates(ecoute); } catch (Exception e) {}
        ecoute = null;
    }

    /** Filet de sécurité : si le système n'envoie plus rien, on relance l'écoute. */
    void battement() {
        if (!tourne) return;
        if (listeVide()) { stopSelf(); return; }
        if (System.currentTimeMillis() - dernierePosMs > 4 * PERIODE_MS) {
            arreterEcoute();
            demarrerEcoute();
        }
        main.postDelayed(this::battement, PERIODE_MS);
    }

    boolean listeVide() {
        try {
            SharedPreferences p = getSharedPreferences("poupous", Context.MODE_PRIVATE);
            String brut = p.getString("courses", "");
            if (brut == null || brut.isEmpty()) return true;
            JSONArray a = new JSONArray(brut);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && !o.optBoolean("ok", false)) return false;
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    int restants() {
        try {
            SharedPreferences p = getSharedPreferences("poupous", Context.MODE_PRIVATE);
            JSONArray a = new JSONArray(p.getString("courses", "[]"));
            int n = 0;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && !o.optBoolean("ok", false)) n++;
            }
            return n;
        } catch (Exception e) {
            return 0;
        }
    }

    void traiter(Location l) {
        if (l == null) return;
        float vitesse = 0f;
        if (l.hasSpeed()) vitesse = l.getSpeed() * 3.6f;
        else if (precedente != null) {
            long dt = l.getTime() - precedente.getTime();
            if (dt > 5000) vitesse = (l.distanceTo(precedente) / (dt / 1000f)) * 3.6f;
        }
        precedente = l;
        if (vitesse < VITESSE_MIN_KMH) return;
        long maintenant = System.currentTimeMillis();
        if (maintenant - derniereRechercheMs < PERIODE_RECHERCHE_MS) return;
        derniereRechercheMs = maintenant;
        final double lat = l.getLatitude(), lon = l.getLongitude();
        new Thread(() -> chercherMagasins(lat, lon)).start();
    }

    void chercherMagasins(double lat, double lon) {
        try {
            if (listeVide()) return;
            String req = "[out:json][timeout:20];node[\"shop\"~\"^(supermarket|convenience)$\"](around:"
                    + RAYON_M + "," + lat + "," + lon + ");out 20;";
            HttpURLConnection c = (HttpURLConnection) new URL("https://overpass-api.de/api/interpreter").openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            c.setRequestProperty("User-Agent", "Poupous");
            byte[] corps = ("data=" + URLEncoder.encode(req, "UTF-8")).getBytes(StandardCharsets.UTF_8);
            c.getOutputStream().write(corps);
            c.getOutputStream().close();
            if (c.getResponseCode() >= 400) return;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            JSONObject rep = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            JSONArray els = rep.optJSONArray("elements");
            if (els == null) return;

            String meilleurNom = null;
            double meilleurLat = 0, meilleurLon = 0;
            float meilleureDist = Float.MAX_VALUE;
            for (int i = 0; i < els.length(); i++) {
                JSONObject e = els.optJSONObject(i);
                if (e == null) continue;
                JSONObject tags = e.optJSONObject("tags");
                String nom = tags == null ? null : tags.optString("name", "");
                if (nom == null || nom.isEmpty()) continue;
                double la = e.optDouble("lat", Double.NaN), lo = e.optDouble("lon", Double.NaN);
                if (Double.isNaN(la) || Double.isNaN(lo)) continue;
                float[] d = new float[1];
                Location.distanceBetween(lat, lon, la, lo, d);
                if (d[0] < meilleureDist && !dejaPrevenu(nom)) {
                    meilleureDist = d[0];
                    meilleurNom = nom;
                    meilleurLat = la;
                    meilleurLon = lo;
                }
            }
            if (meilleurNom == null) return;
            marquerPrevenu(meilleurNom);
            prevenir(meilleurNom, meilleureDist, meilleurLat, meilleurLon);
        } catch (Exception e) {
            // silencieux : on retentera au prochain relevé
        }
    }

    boolean dejaPrevenu(String nom) {
        SharedPreferences p = getSharedPreferences("poupous-route", Context.MODE_PRIVATE);
        long t = p.getLong("vu-" + nom, 0);
        return System.currentTimeMillis() - t < OUBLI_MS;
    }

    void marquerPrevenu(String nom) {
        getSharedPreferences("poupous-route", Context.MODE_PRIVATE)
                .edit().putLong("vu-" + nom, System.currentTimeMillis()).apply();
    }

    void prevenir(String nom, float distance, double lat, double lon) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        int reste = restants();
        String dist = distance < 1000 ? Math.round(distance) + " m" : String.format("%.1f km", distance / 1000f);
        String texte = reste + (reste > 1 ? " articles" : " article") + " sur ta liste. Touche pour l'itinéraire.";

        Intent maps = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + lat + "," + lon + "(" + Uri.encode(nom) + ")"));
        maps.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, (int) (System.currentTimeMillis() % 10000), maps,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notif = new Notification.Builder(this, MainActivity.CANAL)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle(nom + " à " + dist)
                .setContentText(texte)
                .setStyle(new Notification.BigTextStyle().bigText(texte))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify((int) (System.currentTimeMillis() % 100000), notif);
    }
}
