package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.net.InetAddress;
import java.nio.ByteBuffer;

public class PoupousService extends Service {
    private static PowerManager.WakeLock wakeLock = null;
    private static WifiManager.WifiLock wifiLock = null;
    public static boolean running = false;
    private static boolean serverRunning = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c = new NotificationChannel("poupous_fond", "Poupous en arrière-plan", NotificationManager.IMPORTANCE_LOW);
        c.setShowBadge(false); 
        if (nm != null) {
            nm.createNotificationChannel(c);
        }
        
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, "poupous_fond");
        } else {
            builder = new Notification.Builder(this);
        }
        
        Notification n = builder
            .setContentTitle("Poupous est actif")
            .setContentText("Mode persistant en veille et réseau actif.")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setOngoing(true).build();

        if (Build.VERSION.SDK_INT >= 34) {
            int serviceType = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION | 
                              android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            startForeground(1, n, serviceType);
        } else if (Build.VERSION.SDK_INT >= 29) {
            int serviceType = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | 
                              android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            startForeground(1, n, serviceType);
        } else {
            startForeground(1, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "poupous:wakelock");
                wakeLock.setReferenceCounted(false);
            }
        }
        if (wakeLock != null && !wakeLock.isHeld()) {
            wakeLock.acquire();
        }

        if (wifiLock == null) {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                if (Build.VERSION.SDK_INT >= 29) {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "poupous:wifilock");
                } else {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL, "poupous:wifilock");
                }
                wifiLock.setReferenceCounted(false);
            }
        }
        if (wifiLock != null && !wifiLock.isHeld()) {
            wifiLock.acquire();
        }

        running = true;
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {}
        }
        if (wifiLock != null && wifiLock.isHeld()) {
            try {
                wifiLock.release();
            } catch (Exception ignored) {}
        }
        running = false;
        super.onDestroy();
    }

    public static void start(Context c) { 
        Intent intent = new Intent(c, PoupousService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            c.startForegroundService(intent);
        } else {
            c.startService(intent);
        }
    }
    
    public static void stop(Context c) { 
        c.stopService(new Intent(c, PoupousService.class)); 
    }

    public static void startHttpServer(Context context) {
        serverRunning = true;
    }

    public static void stopHttpServer() {
        serverRunning = false;
    }

    public static boolean isServerRunning() {
        return serverRunning;
    }

    public static void broadcastSync(String json) {
        // Implémentation par défaut pour la synchronisation
    }

    public static String getLocalIpAddress(Context context) {
        try {
            WifiManager wm = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                int ipInt = wm.getConnectionInfo().getIpAddress();
                if (ipInt != 0) {
                    return InetAddress.getByAddress(ByteBuffer.allocate(4).putInt(Integer.reverseBytes(ipInt)).array()).getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }
}
