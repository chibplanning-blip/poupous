package com.poupous.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class PoupousService extends Service {
    static final String CHANNEL_ID = "poupous_service";
    PowerManager.WakeLock wakeLock;

    static ServerSocket serverSocket;
    static volatile boolean serverRunning = false;
    static Socket activeClientSocket = null;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous actif", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::Wakelock");
            wakeLock.acquire();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous actif")
               .setContentText("Poupous et la synchronisation PC tournent en arrière-plan.")
               .setSmallIcon(android.R.drawable.ic_btn_speak_now);
        startForeground(1, builder.build());
        return START_STICKY;
    }

    public static void startHttpServer(final Context context) {
        if (serverRunning) return;
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(8080);
                serverRunning = true;
                while (serverRunning) {
                    try {
                        Socket socket = serverSocket.accept();
                        activeClientSocket = socket;
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String line = reader.readLine();
                        if (line == null) {
                            socket.close();
                            continue;
                        }

                        SharedPreferences prefs = context.getSharedPreferences("poupous", MODE_PRIVATE);
                        String payload = prefs.getString("sync_shared_payload", "{\"lists\":{},\"messages\":[]}");

                        if (line.contains("POST /update")) {
                            StringBuilder sb = new StringBuilder();
                            int contentLength = 0;
                            String l;
                            while ((l = reader.readLine()) != null && !l.isEmpty()) {
                                if (l.toLowerCase().startsWith("content-length:")) {
                                    try {
                                        contentLength = Integer.parseInt(l.substring(15).trim());
                                    } catch (Exception ignored) {}
                                }
                            }
                            char[] buf = new char[contentLength];
                            int read = 0;
                            while (read < contentLength) {
                                int r = reader.read(buf, read, contentLength - read);
                                if (r == -1) break;
                                read += r;
                            }
                            String body = new String(buf, 0, read);
                            if (!body.isEmpty()) {
                                prefs.edit().putString("sync_shared_payload", body).apply();
                            }
                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n{\"status\":\"ok\"}";
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        } else {
                            // HTML page for PC browser connection
                            String html = "<(!DOCTYPE html><html><head><meta charset='utf-8'><title>Poupous PC Sync</title>" +
                                    "<style>body{background:#070d1a;color:#fff;font-family:sans-serif;padding:30px;}" +
                                    "h1{color:#38d6f5;} textarea{width:100%;height:300px;background:#1e293b;color:#fff;border:1px solid #38d6f5;border-radius:8px;padding:10px;font-size:16px;}" +
                                    "button{background:#38d6f5;color:#000;font-weight:bold;padding:12px 24px;border:none;border-radius:8px;cursor:pointer;margin-top:10px;font-size:16px;}" +
                                    "</style></head><body><h1>Poupous - Connexion PC en temps réel</h1>" +
                                    "<p>Modifiez vos listes de courses et messages ci-dessous. La synchronisation est instantanée :</p>" +
                                    "<textarea id='data'>" + payload + "</textarea><br>" +
                                    "<button onclick='save()'>Enregistrer et synchroniser avec le téléphone</button>" +
                                    "<script>" +
                                    "function save(){" +
                                    "fetch('/update',{method:'POST',headers:{'Content-Type':'application/json'},body:document.getElementById('data').value})" +
                                    ".then(r=>alert('Synchronisé avec succès !'));" +
                                    "}" +
                                    "setInterval(()=>{fetch(location.href).then(r=>r.text()).then(t=>{/* simple polling */})}, 5000);" +
                                    "</script></body></html>";

                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n" + html;
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        }
                        socket.close();
                    } catch (Exception e) {
                        break;
                    }
                }
            } catch (Exception e) {
                serverRunning = false;
            }
        }).start();
    }

    public static void stopHttpServer() {
        serverRunning = false;
        try {
            if (serverSocket != null) serverSocket.close();
            if (activeClientSocket != null) activeClientSocket.close();
        } catch (Exception ignored) {}
    }

    public static boolean isServerRunning() {
        return serverRunning;
    }

    public static void broadcastSync(String json) {
        // Optionnel: notifie les clients connectés
    }

    public static String getLocalIpAddress(Context context) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        boolean isIPv4 = sAddr.indexOf(':') < 0;
                        if (isIPv4) return sAddr;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }

    @Override
    public void onDestroy() {
        stopHttpServer();
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
