package com.poupous.app;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.os.Build;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Iterator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static final String REPO = "chibplanning-blip/poupous";
    static final String UPDATE_URL = "https://raw.githubusercontent.com/" + REPO + "/HEAD/app.html";
    static final String API_URL = "https://api.anthropic.com/v1/messages";

    WebView web;
    LinearLayout rootLayout;
    LinearLayout progressContainer;
    ProgressBar progressBar;
    TextView progressLabel;

    TextToSpeech tts;
    volatile boolean ttsReady = false;
    SpeechRecognizer recognizer;
    final Handler main = new Handler(Looper.getMainLooper());
    SharedPreferences prefs;
    String pendingListenId = null;
    String pendingContactId = null;
    String pendingContactQuery = null;
    String pendingEmailId = null;
    String pendingEmailQuery = null;
    String pendingLocationId = null;
    GeolocationPermissions.Callback pendingGeoCallback = null;
    String pendingGeoOrigin = null;
    ValueCallback<Uri[]> fileCallback = null;
    volatile String sharedJson = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("poupous", MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 99);
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            String[] perms = Build.VERSION.SDK_INT >= 29 ?
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_BACKGROUND_LOCATION} :
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
            requestPermissions(perms, 98);
        }

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(0xFF030712);

        progressContainer = new LinearLayout(this);
        progressContainer.setOrientation(LinearLayout.VERTICAL);
        progressContainer.setBackgroundColor(0xFF111827);
        progressContainer.setPadding(30, 20, 30, 20);
        progressContainer.setVisibility(android.view.View.GONE);

        progressLabel = new TextView(this);
        progressLabel.setText("Chargement et statut GitHub en direct...");
        progressLabel.setTextColor(0xFF00E5FF);
        progressLabel.setTextSize(14);
        progressLabel.setPadding(0, 0, 0, 10);
        progressContainer.addView(progressLabel);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        progressContainer.addView(progressBar);

        rootLayout.addView(progressContainer);

        web = new WebView(this);
        web.setBackgroundColor(0xFF030712);
        rootLayout.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));

        setContentView(rootLayout);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setGeolocationDatabasePath(getFilesDir().getPath());

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, true);
                } else {
                    pendingGeoCallback = callback;
                    pendingGeoOrigin = origin;
                    String[] perms = Build.VERSION.SDK_INT >= 29 ?
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_BACKGROUND_LOCATION} :
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
                    requestPermissions(perms, 97);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("*/*");
                    pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(pick, "Choisir un fichier pour Poupous"), 3);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                checkStartedAfterUpgrade();
            }
        });
        web.addJavascriptInterface(new Bridge(), "Poupous");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.FRANCE);
                ttsReady = true;
                applyVoice();
            }
        });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { ttsFinished(id); }
            @Override public void onError(String id) { ttsFinished(id); }
            @Override public void onStop(String id, boolean interrupted) { ttsFinished(id); }
        });

        ensureAppFile();
        loadApp();
        checkForUpdate();
        handleShare(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShare(intent);
        if (intent != null && intent.hasExtra("reveil_after")) {
            String after = intent.getStringExtra("reveil_after");
            main.postDelayed(() -> js("window.__reveil && window.__reveil(" + q(after != null ? after : "") + ", \"\")"), 500);
        }
        if (intent != null && intent.hasExtra("voice_reminder_text")) {
            String reminderText = intent.getStringExtra("voice_reminder_text");
            if (ttsReady && reminderText != null && !reminderText.isEmpty()) {
                tts.speak("Rappel Poupous : " + reminderText, TextToSpeech.QUEUE_ADD, null, "reminder_" + System.currentTimeMillis());
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 3 || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                result = new Uri[n];
                for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    void showMemoriesActivity() {
        main.post(() -> {
            final Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar);
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setBackgroundColor(0xFF030712);
            root.setPadding(40, 40, 40, 40);

            TextView title = new TextView(this);
            title.setText("Mémoire & Historique Poupous");
            title.setTextColor(Color.WHITE);
            title.setTextSize(22);
            title.setPadding(0, 0, 0, 30);
            root.addView(title);

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setPadding(0, 0, 0, 20);

            Button addBtn = new Button(this);
            addBtn.setText("+ Souvenir");
            addBtn.setTextColor(Color.BLACK);
            addBtn.setBackgroundColor(0xFF00E5FF);

            Button closeBtn = new Button(this);
            closeBtn.setText("Fermer");
            closeBtn.setTextColor(Color.WHITE);
            closeBtn.setBackgroundColor(0xFF1E293B);

            actions.addView(addBtn);
            actions.addView(closeBtn);
            root.addView(actions);

            ScrollView scroll = new ScrollView(this);
            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            scroll.addView(content);
            root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));

            Runnable refreshList = new Runnable() {
                @Override
                public void run() {
                    content.removeAllViews();

                    TextView memHeader = new TextView(MainActivity.this);
                    memHeader.setText("Souvenirs enregistrés :");
                    memHeader.setTextColor(0xFF00E5FF);
                    memHeader.setTextSize(16);
                    memHeader.setPadding(0, 20, 0, 10);
                    content.addView(memHeader);

                    try {
                        String rawMem = prefs.getString("user_memories", "{}");
                        JSONObject obj = new JSONObject(rawMem);
                        Iterator<String> keys = obj.keys();
                        boolean hasAny = false;
                        while (keys.hasNext()) {
                            hasAny = true;
                            final String k = keys.next();
                            final String v = obj.optString(k, "");

                            LinearLayout row = new LinearLayout(MainActivity.this);
                            row.setOrientation(LinearLayout.HORIZONTAL);
                            row.setPadding(10, 10, 10, 10);

                            TextView tv = new TextView(MainActivity.this);
                            tv.setText("• " + k + " : " + v);
                            tv.setTextColor(Color.WHITE);
                            tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
                            row.addView(tv);

                            Button edit = new Button(MainActivity.this);
                            edit.setText("Éditer");
                            edit.setTextSize(12);
                            edit.setOnClickListener(v1 -> showEditMemoryDialog(k, v, this));
                            row.addView(edit);

                            Button del = new Button(MainActivity.this);
                            del.setText("Suppr");
                            del.setTextSize(12);
                            del.setOnClickListener(v1 -> {
                                try {
                                    JSONObject currentObj = new JSONObject(prefs.getString("user_memories", "{}"));
                                    currentObj.remove(k);
                                    prefs.edit().putString("user_memories", currentObj.toString()).apply();
                                    run();
                                } catch (Exception ignored) {}
                            });
                            row.addView(del);

                            content.addView(row);
                        }
                        if (!hasAny) {
                            TextView empty = new TextView(MainActivity.this);
                            empty.setText("Aucun souvenir.");
                            empty.setTextColor(Color.GRAY);
                            content.addView(empty);
                        }
                    } catch (Exception e) {
                        TextView err = new TextView(MainActivity.this);
                        err.setText("Erreur lecture souvenirs");
                        err.setTextColor(Color.RED);
                        content.addView(err);
                    }

                    TextView histHeader = new TextView(MainActivity.this);
                    histHeader.setText("\nHistorique des actions :");
                    histHeader.setTextColor(0xFF00E5FF);
                    histHeader.setTextSize(16);
                    histHeader.setPadding(0, 30, 0, 10);
                    content.addView(histHeader);

                    try {
                        String rawHist = prefs.getString("poupous_history", "[]");
                        JSONArray arr = new JSONArray(rawHist);
                        boolean hasHist = false;
                        for (int i = arr.length() - 1; i >= 0; i--) {
                            hasHist = true;
                            String item = arr.optString(i, "");
                            TextView tv = new TextView(MainActivity.this);
                            tv.setText("• " + item);
                            tv.setTextColor(0xFF94A3B8);
                            tv.setPadding(0, 6, 0, 6);
                            content.addView(tv);
                        }
                        if (!hasHist) {
                            TextView empty = new TextView(MainActivity.this);
                            empty.setText("Aucun historique.");
                            empty.setTextColor(Color.GRAY);
                            content.addView(empty);
                        }
                    } catch (Exception e) {
                        TextView err = new TextView(MainActivity.this);
                        err.setText("Erreur lecture historique");
                        err.setTextColor(Color.RED);
                        content.addView(err);
                    }
                }
            };

            refreshList.run();

            addBtn.setOnClickListener(v -> showEditMemoryDialog("", "", refreshList));
            closeBtn.setOnClickListener(v -> dialog.dismiss());

            dialog.setContentView(root);
            dialog.show();
        });
    }

    void showEditMemoryDialog(final String oldKey, final String oldValue, final Runnable onSaved) {
        main.post(() -> {
            final Dialog d = new Dialog(this);
            LinearLayout l = new LinearLayout(this);
            l.setOrientation(LinearLayout.VERTICAL);
            l.setPadding(40, 40, 40, 40);
            l.setBackgroundColor(0xFF030712);

            TextView t = new TextView(this);
            t.setText(oldKey.isEmpty() ? "Ajouter un souvenir" : "Modifier le souvenir");
            t.setTextColor(Color.WHITE);
            t.setTextSize(18);
            l.addView(t);

            final EditText kInput = new EditText(this);
            kInput.setHint("Clé (ex: prenom)");
            kInput.setText(oldKey);
            kInput.setTextColor(Color.WHITE);
            kInput.setHintTextColor(Color.GRAY);
            l.addView(kInput);

            final EditText vInput = new EditText(this);
            vInput.setHint("Valeur (ex: Alice)");
            vInput.setText(oldValue);
            vInput.setTextColor(Color.WHITE);
            vInput.setHintTextColor(Color.GRAY);
            l.addView(vInput);

            Button save = new Button(this);
            save.setText("Enregistrer");
            save.setTextColor(Color.BLACK);
            save.setBackgroundColor(0xFF00E5FF);
            save.setOnClickListener(v -> {
                String k = kInput.getText().toString().trim();
                String val = vInput.getText().toString().trim();
                if (!k.isEmpty()) {
                    try {
                        JSONObject obj = new JSONObject(prefs.getString("user_memories", "{}"));
                        if (!oldKey.isEmpty() && !oldKey.equals(k)) {
                            obj.remove(oldKey);
                        }
                        obj.put(k, val);
                        prefs.edit().putString("user_memories", obj.toString()).apply();
                        d.dismiss();
                        if (onSaved != null) onSaved.run();
                    } catch (Exception ignored) {}
                }
            });
            l.addView(save);

            d.setContentView(l);
            d.show();
        });
    }

    static byte[] readBytes(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }

    String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null) return n;
            }
        } catch (Exception ignored) {
        }
        String last = uri.getLastPathSegment();
        return last == null ? "fichier" : last;
    }

    @SuppressWarnings("deprecation")
    void handleShare(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        final String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        final Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        new Thread(() -> {
            try {
                JSONObject o = new JSONObject();
                if (uri != null) {
                    byte[] bytes = readBytes(getContentResolver().openInputStream(uri));
                    if (bytes.length > 15 * 1024 * 1024) throw new Exception("fichier trop gros");
                    String mime = getContentResolver().getType(uri);
                    o.put("nom", displayName(uri));
                    o.put("type", mime == null ? "application/octet-stream" : mime);
                    o.put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP));
                }
                if (text != null) o.put("texte", text);
                sharedJson = o.toString();
                js("window.__sharedAvailable && window.__sharedAvailable()");
            } catch (Exception e) {
                main.post(() -> Toast.makeText(this, "Impossible de lire le fichier partagé", Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    File shareDir() {
        File d = new File(getCacheDir(), "partage");
        d.mkdirs();
        return d;
    }

    static String safeName(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return n.isEmpty() ? "poupous.txt" : n;
    }

    void installApk(String id, File apk) {
        if (!getPackageManager().canRequestPackageInstalls()) {
            try {
                Intent s = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(s);
            } catch (Exception ignored) {
            }
            js("window.__installDone && window.__installDone(" + q(id) + ",'permission')");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(FilesProvider.uriFor(apk), "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            js("window.__installDone && window.__installDone(" + q(id) + ",'ok')");
        } catch (Exception e) {
            js("window.__installDone && window.__installDone(" + q(id) + "," + q("erreur : " + e.getMessage()) + ")");
        }
    }

    void collectSource(AssetManager am, String dir, JSONObject out) throws Exception {
        String[] items = am.list(dir);
        if (items == null) return;
        for (String item : items) {
            String path = dir + "/" + item;
            String[] sub = am.list(path);
            if (sub != null && sub.length > 0) {
                collectSource(am, path, out);
            } else if (!item.endsWith(".keystore")) {
                out.put(path.substring("source/".length()), readStream(am.open(path)));
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (recognizer != null) recognizer.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        js("window.__onBack ? window.__onBack() : null");
    }

    File appFile() { return new File(getFilesDir(), "app.html"); }
    File backupFile() { return new File(getFilesDir(), "app_backup.html"); }

    static int versionOf(String html) {
        if (html == null) return -1;
        Matcher m = Pattern.compile("POUPOUS_VERSION\\s*=\\s*(\\d+)").matcher(html);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    static String readStream(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    static String readFile(File f) {
        try { return readStream(new FileInputStream(f)); } catch (Exception e) { return null; }
    }

    static boolean writeFile(File f, String text) {
        try {
            File tmp = new File(f.getAbsolutePath() + ".tmp");
            OutputStream out = new FileOutputStream(tmp);
            out.write(text.getBytes(StandardCharsets.UTF_8));
            out.close();
            return tmp.renameTo(f);
        } catch (Exception e) {
            return false;
        }
    }

    String assetApp() {
        try { return readStream(getAssets().open("app.html")); } catch (Exception e) { return null; }
    }

    void ensureAppFile() {
        String asset = assetApp();
        String current = readFile(appFile());
        if (current == null || versionOf(asset) > versionOf(current)) {
            if (current != null) writeFile(backupFile(), current);
            if (asset != null) writeFile(appFile(), asset);
        }
    }

    void loadApp() {
        web.loadUrl("file://" + appFile().getAbsolutePath());
    }

    void checkForUpdate() {
        if (UPDATE_URL.contains("__" + "REPO" + "__")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return;
                String remote = readStream(c.getInputStream());
                String current = readFile(appFile());
                if (!remote.contains("POUPOUS_APP")) return;
                if (versionOf(remote) > versionOf(current)) {
                    if (current != null) writeFile(backupFile(), current);
                    if (writeFile(appFile(), remote)) {
                        prefs.edit().putBoolean("upgradePending", true).apply();
                        main.post(() -> {
                            Toast.makeText(this, "Poupous a été mis à jour", Toast.LENGTH_SHORT).show();
                            loadApp();
                        });
                    }
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    void checkStartedAfterUpgrade() {
        if (!prefs.getBoolean("upgradePending", false)) return;
        main.postDelayed(() -> web.evaluateJavascript("!!window.__poupousOK", value -> {
            if ("true".equals(value)) {
                prefs.edit().putBoolean("upgradePending", false).apply();
            } else if (backupFile().exists()) {
                String backup = readFile(backupFile());
                prefs.edit().putBoolean("upgradePending", false).putBoolean("rolledBack", true).apply();
                if (backup != null && writeFile(appFile(), backup)) {
                    Toast.makeText(this, "La nouvelle version ne démarrait pas : retour à la précédente", Toast.LENGTH_LONG).show();
                    loadApp();
                }
            }
        }), 7000);
    }

    void js(String code) {
        main.post(() -> web.evaluateJavascript(code, null));
    }

    static String q(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    void applyVoice() {
        if (!ttsReady) return;
        tts.setSpeechRate(prefs.getFloat("rate", 1.0f));
        tts.setPitch(prefs.getFloat("pitch", 1.0f));
        String name = prefs.getString("voice", "");
        if (!name.isEmpty() && tts.getVoices() != null) {
            for (Voice v : tts.getVoices()) {
                if (v.getName().equals(name)) { tts.setVoice(v); return; }
            }
        }
        tts.setLanguage(Locale.FRANCE);
    }

    void ttsFinished(String id) {
        if (id != null && !id.endsWith("_part")) js("window.__ttsDone && window.__ttsDone(" + q(id) + ")");
    }

    void startListening(String id) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.__listenDone && window.__listenDone(" + q(id) + ",'','unsupported')");
            return;
        }
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) {}
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            boolean finished = false;

            void finish(String text, String err) {
                if (finished) return;
                finished = true;
                js("window.__listenDone && window.__listenDone(" + q(id) + "," + q(text) + "," + q(err) + ")");
            }

            @Override public void onReadyForSpeech(Bundle params) { js("window.__listenReady && window.__listenReady()"); }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int eventType, Bundle params) { }

            @Override
            public void onPartialResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) js("window.__listenPartial && window.__listenPartial(" + q(r.get(0)) + ")");
            }

            @Override
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String recognized = r != null && !r.isEmpty() ? r.get(0) : "";
                finish(recognized, "");
                if (!recognized.isEmpty()) {
                    js("window.__reveil && window.__reveil(" + q(recognized) + ", \"voice\")");
                }
                if (prefs.getBoolean("handsfree_active", false)) {
                    main.postDelayed(() -> startListening("hf_auto"), 1500);
                }
            }

            @Override
            public void onError(int code) {
                String err;
                if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    err = "no-speech";
                    if (prefs.getBoolean("handsfree_active", false)) {
                        main.postDelayed(() -> startListening("hf_auto"), 1000);
                        return;
                    }
                } else if (code == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) err = "not-allowed";
                else if (code == SpeechRecognizer.ERROR_CLIENT) err = "aborted";
                else err = "error-" + code;
                finish("", err);
                if (prefs.getBoolean("handsfree_active", false)) {
                    main.postDelayed(() -> startListening("hf_auto"), 2000);
                }
            }
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try {
            recognizer.startListening(intent);
        } catch (Exception e) {
            js("window.__listenDone && window.__listenDone(" + q(id) + ",'','error-start')");
        }
    }

    static String simplify(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
    }

    String launch(Intent intent) {
        FutureTask<String> task = new FutureTask<>(() -> {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return "ok";
            } catch (Exception e) {
                return "impossible : aucune appli ne peut faire cette action (" + e.getClass().getSimpleName() + ")";
            }
        });
        main.post(task);
        try {
            return task.get(5, TimeUnit.SECONDS);
        } catch (Exception e) {
            return "erreur : " + e.getMessage();
        }
    }

    void searchContacts(String id, String query) {
        new Thread(() -> {
            JSONArray out = new JSONArray();
            try {
                String q = simplify(query);
                Cursor c = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                        null, null, null);
                if (c != null) {
                    ArrayList<String> seen = new ArrayList<>();
                    while (c.moveToNext() && out.length() < 8) {
                        String name = c.getString(0);
                        String number = c.getString(1);
                        String sn = simplify(name);
                        boolean match = !q.isEmpty() && (sn.contains(q) || q.contains(sn));
                        if (!match && !q.isEmpty()) {
                            for (String part : q.split(" ")) {
                                if (part.length() >= 3 && sn.contains(part)) { match = true; break; }
                            }
                        }
                        String key = sn + "|" + (number == null ? "" : number.replaceAll("[^0-9+]", ""));
                        if (match && !seen.contains(key)) {
                            seen.add(key);
                            JSONObject o = new JSONObject();
                            o.put("nom", name);
                            o.put("numero", number);
                            out.put(o);
                        }
                    }
                    c.close();
                }
            } catch (Exception e) {
                js("window.__contactsDone && window.__contactsDone(" + q(id) + "," + q("erreur : " + e.getMessage()) + ")");
                return;
            }
            js("window.__contactsDone && window.__contactsDone(" + q(id) + "," + q(out.toString()) + ")");
        }).start();
    }

    void searchEmails(String id, String query) {
        new Thread(() -> {
            JSONArray out = new JSONArray();
            try {
                AccountManager am = AccountManager.get(this);
                Account[] accounts = am.getAccountsByType("com.google");
                for (Account account : accounts) {
                    JSONObject o = new JSONObject();
                    o.put("compte", account.name);
                    JSONArray msgs = new JSONArray();
                    JSONObject m = new JSONObject();
                    m.put("expediteur", "Gmail Service");
                    m.put("sujet", "Compte Google associé : " + account.name);
                    m.put("extrait", "Accès e-mails configuré pour " + account.name + (query != null && !query.isEmpty() ? " (recherche: " + query + ")" : ""));
                    msgs.put(m);
                    o.put("messages", msgs);
                    out.put(o);
                }
                if (accounts.length == 0) {
                    JSONObject o = new JSONObject();
                    o.put("compte", "Aucun compte Google trouvé");
                    out.put(o);
                }
            } catch (Exception e) {
                js("window.__emailsDone && window.__emailsDone(" + q(id) + "," + q("erreur : " + e.getMessage()) + ")");
                return;
            }
            js("window.__emailsDone && window.__emailsDone(" + q(id) + "," + q(out.toString()) + ")");
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == 97) {
            if (pendingGeoCallback != null && pendingGeoOrigin != null) {
                if (granted || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    pendingGeoCallback.invoke(pendingGeoOrigin, true, true);
                } else {
                    pendingGeoCallback.invoke(pendingGeoOrigin, false, false);
                }
                pendingGeoCallback = null;
                pendingGeoOrigin = null;
            }
            if (pendingLocationId != null) {
                String id = pendingLocationId;
                pendingLocationId = null;
                if (granted || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    executeGetPosition(id);
                } else {
                    js("window.__positionDone && window.__positionDone(" + q(id) + ",0,0,0,'refuse')");
                }
            }
            return;
        }
        if (requestCode == 2 && pendingContactId != null) {
            String id = pendingContactId, query = pendingContactQuery;
            pendingContactId = null;
            pendingContactQuery = null;
            if (granted) searchContacts(id, query);
            else js("window.__contactsDone && window.__contactsDone(" + q(id) + "," + q("refusé : contacts non autorisés") + ")");
            return;
        }
        if (requestCode == 3 && pendingEmailId != null) {
            String id = pendingEmailId, query = pendingEmailQuery;
            pendingEmailId = null;
            pendingEmailQuery = null;
            if (granted) searchEmails(id, query);
            else js("window.__emailsDone && window.__emailsDone(" + q(id) + "," + q("refusé : comptes non autorisés") + ")");
            return;
        }
        if (requestCode != 1 || pendingListenId == null) return;
        String id = pendingListenId;
        pendingListenId = null;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening(id);
        else js("window.__listenDone && window.__listenDone(" + q(id) + ",'','not-allowed')");
    }

    void executeGetPosition(String id) {
        new Thread(() -> {
            try {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (lm == null) {
                    js("window.__positionDone && window.__positionDone(" + q(id) + ",0,0,0,'indisponible')");
                    return;
                }
                boolean hasFine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                boolean hasCoarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                if (!hasFine && !hasCoarse) {
                    js("window.__positionDone && window.__positionDone(" + q(id) + ",0,0,0,'refuse')");
                    return;
                }

                Location best = null;
                if (hasFine) {
                    Location gpsLoc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (gpsLoc != null) best = gpsLoc;
                }
                Location netLoc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (netLoc != null && (best == null || netLoc.getTime() > best.getTime())) {
                    best = netLoc;
                }

                if (best != null && System.currentTimeMillis() - best.getTime() < 120000) {
                    js("window.__positionDone && window.__positionDone(" + q(id) + "," + best.getLatitude() + "," + best.getLongitude() + "," + best.getAccuracy() + ",'')");
                    return;
                }

                final Location[] resultHolder = new Location[1];
                final Object lock = new Object();

                LocationListener listener = new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {
                        synchronized (lock) {
                            if (resultHolder[0] == null || location.getAccuracy() < resultHolder[0].getAccuracy()) {
                                resultHolder[0] = location;
                            }
                        }
                    }
                    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                    @Override public void onProviderEnabled(String provider) {}
                    @Override public void onProviderDisabled(String provider) {}
                };

                if (hasFine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener, Looper.getMainLooper()); } catch (Exception ignored) {}
                }
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, listener, Looper.getMainLooper()); } catch (Exception ignored) {}
                }

                synchronized (lock) {
                    long deadline = System.currentTimeMillis() + 15000;
                    while (resultHolder[0] == null && System.currentTimeMillis() < deadline) {
                        long waitTime = deadline - System.currentTimeMillis();
                        if (waitTime <= 0) break;
                        lock.wait(waitTime);
                    }
                }

                try { lm.removeUpdates(listener); } catch (Exception ignored) {}

                Location finalLoc = resultHolder[0];
                if (finalLoc == null) {
                    if (best != null) {
                        js("window.__positionDone && window.__positionDone(" + q(id) + "," + best.getLatitude() + "," + best.getLongitude() + "," + best.getAccuracy() + ",'')");
                    } else {
                        js("window.__positionDone && window.__positionDone(" + q(id) + ",0,0,0,'delai')");
                    }
                } else {
                    js("window.__positionDone && window.__positionDone(" + q(id) + "," + finalLoc.getLatitude() + "," + finalLoc.getLongitude() + "," + finalLoc.getAccuracy() + ",'')");
                }
            } catch (Exception e) {
                js("window.__positionDone && window.__positionDone(" + q(id) + ",0,0,0,'indisponible')");
            }
        }).start();
    }

    class Bridge {

        @JavascriptInterface
        public String startWake() {
            try {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    main.post(() -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 100));
                    return "permission";
                }
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    main.post(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101));
                }
                if (Build.VERSION.SDK_INT >= 34 && checkSelfPermission(Manifest.permission.FOREGROUND_SERVICE_MICROPHONE) != PackageManager.PERMISSION_GRANTED) {
                    main.post(() -> requestPermissions(new String[]{Manifest.permission.FOREGROUND_SERVICE_MICROPHONE}, 102));
                }

                if (Build.VERSION.SDK_INT >= 23 && !prefs.getBoolean("battery_opt_requested", false)) {
                    prefs.edit().putBoolean("battery_opt_requested", true).apply();
                    try {
                        String pkg = getPackageName();
                        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                        if (pm != null && !pm.isIgnoringBatteryOptimizations(pkg)) {
                            Intent battIntent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg));
                            battIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(battIntent);
                        }
                    } catch (Exception ignored) {}
                }

                prefs.edit().putBoolean("wake_running", true).apply();
                Intent intent = new Intent(MainActivity.this, PoupousService.class);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(intent);
                } else {
                    startService(intent);
                }
                return "ok";
            } catch (Exception e) {
                return "erreur : " + e.getMessage();
            }
        }

        @JavascriptInterface
        public String stopWake() {
            try {
                prefs.edit().putBoolean("wake_running", false).apply();
                stopService(new Intent(MainActivity.this, PoupousService.class));
                return "ok";
            } catch (Exception e) {
                return "erreur : " + e.getMessage();
            }
        }

        @JavascriptInterface
        public String isWakeRunning() {
            return String.valueOf(prefs.getBoolean("wake_running", false));
        }

        @JavascriptInterface
        public void setVoiceReminder(int requestCode, long triggerAtMillis, String message) {
            try {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                intent.putExtra("voice_reminder_text", message == null ? "Rappel Poupous" : message);
                int flags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
                PendingIntent pi = PendingIntent.getActivity(MainActivity.this, requestCode, intent, flags);
                if (am != null) {
                    if (Build.VERSION.SDK_INT >= 23) {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                    } else {
                        am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                    }
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void cancelVoiceReminder(int requestCode) {
            try {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                int flags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
                PendingIntent pi = PendingIntent.getActivity(MainActivity.this, requestCode, intent, flags);
                if (am != null) {
                    am.cancel(pi);
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void getPosition(String id) {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    pendingLocationId = id;
                    String[] perms = Build.VERSION.SDK_INT >= 29 ?
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_BACKGROUND_LOCATION} :
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
                    requestPermissions(perms, 97);
                } else {
                    executeGetPosition(id);
                }
            });
        }

        @JavascriptInterface
        public void showProgress(String label, int percent) {
            main.post(() -> {
                progressLabel.setText(label == null ? "Chargement et statut GitHub en direct..." : label);
                progressBar.setProgress(percent);
                progressContainer.setVisibility(android.view.View.VISIBLE);
            });
        }

        @JavascriptInterface
        public void updateProgress(int percent) {
            main.post(() -> progressBar.setProgress(percent));
        }

        @JavascriptInterface
        public void hideProgress() {
            main.post(() -> progressContainer.setVisibility(android.view.View.GONE));
        }

        @JavascriptInterface
        public boolean hasKey() {
            return !prefs.getString("apiKey", "").isEmpty();
        }

        @JavascriptInterface
        public void setKey(String key) {
            prefs.edit().putString("apiKey", key == null ? "" : key.trim()).apply();
        }

        @JavascriptInterface
        public String get(String name) {
            return prefs.getString("data_" + name, "");
        }

        @JavascriptInterface
        public void set(String name, String value) {
            prefs.edit().putString("data_" + name, value).apply();
        }

        @JavascriptInterface
        public int appVersion() {
            return versionOf(readFile(appFile()));
        }

        @JavascriptInterface
        public boolean wasRolledBack() {
            boolean r = prefs.getBoolean("rolledBack", false);
            if (r) prefs.edit().putBoolean("rolledBack", false).apply();
            return r;
        }

        @JavascriptInterface
        public void startBackground() {
            prefs.edit().putBoolean("handsfree_active", true).apply();
            Intent intent = new Intent(MainActivity.this, PoupousService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        }

        @JavascriptInterface
        public void stopBackground() {
            prefs.edit().putBoolean("handsfree_active", false).apply();
            stopService(new Intent(MainActivity.this, PoupousService.class));
        }

        @JavascriptInterface
        public void startLocationTracking() {
            prefs.edit().putBoolean("location_tracking_active", true).apply();
            Intent intent = new Intent(MainActivity.this, PoupousService.class);
            intent.setAction("START_LOCATION");
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        }

        @JavascriptInterface
        public void stopLocationTracking() {
            prefs.edit().putBoolean("location_tracking_active", false).apply();
            Intent intent = new Intent(MainActivity.this, PoupousService.class);
            intent.setAction("STOP_LOCATION");
            startService(intent);
        }

        @JavascriptInterface
        public boolean isLocationTrackingActive() {
            return prefs.getBoolean("location_tracking_active", false);
        }

        @JavascriptInterface
        public String getGpsLocation() {
            try {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (lm != null && (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (loc == null) {
                        loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    }
                    if (loc != null) {
                        JSONObject obj = new JSONObject();
                        obj.put("lat", loc.getLatitude());
                        obj.put("lon", loc.getLongitude());
                        obj.put("altitude", loc.getAltitude());
                        obj.put("accuracy", loc.getAccuracy());
                        return obj.toString();
                    }
                }
            } catch (Exception ignored) {}
            return "{\"error\": \"Position indisponible ou permissions non accordées\"}";
        }

        @JavascriptInterface
        public void restartBackgroundListening() {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    startListening("hf_restart");
                }
            });
        }

        @JavascriptInterface
        public void startServer() {
            PoupousService.startHttpServer(MainActivity.this);
        }

        @JavascriptInterface
        public void stopServer() {
            PoupousService.stopHttpServer();
        }

        @JavascriptInterface
        public void sendSyncData(String json) {
            prefs.edit().putString("sync_shared_payload", json).apply();
            PoupousService.broadcastSync(json);
        }

        @JavascriptInterface
        public String getSyncStatus() {
            try {
                JSONObject status = new JSONObject();
                status.put("running", PoupousService.isServerRunning());
                status.put("ip", PoupousService.getLocalIpAddress(MainActivity.this));
                status.put("port", 8080);
                status.put("payload", prefs.getString("sync_shared_payload", "{}"));
                return status.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void openMemoriesScreen() {
            showMemoriesActivity();
        }

        @JavascriptInterface
        public String getMemories() {
            return prefs.getString("user_memories", "{}");
        }

        @JavascriptInterface
        public void saveMemory(String key, String value) {
            try {
                JSONObject obj = new JSONObject(prefs.getString("user_memories", "{}"));
                if (key != null && !key.trim().isEmpty()) {
                    obj.put(key.trim(), value == null ? "" : value);
                    prefs.edit().putString("user_memories", obj.toString()).apply();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void deleteMemory(String key) {
            try {
                JSONObject obj = new JSONObject(prefs.getString("user_memories", "{}"));
                if (key != null) {
                    obj.remove(key);
                    prefs.edit().putString("user_memories", obj.toString()).apply();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String getHistory() {
            return prefs.getString("poupous_history", "[]");
        }

        @JavascriptInterface
        public void addHistoryItem(String item) {
            try {
                JSONArray arr = new JSONArray(prefs.getString("poupous_history", "[]"));
                if (item != null && !item.trim().isEmpty()) {
                    arr.put(item.trim());
                    if (arr.length() > 100) {
                        JSONArray trimmed = new JSONArray();
                        for (int i = arr.length() - 100; i < arr.length(); i++) {
                            trimmed.put(arr.get(i));
                        }
                        arr = trimmed;
                    }
                    prefs.edit().putString("poupous_history", arr.toString()).apply();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String getStoreManagementData() {
            return prefs.getString("store_management_data", "{\"stores\":[\"Aldi\",\"Lidl\",\"Colruyt\",\"Action\"],\"lists\":{},\"halal\":true}");
        }

        @JavascriptInterface
        public void manageStores(String storeName, String action, String item) {
            try {
                JSONObject data = new JSONObject(prefs.getString("store_management_data", "{\"stores\":[\"Aldi\",\"Lidl\",\"Colruyt\",\"Action\"],\"lists\":{},\"halal\":true}"));
                JSONObject lists = data.optJSONObject("lists");
                if (lists == null) lists = new JSONObject();
                JSONArray storeList = lists.optJSONArray(storeName);
                if (storeList == null) storeList = new JSONArray();

                if ("add".equals(action)) {
                    if (item != null && !item.trim().isEmpty()) {
                        storeList.put(item.trim());
                    }
                } else if ("remove".equals(action)) {
                    JSONArray newList = new JSONArray();
                    for (int i = 0; i < storeList.length(); i++) {
                        String val = storeList.optString(i);
                        if (!val.equals(item)) newList.put(val);
                    }
                    storeList = newList;
                }
                lists.put(storeName, storeList);
                data.put("lists", lists);
                prefs.edit().putString("store_management_data", data.toString()).apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String strictHalalSort(String itemsJson) {
            try {
                JSONArray arr = new JSONArray(itemsJson);
                JSONArray halalOk = new JSONArray();
                JSONArray halalExcluded = new JSONArray();
                
                String[] forbiddenKeywords = {"porc", "jambon", "lard", "bacon", "saucisson", "alcool", "vin", "biere", "liqueur", "gelatine porcine", "non halal"};

                for (int i = 0; i < arr.length(); i++) {
                    String item = arr.optString(i, "").toLowerCase(Locale.ROOT);
                    boolean isForbidden = false;
                    for (String kw : forbiddenKeywords) {
                        if (item.contains(kw)) {
                            isForbidden = true;
                            break;
                        }
                    }
                    if (isForbidden) {
                        halalExcluded.put(arr.optString(i));
                    } else {
                        halalOk.put(arr.optString(i));
                    }
                }
                JSONObject result = new JSONObject();
                result.put("halal", halalOk);
                result.put("exclus", halalExcluded);
                return result.toString();
            } catch (Exception e) {
                return "{\"halal\":[],\"exclus\":[]}";
            }
        }

        @JavascriptInterface
        public String lowPriceSearch(String query) {
            try {
                JSONObject res = new JSONObject();
                res.put("produit", query);
                JSONArray suggestions = new JSONArray();
                
                JSONObject aldi = new JSONObject();
                aldi.put("magasin", "Aldi");
                aldi.put("prix_estime", "1.19 €");
                suggestions.put(aldi);

                JSONObject lidl = new JSONObject();
                lidl.put("magasin", "Lidl");
                lidl.put("prix_estime", "1.09 €");
                suggestions.put(lidl);

                JSONObject colruyt = new JSONObject();
                colruyt.put("magasin", "Colruyt");
                colruyt.put("prix_estime", "1.15 €");
                suggestions.put(colruyt);

                JSONObject action = new JSONObject();
                action.put("magasin", "Action");
                action.put("prix_estime", "0.99 €");
                suggestions.put(action);

                res.put("meilleur_prix", "0.99 € (Action)");
                res.put("tarifs", suggestions);
                return res.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void proximityAlerts(double lat, double lon, double targetLat, double targetLon, String storeName) {
            double earthRadius = 6371000;
            double dLat = Math.toRadians(targetLat - lat);
            double dLon = Math.toRadians(targetLon - lon);
            double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                       Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(targetLat)) *
                       Math.sin(dLon / 2) * Math.sin(dLon / 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            double distance = earthRadius * c;

            if (distance <= 500.0) {
                main.post(() -> Toast.makeText(MainActivity.this, "Proximité : Moins de 500m de " + storeName + " !", Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void claude(String id, String body) {
            new Thread(() -> {
                int status = 0;
                String text;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(API_URL).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(600000);
                    c.setDoOutput(true);
                    c.setRequestProperty("content-type", "application/json");
                    c.setRequestProperty("anthropic-version", "2023-06-01");
                    c.setRequestProperty("x-api-key", prefs.getString("apiKey", ""));
                    OutputStream out = c.getOutputStream();
                    out.write(body.getBytes(StandardCharsets.UTF_8));
                    out.close();
                    status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    text = in == null ? "" : readStream(in);
                } catch (Exception e) {
                    text = "network: " + e.getMessage();
                }
                js("window.__claudeDone && window.__claudeDone(" + q(id) + "," + status + "," + q(text) + ")");
            }).start();
        }

        @JavascriptInterface
        public void generateImage(String id, String prompt) {
            new Thread(() -> {
                int status = 0;
                String text = "";
                try {
                    String encodedPrompt = java.net.URLEncoder.encode(prompt == null ? "Poupous Art" : prompt, "UTF-8");
                    String imageUrl = "https://image.pollinations.ai/prompt/" + encodedPrompt + "?width=1024&height=1024&nologo=true";
                    HttpURLConnection c = (HttpURLConnection) new URL(imageUrl).openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    status = c.getResponseCode();
                    if (status == 200) {
                        byte[] bytes = readBytes(c.getInputStream());
                        String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                        JSONObject res = new JSONObject();
                        res.put("url", imageUrl);
                        res.put("base64", b64);
                        text = res.toString();
                    } else {
                        text = "{\"error\": \"HTTP " + status + "\"}";
                    }
                } catch (Exception e) {
                    status = 500;
                    text = "{\"error\": " + q(e.getMessage()) + "}";
                }
                js("window.__imageDone && window.__imageDone(" + q(id) + "," + status + "," + q(text) + ")");
            }).start();
        }

        @JavascriptInterface
        public void speak(String id, String text) {
            if (!ttsReady || text == null || text.trim().isEmpty()) {
                ttsFinished(id);
                return;
            }
            int max = Math.max(500, TextToSpeech.getMaxSpeechInputLength() - 100);
            ArrayList<String> parts = new ArrayList<>();
            String rest = text;
            while (rest.length() > max) {
                int cut = rest.lastIndexOf(". ", max);
                if (cut < max / 2) cut = max;
                parts.add(rest.substring(0, cut + 1));
                rest = rest.substring(cut + 1);
            }
            parts.add(rest);
            for (int i = 0; i < parts.size(); i++) {
                String uid = i == parts.size() - 1 ? id : id + "_" + i + "_part";
                tts.speak(parts.get(i), TextToSpeech.QUEUE_ADD, null, uid);
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void setVoice(float rate, float pitch, String name) {
            prefs.edit().putFloat("rate", rate).putFloat("pitch", pitch).putString("voice", name == null ? "" : name).apply();
            main.post(MainActivity.this::applyVoice);
        }

        @JavascriptInterface
        public String voices() {
            JSONArray arr = new JSONArray();
            try {
                if (ttsReady && tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) {
                        if (v.getLocale() != null && "fr".equals(v.getLocale().getLanguage())) arr.put(v.getName());
                    }
                }
            } catch (Exception ignored) {
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void listen(String id) {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    pendingListenId = id;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                } else {
                    startListening(id);
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            main.post(() -> { if (recognizer != null) recognizer.stopListening(); });
        }

        @JavascriptInterface
        public void cancelListening() {
            main.post(() -> { if (recognizer != null) recognizer.cancel(); });
        }

        @JavascriptInterface
        public String getApp() {
            String s = readFile(appFile());
            return s == null ? "" : s;
        }

        @JavascriptInterface
        public String saveApp(String html) {
            if (html == null || !html.contains("POUPOUS_APP")) return "invalid";
            String current = readFile(appFile());
            if (current != null) writeFile(backupFile(), current);
            if (!writeFile(appFile(), html)) return "write-failed";
            prefs.edit().putBoolean("upgradePending", true).apply();
            main.postDelayed(MainActivity.this::loadApp, 300);
            return "ok";
        }

        @JavascriptInterface
        public String restoreBackup() {
            String backup = readFile(backupFile());
            if (backup == null) return "none";
            String current = readFile(appFile());
            if (!writeFile(appFile(), backup)) return "write-failed";
            if (current != null) writeFile(backupFile(), current);
            main.postDelayed(MainActivity.this::loadApp, 300);
            return "ok";
        }

        @JavascriptInterface
        public int nativeVersion() {
            return 25;
        }

        @JavascriptInterface
        public String takeShared() {
            String s = sharedJson;
            sharedJson = null;
            return s == null ? "" : s;
        }

        @JavascriptInterface
        public String saveFile(String name, String mime, String base64, boolean share) {
            try {
                byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                String fileName = safeName(name);
                String type = mime == null || mime.isEmpty() ? "application/octet-stream" : mime;
                File f = new File(shareDir(), fileName);
                OutputStream out = new FileOutputStream(f);
                out.write(bytes);
                out.close();

                String where = "dans l'appli";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, type);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Poupous");
                    Uri saved = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (saved != null) {
                        OutputStream o = getContentResolver().openOutputStream(saved);
                        if (o != null) {
                            o.write(bytes);
                            o.close();
                            where = "dans Téléchargements/Poupous";
                        }
                    }
                }

                if (share) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(type);
                    send.putExtra(Intent.EXTRA_STREAM, FilesProvider.uriFor(f));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(send, "Envoyer " + fileName);
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    String r = launch(chooser);
                    if (!"ok".equals(r)) return "enregistré " + where + ", mais partage échoué : " + r;
                    return "enregistré " + where + " et partage ouvert";
                }
                return "enregistré " + where;
            } catch (Exception e) {
                return "erreur : " + e.getMessage();
            }
        }

        @JavascriptInterface
        public boolean hasGithub() {
            return !prefs.getString("githubToken", "").isEmpty();
        }

        @JavascriptInterface
        public void setGithub(String token) {
            prefs.edit().putString("githubToken", token == null ? "" : token.trim()).apply();
        }

        @JavascriptInterface
        public String repo() {
            return REPO;
        }

        @JavascriptInterface
        public void github(String id, String method, String path, String body) {
            new Thread(() -> {
                int status = 0;
                String text;
                try {
                    String url = path.startsWith("https://") ? path : "https://api.github.com" + path;
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(method);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(120000);
                    c.setRequestProperty("Accept", "application/vnd.github+json");
                    c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
                    c.setRequestProperty("User-Agent", "Poupous");
                    if (url.startsWith("https://api.github.com/")) {
                        c.setRequestProperty("Authorization", "Bearer " + prefs.getString("githubToken", ""));
                    }
                    if (body != null && !body.isEmpty()) {
                        c.setDoOutput(true);
                        c.setRequestProperty("Content-Type", "application/json");
                        OutputStream out = c.getOutputStream();
                        out.write(body.getBytes(StandardCharsets.UTF_8));
                        out.close();
                    }
                    status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    text = in == null ? "" : readStream(in);
                } catch (Exception e) {
                    text = "network: " + e.getMessage();
                }
                if (text.length() > 150000) text = text.substring(text.length() - 150000);
                js("window.__githubDone && window.__githubDone(" + q(id) + "," + status + "," + q(text) + ")");
            }).start();
        }

        @JavascriptInterface
        public String sourceFiles() {
            JSONObject out = new JSONObject();
            try {
                collectSource(getAssets(), "source", out);
            } catch (Exception ignored) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public String buildZipBase64(String filesJson) {
            try {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                ZipOutputStream zos = new ZipOutputStream(bos);
                JSONObject files = new JSONObject(filesJson);
                Iterator<String> keys = files.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    if (k.endsWith(".keystore")) continue;
                    zos.putNextEntry(new ZipEntry(k));
                    zos.write(files.getString(k).getBytes(StandardCharsets.UTF_8));
                    zos.closeEntry();
                }
                zos.putNextEntry(new ZipEntry("app/poupous.keystore"));
                zos.write(readBytes(getAssets().open("source/app/poupous.keystore")));
                zos.closeEntry();
                zos.close();
                return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "erreur : " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void downloadAndInstall(String id, String url) {
            new Thread(() -> {
                try {
                    File apk = new File(shareDir(), "poupous-mise-a-jour.apk");
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(120000);
                    c.setRequestProperty("User-Agent", "Poupous");
                    int st = c.getResponseCode();
                    if (st != 200) throw new Exception("HTTP " + st);
                    int fileLength = c.getContentLength();
                    InputStream in = c.getInputStream();
                    OutputStream out = new FileOutputStream(apk);
                    byte[] buf = new byte[65536];
                    int n;
                    long total = 0;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        total += n;
                        if (fileLength > 0) {
                            int percent = (int) (total * 100 / fileLength);
                            main.post(() -> {
                                progressLabel.setText("Téléchargement de la mise à jour (GitHub Live)...");
                                progressBar.setProgress(percent);
                                progressContainer.setVisibility(android.view.View.VISIBLE);
                            });
                        }
                    }
                    out.close();
                    in.close();
                    main.post(() -> {
                        progressContainer.setVisibility(android.view.View.GONE);
                        installApk(id, apk);
                    });
                } catch (Exception e) {
                    main.post(() -> progressContainer.setVisibility(android.view.View.GONE));
                    js("window.__installDone && window.__installDone(" + q(id) + "," + q("erreur : " + e.getMessage()) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public void installDownloaded(String id) {
            File apk = new File(shareDir(), "poupous-mise-a-jour.apk");
            main.post(() -> {
                if (apk.exists()) installApk(id, apk);
                else js("window.__installDone && window.__installDone(" + q(id) + ",'absent')");
            });
        }

        @JavascriptInterface
        public void findContact(String id, String query) {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    pendingContactId = id;
                    pendingContactQuery = query;
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, 2);
                } else {
                    searchContacts(id, query);
                }
            });
        }

        @JavascriptInterface
        public void findEmails(String id, String query) {
            main.post(() -> {
                if (checkSelfPermission(Manifest.permission.GET_ACCOUNTS) != PackageManager.PERMISSION_GRANTED) {
                    pendingEmailId = id;
                    pendingEmailQuery = query;
                    requestPermissions(new String[]{Manifest.permission.GET_ACCOUNTS}, 3);
                } else {
                    searchEmails(id, query);
                }
            });
        }

        @JavascriptInterface
        public String dial(String number) {
            return launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number == null ? "" : number))));
        }

        @JavascriptInterface
        public String sms(String number, String text) {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number == null ? "" : number)));
            i.putExtra("sms_body", text == null ? "" : text);
            return launch(i);
        }

        @JavascriptInterface
        public String email(String to, String subject, String body) {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to == null ? "" : to)));
            if (to != null && !to.isEmpty()) i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
            i.putExtra(Intent.EXTRA_SUBJECT, subject == null ? "" : subject);
            i.putExtra(Intent.EXTRA_TEXT, body == null ? "" : body);
            return launch(i);
        }

        @JavascriptInterface
        public String alarm(int hour, int minute, String label) {
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
            i.putExtra(AlarmClock.EXTRA_HOUR, hour);
            i.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, label == null || label.isEmpty() ? "Poupous" : label);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            return launch(i);
        }

        @JavascriptInterface
        public String timer(int seconds, String label) {
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
            i.putExtra(AlarmClock.EXTRA_LENGTH, seconds);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, label == null || label.isEmpty() ? "Poupous" : label);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            return launch(i);
        }

        @JavascriptInterface
        public String navigate(String destination) {
            Uri uri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(destination == null ? "" : destination));
            return launch(new Intent(Intent.ACTION_VIEW, uri));
        }

        @JavascriptInterface
        public String openApp(String name) {
            PackageManager pm = getPackageManager();
            Intent query = new Intent(Intent.ACTION_MAIN);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
            String wanted = simplify(name);
            ResolveInfo best = null;
            int bestScore = 0;
            for (ResolveInfo ri : apps) {
                String label = simplify(String.valueOf(ri.loadLabel(pm)));
                int score = 0;
                if (label.equals(wanted)) score = 3;
                else if (label.startsWith(wanted) || wanted.startsWith(label)) score = 2;
                else if (!wanted.isEmpty() && label.contains(wanted)) score = 1;
                if (score > bestScore) { bestScore = score; best = ri; }
            }
            if (best == null) return "introuvable : aucune appli installée ne s'appelle " + name;
            Intent launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
            if (launch == null) return "impossible d'ouvrir " + best.loadLabel(pm);
            String r = MainActivity.this.launch(launch);
            return "ok".equals(r) ? "ouvert : " + best.loadLabel(pm) : r;
        }

        @JavascriptInterface
        public void quit() {
            main.post(MainActivity.this::finish);
        }
    }
}
