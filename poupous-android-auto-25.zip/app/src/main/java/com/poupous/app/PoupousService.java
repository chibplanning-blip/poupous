package com.poupous.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

public class PoupousService extends Service implements LocationListener {
    static final String CHANNEL_ID = "poupous_service";

    static ServerSocket serverSocket;
    static volatile boolean serverRunning = false;
    static Socket activeClientSocket = null;

    LocationManager locationManager;
    boolean isTracking = false;

    SpeechRecognizer speechRecognizer;
    Handler serviceHandler;
    PowerManager.WakeLock partialWakeLock;
    AudioManager audioManager;

    boolean isListeningActive = false;
    int networkRetryDelay = 1000;

    static final double[][] STORES = {
        {50.8503, 4.3517, 500, 4.3517, 50.8503, 1},
        {50.8450, 4.3800, 500, 4.3800, 50.8450, 2},
        {50.8600, 4.3400, 500, 4.3400, 50.8600, 3},
        {50.8350, 4.3600, 500, 4.3600, 50.8350, 4}
    };
    long lastNotificationTime = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        serviceHandler = new Handler(Looper.getMainLooper());
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Poupous à l'écoute", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if ("STOP_SERVICE".equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if ("START_LOCATION".equals(action)) {
            startLocationUpdates();
        } else if ("STOP_LOCATION".equals(action)) {
            stopLocationUpdates();
        }

        Intent notificationIntent = new Intent(this, MainActivity.class);
        int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, flagsPending);

        Intent stopIntent = new Intent(this, PoupousService.class);
        stopIntent.setAction("STOP_SERVICE");
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 0, stopIntent, flagsPending);

        Notification.Builder builder = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
        builder.setContentTitle("Poupous")
               .setContentText("Poupous est à l'écoute")
               .setSmallIcon(android.R.drawable.ic_btn_speak_now)
               .setContentIntent(pendingIntent);

        if (Build.VERSION.SDK_INT >= 23) {
            builder.addAction(new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel, "Arrêter", stopPendingIntent).build());
        }

        Notification notification = builder.build();
        startForeground(1, notification);

        SharedPreferences prefs = getSharedPreferences("poupous", MODE_PRIVATE);
        prefs.edit().putBoolean("wake_running", true).apply();

        if (!isListeningActive) {
            isListeningActive = true;
            serviceHandler.post(this::initAndStartListening);
        }

        return START_STICKY;
    }

    void acquirePartialWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                if (partialWakeLock == null) {
                    partialWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Poupous::SpeechWakeLock");
                }
                if (!partialWakeLock.isHeld()) {
                    partialWakeLock.acquire(10000);
                }
            }
        } catch (Exception ignored) {}
    }

    void releasePartialWakeLock() {
        try {
            if (partialWakeLock != null && partialWakeLock.isHeld()) {
                partialWakeLock.release();
            }
        } catch (Exception ignored) {}
    }

    void initAndStartListening() {
        if (!isListeningActive) return;
        acquirePartialWakeLock();

        if (speechRecognizer != null) {
            try {
                speechRecognizer.destroy();
            } catch (Exception ignored) {}
            speechRecognizer = null;
        }

        try {
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
        } catch (Exception e) {
            try {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            } catch (Exception ignored) {}
        }

        if (speechRecognizer == null) {
            releasePartialWakeLock();
            serviceHandler.postDelayed(() -> initAndStartListening(), 2000);
            return;
        }

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}

            @Override
            public void onResults(Bundle results) {
                releasePartialWakeLock();
                ArrayList<String> matches = results != null ? results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) : null;
                if (matches != null && !matches.isEmpty()) {
                    processRecognizedText(matches.get(0));
                }
                networkRetryDelay = 1000;
                if (isListeningActive) {
                    serviceHandler.postDelayed(() -> initAndStartListening(), 300);
                }
            }

            @Override
            public void onError(int error) {
                releasePartialWakeLock();

                if (!isListeningActive) return;

                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    serviceHandler.postDelayed(() -> initAndStartListening(), 100);
                } else if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                    try {
                        speechRecognizer.cancel();
                    } catch (Exception ignored) {}
                    serviceHandler.postDelayed(() -> initAndStartListening(), 300);
                } else if (error == SpeechRecognizer.ERROR_CLIENT) {
                    try {
                        speechRecognizer.destroy();
                    } catch (Exception ignored) {}
                    speechRecognizer = null;
                    serviceHandler.postDelayed(() -> initAndStartListening(), 500);
                } else if (error == SpeechRecognizer.ERROR_NETWORK) {
                    int delay = networkRetryDelay;
                    networkRetryDelay = Math.min(networkRetryDelay * 2, 30000);
                    serviceHandler.postDelayed(() -> initAndStartListening(), delay);
                } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    isListeningActive = false;
                } else {
                    serviceHandler.postDelayed(() -> initAndStartListening(), 1000);
                }
            }

            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);

        try {
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            releasePartialWakeLock();
            serviceHandler.postDelayed(() -> initAndStartListening(), 1000);
        }
    }

    void processRecognizedText(String rawText) {
        if (rawText == null) return;
        String lower = rawText.toLowerCase(Locale.ROOT).trim();
        String[] triggers = {"poupous", "poupou", "popo", "poupousse", "papous"};

        int matchedIndex = -1;
        String matchedTrigger = "";
        for (String trig : triggers) {
            int idx = lower.indexOf(trig);
            if (idx != -1) {
                matchedIndex = idx;
                matchedTrigger = trig;
                break;
            }
        }

        if (matchedIndex != -1) {
            String after = lower.substring(matchedIndex + matchedTrigger.length()).trim();
            wakeUpApp(after);
        }
    }

    void wakeUpApp(String afterText) {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                PowerManager.WakeLock wakeLock = pm.newWakeLock(
                    PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE,
                    "Poupous::VoiceWakeUp"
                );
                wakeLock.acquire(3000);
            }
        } catch (Exception ignored) {}

        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("reveil_after", afterText);
        startActivity(intent);
    }

    void startLocationUpdates() {
        if (isTracking) return;
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locationManager != null && (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10.0f, this);
                if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 10.0f, this);
                }
                isTracking = true;
            }
        } catch (Exception ignored) {}
    }

    void stopLocationUpdates() {
        if (!isTracking) return;
        try {
            if (locationManager != null) {
                locationManager.removeUpdates(this);
            }
        } catch (Exception ignored) {}
        isTracking = false;
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location == null) return;
        long now = System.currentTimeMillis();
        if (now - lastNotificationTime < 300000) return;

        double userLat = location.getLatitude();
        double userLon = location.getLongitude();

        String[] storeNames = {"Aldi", "Lidl", "Colruyt", "Action"};
        for (int i = 0; i < STORES.length; i++) {
            double sLat = STORES[i][1];
            double sLon = STORES[i][0];
            float[] results = new float[1];
            Location.distanceBetween(userLat, userLon, sLat, sLon, results);
            float distanceInMeters = results[0];

            if (distanceInMeters <= 500.0f) {
                lastNotificationTime = now;
                String storeName = i < storeNames.length ? storeNames[i] : "Magasin";
                triggerStoreNotification(storeName, (int) distanceInMeters);
                break;
            }
        }
    }

    void triggerStoreNotification(String storeName, int distance) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Intent intent = new Intent(this, MainActivity.class);
            int flagsPending = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, flagsPending);

            Notification.Builder builder = new Notification.Builder(this);
            if (Build.VERSION.SDK_INT >= 26) builder.setChannelId(CHANNEL_ID);
            builder.setContentTitle("Proche de " + storeName + " !")
                   .setContentText("Vous êtes à moins de " + distance + "m. Pensez à vérifier votre liste de courses !")
                   .setSmallIcon(android.R.drawable.ic_dialog_map)
                   .setAutoCancel(true)
                   .setContentIntent(pendingIntent);

            if (nm != null) {
                nm.notify(2, builder.build());
            }
        } catch (Exception ignored) {}
    }

    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}

    public static void startHttpServer(final Context context) {
        if (serverRunning) return;
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(8080);
                serverRunning = true;
                while (serverRunning) {
                    try {
                        Socket socket = serverSocket.accept();
                        activeClientSocket = socket;
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String line = reader.readLine();
                        if (line == null) {
                            socket.close();
                            continue;
                        }

                        SharedPreferences prefs = context.getSharedPreferences("poupous", MODE_PRIVATE);
                        String payload = prefs.getString("sync_shared_payload", "{\"lists\":{},\"messages\":[]}");

                        if (line.contains("POST /update")) {
                            StringBuilder sb = new StringBuilder();
                            int contentLength = 0;
                            String l;
                            while ((l = reader.readLine()) != null && !l.isEmpty()) {
                                if (l.toLowerCase().startsWith("content-length:")) {
                                    try {
                                        contentLength = Integer.parseInt(l.substring(15).trim());
                                    } catch (Exception ignored) {}
                                }
                            }
                            char[] buf = new char[contentLength];
                            int read = 0;
                            while (read < contentLength) {
                                int r = reader.read(buf, read, contentLength - read);
                                if (r == -1) break;
                                read += r;
                            }
                            String body = new String(buf, 0, read);
                            if (!body.isEmpty()) {
                                prefs.edit().putString("sync_shared_payload", body).apply();
                            }
                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n{\"status\":\"ok\"}";
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        } else {
                            String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Poupous PC Sync</title>" +
                                    "<style>body{background:#030712;color:#f8fafc;font-family:sans-serif;padding:40px;max-width:800px;margin:0 auto;}" +
                                    "h1{color:#00e5ff;margin-bottom:10px;} textarea{width:100%;height:350px;background:#111827;color:#f8fafc;border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:16px;font-size:15px;outline:none;}" +
                                    "button{background:#00e5ff;color:#000;font-weight:bold;padding:14px 28px;border:none;border-radius:12px;cursor:pointer;margin-top:16px;font-size:16px;box-shadow:0 0 20px rgba(0,229,255,0.3);}" +
                                    "</style></head><body><h1>Poupous - Synchronisation PC</h1>" +
                                    "<p style='color:#94a3b8;margin-bottom:20px;'>Modifiez vos listes et données ci-dessous. La synchronisation avec le téléphone est instantanée :</p>" +
                                    "<textarea id='data'>" + payload + "</textarea><br>" +
                                    "<button onclick='save()'>Enregistrer et synchroniser</button>" +
                                    "<script>" +
                                    "function save(){" +
                                    "fetch('/update',{method:'POST',headers:{'Content-Type':'application/json'},body:document.getElementById('data').value})" +
                                    ".then(r=>alert('Données synchronisées avec succès !'));" +
                                    "}" +
                                    "</script></body></html>";

                            String httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\n\r\n" + html;
                            OutputStream out = socket.getOutputStream();
                            out.write(httpResponse.getBytes("UTF-8"));
                            out.flush();
                        }
                        socket.close();
                    } catch (Exception e) {
                        break;
                    }
                }
            } catch (Exception e) {
                serverRunning = false;
            }
        }).start();
    }

    public static void stopHttpServer() {
        serverRunning = false;
        try {
            if (serverSocket != null) serverSocket.close();
            if (activeClientSocket != null) activeClientSocket.close();
        } catch (Exception ignored) {}
    }

    public static boolean isServerRunning() {
        return serverRunning;
    }

    public static void broadcastSync(String json) {}

    public static String getLocalIpAddress(Context context) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        boolean isIPv4 = sAddr.indexOf(':') < 0;
                        if (isIPv4) return sAddr;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }

    @Override
    public void onDestroy() {
        isListeningActive = false;
        if (speechRecognizer != null) {
            try {
                speechRecognizer.destroy();
            } catch (Exception ignored) {}
            speechRecognizer = null;
        }
        releasePartialWakeLock();
        stopLocationUpdates();
        stopHttpServer();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
