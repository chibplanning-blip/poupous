@echo off
chcp 65001 >nul
rem Lance le serveur Poupous a chaque ouverture de session Windows
schtasks /create /tn "Poupous serveur famille" /tr "\"%~dp0lancer_serveur.bat\"" /sc onlogon /rl limited /f
echo.
echo Fait. Le serveur se lancera tout seul quand Windows demarre.
pause
