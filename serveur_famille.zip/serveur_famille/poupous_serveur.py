#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Serveur famille de Poupous (Windows, Linux ou Mac) - aucune installation de paquet : Python 3.8+ suffit.

Il fait deux choses pour toute la famille :
  1. Il garde le cerveau (les clés Gemini / Claude restent sur CET ordinateur, jamais sur les téléphones).
  2. Il garde une mémoire commune que tous les téléphones partagent.

Commandes :
  python poupous_serveur.py                       -> démarre le serveur
  python poupous_serveur.py adresse https://...   -> enregistre l'adresse publique (voir LISEZ-MOI)
  python poupous_serveur.py cle-gemini XXXX       -> enregistre la clé Gemini
  python poupous_serveur.py cle-claude XXXX       -> enregistre la clé Claude (facultatif)
  python poupous_serveur.py ajouter Prenom        -> crée l'accès d'une personne et affiche son CODE FAMILLE
  python poupous_serveur.py code Prenom           -> réaffiche le code d'une personne
  python poupous_serveur.py retirer Prenom        -> supprime l'accès d'une personne
  python poupous_serveur.py liste                 -> liste les personnes
"""
import base64
import json
import os
import re
import secrets
import sys
import threading
import time
import unicodedata
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DOSSIER = os.path.dirname(os.path.abspath(__file__))
CONF = os.path.join(DOSSIER, "config.json")
MEM = os.path.join(DOSSIER, "memoire.json")
GEMINI_BASE = os.environ.get("POUPOUS_GEMINI_BASE", "https://generativelanguage.googleapis.com")
CLAUDE_BASE = os.environ.get("POUPOUS_CLAUDE_BASE", "https://api.anthropic.com")
MAX_CORPS = 30 * 1024 * 1024
LIMITE_PAR_MINUTE = 60
verrou = threading.Lock()
appels = {}


# ------------------------------------------------------------------ fichiers

def lire_json(chemin, defaut):
    try:
        with open(chemin, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return defaut


def ecrire_json(chemin, donnees):
    tmp = chemin + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(donnees, f, ensure_ascii=False, indent=2)
    os.replace(tmp, chemin)


def config():
    c = lire_json(CONF, {})
    c.setdefault("port", 8787)
    c.setdefault("adresse", "")
    c.setdefault("gemini_key", "")
    c.setdefault("claude_key", "")
    c.setdefault("personnes", {})  # jeton -> prénom
    return c


def norm(s):
    s = unicodedata.normalize("NFD", str(s).lower())
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")


def code_famille(c, jeton):
    brut = json.dumps({"u": c["adresse"], "t": jeton}, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(brut).decode("ascii").rstrip("=")


# ------------------------------------------------------------------ mémoire commune

def memoire():
    return lire_json(MEM, {"faits": []})


def modifier_memoire(nom, corps):
    op = corps.get("op")
    with verrou:
        m = memoire()
        faits = m.get("faits", [])
        if op == "add":
            t = str(corps.get("t", "")).strip()[:500]
            if t and not any(norm(f["t"]) == norm(t) for f in faits):
                faits.append({"id": secrets.token_hex(4), "t": t, "par": nom, "date": time.strftime("%Y-%m-%d")})
        elif op == "del":
            q = str(corps.get("q", "")).strip()
            if q == "*":
                faits = [f for f in faits if f.get("par") != nom]  # '*' n'efface que ses propres souvenirs
            elif q:
                faits = [f for f in faits if norm(q) not in norm(f["t"])]
        else:
            return None
        m["faits"] = faits[-500:]
        ecrire_json(MEM, m)
        return m


# ------------------------------------------------------------------ serveur

def limite_atteinte(nom):
    maintenant = time.time()
    liste = [t for t in appels.get(nom, []) if maintenant - t < 60]
    if len(liste) >= LIMITE_PAR_MINUTE:
        appels[nom] = liste
        return True
    liste.append(maintenant)
    appels[nom] = liste
    return False


class Gestionnaire(BaseHTTPRequestHandler):
    server_version = "PoupousFamille/1.0"

    def log_message(self, fmt, *args):
        pass

    def repondre(self, statut, corps, type_="application/json; charset=utf-8"):
        donnees = corps if isinstance(corps, bytes) else json.dumps(corps, ensure_ascii=False).encode("utf-8")
        self.send_response(statut)
        self.send_header("Content-Type", type_)
        self.send_header("Content-Length", str(len(donnees)))
        self.end_headers()
        self.wfile.write(donnees)

    def personne(self):
        jeton = self.headers.get("X-Poupous-Token", "")
        return config()["personnes"].get(jeton) if jeton else None

    def lire_corps(self):
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return None
        if n <= 0 or n > MAX_CORPS:
            return None
        return self.rfile.read(n)

    def relayer(self, url, entetes, corps):
        req = urllib.request.Request(url, data=corps, headers=entetes, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=150) as r:
                self.repondre(r.status, r.read())
        except urllib.error.HTTPError as e:
            self.repondre(e.code, e.read() or b"{}")
        except Exception as e:  # réseau coupé côté ordinateur
            self.repondre(502, {"error": {"message": "l'ordinateur n'arrive pas à joindre le service : " + str(e)[:120]}})

    def do_GET(self):
        p = urlparse(self.path)
        nom = self.personne()
        if p.path == "/":
            return self.repondre(200, "Poupous famille : en marche.".encode("utf-8"), "text/plain; charset=utf-8")
        if not nom:
            return self.repondre(401, {"error": {"message": "code famille refusé"}})
        if p.path == "/ping":
            c = config()
            return self.repondre(200, {"ok": True, "nom": nom, "gemini": bool(c["gemini_key"]), "claude": bool(c["claude_key"])})
        if p.path == "/memoire":
            return self.repondre(200, memoire())
        self.repondre(404, {"error": {"message": "inconnu"}})

    def do_POST(self):
        p = urlparse(self.path)
        nom = self.personne()
        if not nom:
            return self.repondre(401, {"error": {"message": "code famille refusé"}})
        if limite_atteinte(nom):
            return self.repondre(429, {"error": {"message": "trop de demandes d'un coup"}})
        corps = self.lire_corps()
        if corps is None:
            return self.repondre(400, {"error": {"message": "corps de requête absent ou trop gros"}})
        c = config()
        if p.path == "/gemini":
            modele = parse_qs(p.query).get("model", [""])[0]
            if not re.fullmatch(r"[A-Za-z0-9._-]{1,60}", modele):
                return self.repondre(400, {"error": {"message": "modèle invalide"}})
            if not c["gemini_key"]:
                return self.repondre(400, {"error": {"message": "pas de clé Gemini sur l'ordinateur de la maison"}})
            url = "%s/v1beta/models/%s:generateContent?key=%s" % (GEMINI_BASE, modele, c["gemini_key"])
            return self.relayer(url, {"Content-Type": "application/json"}, corps)
        if p.path == "/claude":
            if not c["claude_key"]:
                return self.repondre(400, {"error": {"message": "pas de clé Claude sur l'ordinateur de la maison"}})
            return self.relayer(CLAUDE_BASE + "/v1/messages", {
                "Content-Type": "application/json", "x-api-key": c["claude_key"], "anthropic-version": "2023-06-01"}, corps)
        if p.path == "/memoire":
            try:
                m = modifier_memoire(nom, json.loads(corps.decode("utf-8")))
            except ValueError:
                m = None
            if m is None:
                return self.repondre(400, {"error": {"message": "opération inconnue"}})
            return self.repondre(200, m)
        self.repondre(404, {"error": {"message": "inconnu"}})


# ------------------------------------------------------------------ commandes

def commande(args):
    c = config()
    cmd = args[0].lower()
    if cmd == "adresse" and len(args) == 2:
        c["adresse"] = args[1].strip().rstrip("/")
        ecrire_json(CONF, c)
        print("Adresse enregistrée :", c["adresse"])
    elif cmd in ("cle-gemini", "cle-claude") and len(args) == 2:
        c[cmd.replace("cle-", "") + "_key"] = args[1].strip()
        ecrire_json(CONF, c)
        print("Clé enregistrée.")
    elif cmd == "ajouter" and len(args) >= 2:
        nom = " ".join(args[1:]).strip()
        if any(norm(n) == norm(nom) for n in c["personnes"].values()):
            print("Cette personne existe déjà. Utilise : code", nom)
            return
        jeton = secrets.token_urlsafe(24)
        c["personnes"][jeton] = nom
        ecrire_json(CONF, c)
        afficher_code(c, nom, jeton)
    elif cmd == "code" and len(args) >= 2:
        nom = " ".join(args[1:]).strip()
        for j, n in c["personnes"].items():
            if norm(n) == norm(nom):
                return afficher_code(c, n, j)
        print("Personne inconnue.")
    elif cmd == "retirer" and len(args) >= 2:
        nom = " ".join(args[1:]).strip()
        avant = len(c["personnes"])
        c["personnes"] = {j: n for j, n in c["personnes"].items() if norm(n) != norm(nom)}
        ecrire_json(CONF, c)
        print("Accès retiré." if len(c["personnes"]) < avant else "Personne inconnue.")
    elif cmd == "liste":
        for n in c["personnes"].values():
            print("-", n)
        if not c["personnes"]:
            print("(personne pour l'instant)")
    else:
        print(__doc__)


def afficher_code(c, nom, jeton):
    if not c["adresse"]:
        print("Il manque l'adresse publique. Fais d'abord : python poupous_serveur.py adresse https://...")
        return
    print("\nCODE FAMILLE de %s (à coller dans Poupous, réglages, rubrique Famille) :\n\n%s\n" % (nom, code_famille(c, jeton)))


def main():
    if len(sys.argv) > 1:
        return commande(sys.argv[1:])
    c = config()
    if not os.path.exists(CONF):
        ecrire_json(CONF, c)
    print("Poupous famille - port %d" % c["port"])
    print("Personnes :", ", ".join(c["personnes"].values()) or "aucune (fais : python poupous_serveur.py ajouter Prenom)")
    print("Clé Gemini :", "oui" if c["gemini_key"] else "NON", "| Clé Claude :", "oui" if c["claude_key"] else "non")
    print("Adresse publique :", c["adresse"] or "pas encore (voir LISEZ-MOI)")
    srv = ThreadingHTTPServer(("0.0.0.0", c["port"]), Gestionnaire)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
