#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Serveur famille de Poupous (Windows, Linux ou Mac) - aucune installation de paquet : Python 3.8+ suffit.

Il fait deux choses pour toute la famille :
  1. Il garde le cerveau (les clés Gemini / Claude restent sur CET ordinateur, jamais sur les téléphones).
  2. Il garde une mémoire commune que tous les téléphones partagent.

Commandes :
  python poupous_serveur.py                       -> démarre le serveur
  python poupous_serveur.py adresse https://...   -> enregistre l'adresse publique (voir LISEZ-MOI)
  python poupous_serveur.py cle-gemini XXXX       -> enregistre la clé Gemini
  python poupous_serveur.py cle-claude XXXX       -> enregistre la clé Claude (facultatif)
  python poupous_serveur.py cle-cloudflare ID JETON -> images (Cloudflare Workers AI)
  python poupous_serveur.py cle-pixazo XXXX       -> vidéos (Pixazo)
  python poupous_serveur.py autre URL CLE MODELE  -> autre IA (Kimi, DeepSeek...), ex. https://api.moonshot.ai/v1 sk-... kimi-k2.6
  python poupous_serveur.py admin Prenom          -> autorise cette personne à envoyer les clés depuis son téléphone
  python poupous_serveur.py ajouter Prenom        -> crée l'accès d'une personne et affiche son CODE FAMILLE
  python poupous_serveur.py code Prenom           -> réaffiche le code d'une personne
  python poupous_serveur.py retirer Prenom        -> supprime l'accès d'une personne
  python poupous_serveur.py enfant Prenom 5e      -> profil enfant : Poupous l'aide aux devoirs sans les faire à sa place
  python poupous_serveur.py adulte Prenom         -> remet un profil adulte
  python poupous_serveur.py liste                 -> liste les personnes
"""
import base64
import json
import os
import re
import secrets
import sys
import threading
import time
import unicodedata
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DOSSIER = os.path.dirname(os.path.abspath(__file__))
CONF = os.path.join(DOSSIER, "config.json")
MEM = os.path.join(DOSSIER, "memoire.json")
GEMINI_BASE = os.environ.get("POUPOUS_GEMINI_BASE", "https://generativelanguage.googleapis.com")
CLAUDE_BASE = os.environ.get("POUPOUS_CLAUDE_BASE", "https://api.anthropic.com")
CF_BASE = os.environ.get("POUPOUS_CF_BASE", "https://api.cloudflare.com")
PIXAZO_BASE = os.environ.get("POUPOUS_PIXAZO_BASE", "https://gateway.pixazo.ai/ltx-video/v1")
CF_MODELE = "@cf/black-forest-labs/flux-1-schnell"
MAX_CORPS = 30 * 1024 * 1024
LIMITE_PAR_MINUTE = 60
verrou = threading.Lock()
appels = {}


# ------------------------------------------------------------------ fichiers

def lire_json(chemin, defaut):
    try:
        with open(chemin, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return defaut


def ecrire_json(chemin, donnees):
    tmp = chemin + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(donnees, f, ensure_ascii=False, indent=2)
    os.replace(tmp, chemin)


def config():
    c = lire_json(CONF, {})
    c.setdefault("port", 8787)
    c.setdefault("adresse", "")
    c.setdefault("gemini_key", "")
    c.setdefault("claude_key", "")
    c.setdefault("personnes", {})  # jeton -> prénom
    c.setdefault("profils", {})  # prénom -> {"enfant": true, "classe": "5e"}
    c.setdefault("admins", [])  # prénoms autorisés à envoyer les clés depuis leur téléphone
    c.setdefault("cloudflare", {"compte": "", "jeton": ""})
    c.setdefault("pixazo", "")
    c.setdefault("autre", {"preset": "", "base": "", "key": "", "model": ""})
    return c


def norm(s):
    s = unicodedata.normalize("NFD", str(s).lower())
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")


def services(c):
    a = c.get("autre", {})
    cf = c.get("cloudflare", {})
    return {
        "gemini": bool(c["gemini_key"]),
        "claude": bool(c["claude_key"]),
        "images": bool(cf.get("compte") and cf.get("jeton")),
        "video": bool(c.get("pixazo")),
        "autre": bool(a.get("base") and a.get("key") and a.get("model")),
        "autre_preset": a.get("preset", ""),
        "autre_model": a.get("model", ""),
    }


def est_admin(c, nom):
    return any(norm(nom) == norm(x) for x in c.get("admins", []))


def code_famille(c, jeton):
    brut = json.dumps({"u": c["adresse"], "t": jeton}, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(brut).decode("ascii").rstrip("=")


# ------------------------------------------------------------------ mémoire commune

def memoire():
    return lire_json(MEM, {"faits": []})


def modifier_memoire(nom, corps):
    op = corps.get("op")
    with verrou:
        m = memoire()
        faits = m.get("faits", [])
        if op == "add":
            t = str(corps.get("t", "")).strip()[:500]
            if t and not any(norm(f["t"]) == norm(t) for f in faits):
                faits.append({"id": secrets.token_hex(4), "t": t, "par": nom, "date": time.strftime("%Y-%m-%d")})
        elif op == "del":
            q = str(corps.get("q", "")).strip()
            if q == "*":
                faits = [f for f in faits if f.get("par") != nom]  # '*' n'efface que ses propres souvenirs
            elif q:
                faits = [f for f in faits if norm(q) not in norm(f["t"])]
        else:
            return None
        m["faits"] = faits[-500:]
        ecrire_json(MEM, m)
        return m


def texte_cle(v, mini=8, maxi=400):
    v = re.sub(r"\s+", "", str(v or ""))
    return v if mini <= len(v) <= maxi else ""


def enregistrer_cles(d):
    """Met à jour seulement les clés fournies et valides. Renvoie la liste de ce qui a été enregistré."""
    with verrou:
        c = config()
        fait = []
        v = texte_cle(d.get("gemini"))
        if v:
            c["gemini_key"] = v; fait.append("gemini")
        v = texte_cle(d.get("claude"))
        if v:
            c["claude_key"] = v; fait.append("claude")
        cf = d.get("cloudflare") or {}
        compte, jeton = texte_cle(cf.get("compte"), 32, 32), texte_cle(cf.get("jeton"), 20)
        if compte and jeton and re.fullmatch(r"[0-9a-fA-F]{32}", compte):
            c["cloudflare"] = {"compte": compte, "jeton": jeton}; fait.append("images")
        v = texte_cle(d.get("pixazo"), 12)
        if v:
            c["pixazo"] = v; fait.append("video")
        a = d.get("autre") or {}
        base = str(a.get("base", "")).strip().rstrip("/")
        cle, modele = texte_cle(a.get("key")), str(a.get("model", "")).strip()[:120]
        if base.startswith("https://") and len(base) < 200 and cle and modele:
            c["autre"] = {"preset": str(a.get("preset", ""))[:30], "base": base, "key": cle, "model": modele}; fait.append("autre")
        if fait:
            ecrire_json(CONF, c)
        return fait


# ------------------------------------------------------------------ serveur

def limite_atteinte(nom):
    maintenant = time.time()
    liste = [t for t in appels.get(nom, []) if maintenant - t < 60]
    if len(liste) >= LIMITE_PAR_MINUTE:
        appels[nom] = liste
        return True
    liste.append(maintenant)
    appels[nom] = liste
    return False


class Gestionnaire(BaseHTTPRequestHandler):
    server_version = "PoupousFamille/1.0"

    def log_message(self, fmt, *args):
        pass

    def repondre(self, statut, corps, type_="application/json; charset=utf-8"):
        donnees = corps if isinstance(corps, bytes) else json.dumps(corps, ensure_ascii=False).encode("utf-8")
        self.send_response(statut)
        self.send_header("Content-Type", type_)
        self.send_header("Content-Length", str(len(donnees)))
        self.end_headers()
        self.wfile.write(donnees)

    def personne(self):
        jeton = self.headers.get("X-Poupous-Token", "")
        return config()["personnes"].get(jeton) if jeton else None

    def lire_corps(self):
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return None
        if n <= 0 or n > MAX_CORPS:
            return None
        return self.rfile.read(n)

    def relayer(self, url, entetes, corps):
        req = urllib.request.Request(url, data=corps, headers=entetes, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=150) as r:
                self.repondre(r.status, r.read())
        except urllib.error.HTTPError as e:
            self.repondre(e.code, e.read() or b"{}")
        except Exception as e:  # réseau coupé côté ordinateur
            self.repondre(502, {"error": {"message": "l'ordinateur n'arrive pas à joindre le service : " + str(e)[:120]}})

    def relayer_get(self, url, entetes):
        req = urllib.request.Request(url, headers=entetes, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                self.repondre(r.status, r.read())
        except urllib.error.HTTPError as e:
            self.repondre(e.code, e.read() or b"{}")
        except Exception as e:
            self.repondre(502, {"error": {"message": "l'ordinateur n'arrive pas à joindre le service : " + str(e)[:120]}})

    def do_GET(self):
        p = urlparse(self.path)
        nom = self.personne()
        if p.path == "/":
            return self.repondre(200, "Poupous famille : en marche.".encode("utf-8"), "text/plain; charset=utf-8")
        if not nom:
            return self.repondre(401, {"error": {"message": "code famille refusé"}})
        if p.path == "/ping":
            c = config()
            pr = c["profils"].get(nom, {})
            sv = services(c)
            return self.repondre(200, {"ok": True, "nom": nom, "gemini": sv["gemini"], "claude": sv["claude"],
                                       "enfant": bool(pr.get("enfant")), "classe": str(pr.get("classe", ""))[:30],
                                       "admin": est_admin(c, nom), "services": sv})
        if p.path == "/memoire":
            return self.repondre(200, memoire())
        if p.path == "/video/poll":
            c = config()
            cible = parse_qs(p.query).get("u", [""])[0]
            hote = (urlparse(cible).hostname or "").lower()
            if not c.get("pixazo"):
                return self.repondre(400, {"error": {"message": "pas de clé Pixazo sur l'ordinateur de la maison"}})
            if urlparse(cible).scheme != "https" or not (hote == "pixazo.ai" or hote.endswith(".pixazo.ai")):
                return self.repondre(400, {"error": {"message": "adresse de suivi refusée"}})
            return self.relayer_get(cible, {"Ocp-Apim-Subscription-Key": c["pixazo"]})
        self.repondre(404, {"error": {"message": "inconnu"}})

    def do_POST(self):
        p = urlparse(self.path)
        nom = self.personne()
        if not nom:
            return self.repondre(401, {"error": {"message": "code famille refusé"}})
        if limite_atteinte(nom):
            return self.repondre(429, {"error": {"message": "trop de demandes d'un coup"}})
        corps = self.lire_corps()
        if corps is None:
            return self.repondre(400, {"error": {"message": "corps de requête absent ou trop gros"}})
        c = config()
        if p.path == "/gemini":
            modele = parse_qs(p.query).get("model", [""])[0]
            if not re.fullmatch(r"[A-Za-z0-9._-]{1,60}", modele):
                return self.repondre(400, {"error": {"message": "modèle invalide"}})
            if not c["gemini_key"]:
                return self.repondre(400, {"error": {"message": "pas de clé Gemini sur l'ordinateur de la maison"}})
            url = "%s/v1beta/models/%s:generateContent?key=%s" % (GEMINI_BASE, modele, c["gemini_key"])
            return self.relayer(url, {"Content-Type": "application/json"}, corps)
        if p.path == "/claude":
            if not c["claude_key"]:
                return self.repondre(400, {"error": {"message": "pas de clé Claude sur l'ordinateur de la maison"}})
            return self.relayer(CLAUDE_BASE + "/v1/messages", {
                "Content-Type": "application/json", "x-api-key": c["claude_key"], "anthropic-version": "2023-06-01"}, corps)
        if p.path == "/images":
            cf = c.get("cloudflare", {})
            if not (cf.get("compte") and cf.get("jeton")):
                return self.repondre(400, {"error": {"message": "pas de clé Cloudflare sur l'ordinateur de la maison"}})
            if not re.fullmatch(r"[0-9a-fA-F]{32}", cf["compte"]):
                return self.repondre(400, {"error": {"message": "identifiant de compte Cloudflare invalide sur l'ordinateur"}})
            return self.relayer("%s/client/v4/accounts/%s/ai/run/%s" % (CF_BASE, cf["compte"], CF_MODELE),
                                {"Content-Type": "application/json", "Authorization": "Bearer " + cf["jeton"]}, corps)
        if p.path.startswith("/video/") and p.path != "/video/poll":
            chemin = p.path[len("/video/"):]
            if not c.get("pixazo"):
                return self.repondre(400, {"error": {"message": "pas de clé Pixazo sur l'ordinateur de la maison"}})
            if not re.fullmatch(r"[a-z0-9][a-z0-9/_-]{0,60}", chemin) or ".." in chemin:
                return self.repondre(400, {"error": {"message": "chemin invalide"}})
            return self.relayer("%s/%s" % (PIXAZO_BASE, chemin),
                                {"Content-Type": "application/json", "Ocp-Apim-Subscription-Key": c["pixazo"]}, corps)
        if p.path == "/autre":
            a = c.get("autre", {})
            if not (a.get("base") and a.get("key") and a.get("model")):
                return self.repondre(400, {"error": {"message": "pas d'autre IA configurée sur l'ordinateur de la maison"}})
            try:
                requete = json.loads(corps.decode("utf-8"))
                requete["model"] = a["model"]
                requete.pop("stream", None)
                corps2 = json.dumps(requete).encode("utf-8")
            except ValueError:
                return self.repondre(400, {"error": {"message": "requête invalide"}})
            return self.relayer(a["base"].rstrip("/") + "/chat/completions",
                                {"Content-Type": "application/json", "Authorization": "Bearer " + a["key"]}, corps2)
        if p.path == "/cles":
            if not est_admin(c, nom):
                return self.repondre(403, {"error": {"message": "seul l'administrateur peut envoyer des clés"}})
            try:
                d = json.loads(corps.decode("utf-8"))
            except ValueError:
                return self.repondre(400, {"error": {"message": "requête invalide"}})
            maj = enregistrer_cles(d)
            return self.repondre(200, {"ok": True, "recu": maj, "services": services(config())})
        if p.path == "/memoire":
            try:
                m = modifier_memoire(nom, json.loads(corps.decode("utf-8")))
            except ValueError:
                m = None
            if m is None:
                return self.repondre(400, {"error": {"message": "opération inconnue"}})
            return self.repondre(200, m)
        self.repondre(404, {"error": {"message": "inconnu"}})


# ------------------------------------------------------------------ commandes

def commande(args):
    c = config()
    cmd = args[0].lower()
    if cmd == "adresse" and len(args) == 2:
        c["adresse"] = args[1].strip().rstrip("/")
        ecrire_json(CONF, c)
        print("Adresse enregistrée :", c["adresse"])
    elif cmd in ("cle-gemini", "cle-claude") and len(args) == 2:
        c[cmd.replace("cle-", "") + "_key"] = args[1].strip()
        ecrire_json(CONF, c)
        print("Clé enregistrée.")
    elif cmd == "cle-cloudflare" and len(args) == 3:
        c["cloudflare"] = {"compte": args[1].strip(), "jeton": args[2].strip()}
        ecrire_json(CONF, c)
        print("Clé Cloudflare (images) enregistrée.")
    elif cmd == "cle-pixazo" and len(args) == 2:
        c["pixazo"] = args[1].strip()
        ecrire_json(CONF, c)
        print("Clé Pixazo (vidéos) enregistrée.")
    elif cmd == "autre" and len(args) == 4:
        c["autre"] = {"preset": "", "base": args[1].strip().rstrip("/"), "key": args[2].strip(), "model": args[3].strip()}
        ecrire_json(CONF, c)
        print("Autre IA enregistrée.")
    elif cmd == "admin" and len(args) >= 2:
        nom = " ".join(args[1:]).strip()
        vrai = next((n for n in c["personnes"].values() if norm(n) == norm(nom)), None)
        if not vrai:
            print("Personne inconnue. Crée d'abord son accès : ajouter", nom)
            return
        if vrai not in c["admins"]:
            c["admins"].append(vrai)
            ecrire_json(CONF, c)
        print("%s peut maintenant envoyer les clés depuis son téléphone." % vrai)
    elif cmd == "ajouter" and len(args) >= 2:
        nom = " ".join(args[1:]).strip()
        if any(norm(n) == norm(nom) for n in c["personnes"].values()):
            print("Cette personne existe déjà. Utilise : code", nom)
            return
        jeton = secrets.token_urlsafe(24)
        premier = not c["personnes"]
        c["personnes"][jeton] = nom
        if premier:
            c["admins"].append(nom)  # la première personne créée est l'administrateur
        ecrire_json(CONF, c)
        afficher_code(c, nom, jeton)
    elif cmd == "code" and len(args) >= 2:
        nom = " ".join(args[1:]).strip()
        for j, n in c["personnes"].items():
            if norm(n) == norm(nom):
                return afficher_code(c, n, j)
        print("Personne inconnue.")
    elif cmd == "retirer" and len(args) >= 2:
        nom = " ".join(args[1:]).strip()
        avant = len(c["personnes"])
        c["personnes"] = {j: n for j, n in c["personnes"].items() if norm(n) != norm(nom)}
        ecrire_json(CONF, c)
        print("Accès retiré." if len(c["personnes"]) < avant else "Personne inconnue.")
    elif cmd == "enfant" and len(args) >= 2:
        nom = args[1].strip()
        vrai = next((n for n in c["personnes"].values() if norm(n) == norm(nom)), None)
        if not vrai:
            print("Personne inconnue. Crée d'abord son accès : ajouter", nom)
            return
        c["profils"][vrai] = {"enfant": True, "classe": " ".join(args[2:]).strip()}
        ecrire_json(CONF, c)
        print("%s est maintenant un profil enfant (aide aux devoirs sans faire à sa place)." % vrai)
    elif cmd == "adulte" and len(args) >= 2:
        nom = args[1].strip()
        vrai = next((n for n in c["personnes"].values() if norm(n) == norm(nom)), None)
        if vrai:
            c["profils"].pop(vrai, None)
            ecrire_json(CONF, c)
            print("%s est maintenant un profil adulte." % vrai)
        else:
            print("Personne inconnue.")
    elif cmd == "liste":
        for n in c["personnes"].values():
            pr = c["profils"].get(n, {})
            print("-", n, ("(enfant, " + pr.get("classe", "") + ")") if pr.get("enfant") else "")
        if not c["personnes"]:
            print("(personne pour l'instant)")
    else:
        print(__doc__)


def afficher_code(c, nom, jeton):
    if not c["adresse"]:
        print("Il manque l'adresse publique. Fais d'abord : python poupous_serveur.py adresse https://...")
        return
    print("\nCODE FAMILLE de %s (à coller dans Poupous, réglages, rubrique Famille) :\n\n%s\n" % (nom, code_famille(c, jeton)))


def main():
    if len(sys.argv) > 1:
        return commande(sys.argv[1:])
    c = config()
    if not os.path.exists(CONF):
        ecrire_json(CONF, c)
    print("Poupous famille - port %d" % c["port"])
    print("Personnes :", ", ".join(c["personnes"].values()) or "aucune (fais : python poupous_serveur.py ajouter Prenom)")
    sv = services(c)
    print("Services : Gemini", "oui" if sv["gemini"] else "NON", "| Claude", "oui" if sv["claude"] else "non", "| Images", "oui" if sv["images"] else "non",
          "| Vidéos", "oui" if sv["video"] else "non", "| Autre IA", "oui" if sv["autre"] else "non")
    print("Administrateurs :", ", ".join(c["admins"]) or "aucun")
    print("Adresse publique :", c["adresse"] or "pas encore (voir LISEZ-MOI)")
    srv = ThreadingHTTPServer(("0.0.0.0", c["port"]), Gestionnaire)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
