@echo off
chcp 65001 >nul
cd /d "%~dp0"
:boucle
python poupous_serveur.py
echo Le serveur s'est arrete. Redemarrage dans 5 secondes...
timeout /t 5 /nobreak >nul
goto boucle
